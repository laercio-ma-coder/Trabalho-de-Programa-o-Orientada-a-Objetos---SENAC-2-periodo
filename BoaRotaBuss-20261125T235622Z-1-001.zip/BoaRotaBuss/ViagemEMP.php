<?php include 'inc/headerEMP.inc.php'; ?>

<?php include 'inc/menuLateralEMP.inc.php'; ?>

<!-- BLOCO 1: FORMULÁRIO DE CADASTRO -->
<div class="tela">
    <section class="cadastrar-viagem" id="cadastrar-viagem">
        <h1 class="title">Cadastrar Viagem</h1>
        <p class="subtitle">Informe os dados da nova viagem, o motorista e o veículo escalado</p>

        <form action="." method="post">
            <div class="linha">
                <div class="campo">
                    <label class="dados" for="origem">Origem</label>
                    <input class="input" type="text" id="origem" name="origem"
                           placeholder="Digite a origem da viagem" required>
                </div>

                <div class="campo">
                    <label class="dados" for="destino">Destino</label>
                    <input class="input" type="text" id="destino" name="destino"
                           placeholder="Digite o destino da viagem" required>
                </div>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="data_viagem">Data da Viagem</label>
                    <input class="input" type="date" id="data_viagem" name="data_viagem" required>
                </div>

                <div class="campo">
                    <label class="dados" for="horario_saida">Horário de Saída</label>
                    <input class="input" type="time" id="horario_saida" name="horario_saida" required>
                </div>
            </div>

            <!-- Escala da Frota: Motorista e Ônibus -->
            <div class="linha">
                <div class="campo">
                    <label class="dados" for="motorista_id">Motorista Escalado</label>
                    <select class="input" id="motorista_id" name="motorista_id" required>
                        <option value="" disabled selected>Selecione o motorista</option>
                        <option value="1">Carlos Eduardo Mendes (CNH Cat. D)</option>
                        <option value="2">Marcos Vinícius Ferreira (CNH Cat. E)</option>
                        <option value="3">Roberto Almeida Santos (CNH Cat. D)</option>
                    </select>
                </div>

                <div class="campo">
                    <label class="dados" for="onibus_id">Ônibus da Frota</label>
                    <select class="input" id="onibus_id" name="onibus_id" required>
                        <option value="" disabled selected>Selecione o veículo</option>
                        <option value="1">Marcopolo Paradiso G7 — ABC-1234 (44 lugares)</option>
                        <option value="2">Comil Campione Invictus — DEF-5678 (46 lugares)</option>
                        <option value="3">Busscar Vissta Buss — GHI-9012 (42 lugares)</option>
                    </select>
                </div>
            </div>

            <!-- Botão para abrir Dados de Endereço -->
            <ul class="grade-acoes" id="itemAddDados">
                <li><button type="button" class="cardADD" id="btnAddDados">Adicionar Dados de Endereço</button></li>
            </ul>

            <!-- Área onde os dados de endereço serão abertos -->
            <div id="container-dados" class="container-paradas"></div>

            <!-- Botão de remover logo abaixo dos dados -->
            <ul class="grade-acoes escondido" id="itemRmvDados">
                <li><button type="button" class="cardRMV" id="btnRmvDados">Remover Dados</button></li>
            </ul>

            <!-- Botão para abrir Paradas -->
            <ul class="grade-acoes">
                <li><button type="button" class="cardADD" id="btnAddParada">Adicionar Parada</button></li>
            </ul>
            
            <!-- Área onde as paradas serão abertas -->
            <div id="container-paradas" class="container-paradas"></div>
            
            <!-- Botão de remover logo abaixo das paradas -->
            <ul class="grade-acoes escondido" id="itemRmvParada">
                <li><button type="button" class="cardRMV" id="btnRmvParada">Remover Parada</button></li>
            </ul>

            <div class="botoes">
                <button type="submit" class="buttonLGN" id="cadastrarV">Salvar Viagem</button>
            </div>
        </form>
    </section>
</div>

<!-- BLOCO 2: LISTAGEM VISUAL DE VIAGENS CADASTRADAS -->
<div class="tela">
    <div class="topo-listagem">
        <h1 class="title">Rotas Cadastradas</h1>
        <a href="historicoViagensEMP.php" class="btn-historico">Histórico de Viagens</a>
    </div>

    <div class="lista-viagens-cadastradas">
        <!-- Exemplo 1: Viagem com paradas -->
        <div class="card-viagem-item">
            <div class="detalhes-rota">
                <div class="rota-principal">
                    <span class="cidade-origem">Ponta Grossa - PR</span>
                    <span class="seta-rota">→</span>
                    <span class="cidade-destino">Curitiba - PR</span>
                </div>
                <div class="meta-viagem">
                    <span><strong>Data:</strong> 20/11/2026</span>
                    <span><strong>Saída:</strong> 08:00</span>
                    <span><strong>Motorista:</strong> Carlos Eduardo Mendes</span>
                    <span><strong>Ônibus:</strong> Marcopolo G7 (ABC-1234)</span>
                    <span class="badge-paradas com-paradas">3 paradas cadastradas</span>
                </div>
            </div>

            <div class="acoes-item">
                <a href="editarViagem.php?id=1" class="btn-editar">Editar</a>
                <a href="excluirViagem.php?id=1" class="btn-excluir">Excluir</a>
            </div>
        </div>

        <!-- Exemplo 2: Viagem direta (0 paradas) -->
        <div class="card-viagem-item">
            <div class="detalhes-rota">
                <div class="rota-principal">
                    <span class="cidade-origem">Ponta Grossa - PR</span>
                    <span class="seta-rota">→</span>
                    <span class="cidade-destino">Castro - PR</span>
                </div>
                <div class="meta-viagem">
                    <span><strong>Data:</strong> 21/11/2026</span>
                    <span><strong>Saída:</strong> 14:30</span>
                    <span><strong>Motorista:</strong> Marcos Vinícius Ferreira</span>
                    <span><strong>Ônibus:</strong> Comil Invictus (DEF-5678)</span>
                    <span class="badge-paradas direta">Viagem Direta (0 paradas)</span>
                </div>
            </div>

            <div class="acoes-item">
                <a href="editarViagem.php?id=2" class="btn-editar">Editar</a>
                <a href="excluirViagem.php?id=2" class="btn-excluir">Excluir</a>
            </div>
        </div>

        <!-- Exemplo 3: Viagem com 1 parada -->
        <div class="card-viagem-item">
            <div class="detalhes-rota">
                <div class="rota-principal">
                    <span class="cidade-origem">Curitiba - PR</span>
                    <span class="seta-rota">→</span>
                    <span class="cidade-destino">Guarapuava - PR</span>
                </div>
                <div class="meta-viagem">
                    <span><strong>Data:</strong> 22/11/2026</span>
                    <span><strong>Saída:</strong> 06:15</span>
                    <span><strong>Motorista:</strong> Roberto Almeida Santos</span>
                    <span><strong>Ônibus:</strong> Busscar Vissta (GHI-9012)</span>
                    <span class="badge-paradas com-paradas">1 parada cadastrada</span>
                </div>
            </div>

            <div class="acoes-item">
                <a href="editarViagem.php?id=3" class="btn-editar">Editar</a>
                <a href="excluirViagem.php?id=3" class="btn-excluir">Excluir</a>
            </div>
        </div>
    </div>
</div>

<script>
    // ==========================================================
    // 1. CONTROLE DOS DADOS DE ENDEREÇO
    // ==========================================================
    const btnAddDados = document.getElementById('btnAddDados');
    const btnRmvDados = document.getElementById('btnRmvDados');
    const itemAddDados = document.getElementById('itemAddDados');
    const itemRmvDados = document.getElementById('itemRmvDados');
    const containerDados = document.getElementById('container-dados');

    btnAddDados.addEventListener('click', () => {
        containerDados.innerHTML = `
            <div class="box-parada">
                <h3 class="titulo-parada">Dados de Endereço</h3>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="cep">CEP</label>
                        <input class="input" type="text" id="cep" name="cep" placeholder="00000-000" maxlength="9" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="numero">Número</label>
                        <input class="input" type="text" id="numero" name="numero" placeholder="Ex: 123" required>
                    </div>
                </div>

                <label class="dados" for="rua">Rua / Logradouro</label>
                <input class="input" type="text" id="rua" name="rua" placeholder="Digite o nome da rua ou avenida" required>

                <label class="dados" for="bairro">Bairro</label>
                <input class="input" type="text" id="bairro" name="bairro" placeholder="Digite o bairro" required>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="cidade">Cidade</label>
                        <input class="input" type="text" id="cidade" name="cidade" placeholder="Digite a cidade" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="estado">Estado (UF)</label>
                        <input class="input" type="text" id="estado" name="estado" placeholder="Ex: PR" maxlength="2" required>
                    </div>
                </div>
            </div>
        `;

        // Formatação e preenchimento automático via CEP
        const inputCep = document.getElementById('cep');
        inputCep.addEventListener('input', (e) => {
            let valor = e.target.value.replace(/\D/g, '');
            if (valor.length > 5) {
                valor = valor.replace(/^(\d{5})(\d)/, '$1-$2');
            }
            e.target.value = valor;

            if (valor.replace('-', '').length === 8) {
                fetch(`https://viacep.com.br/ws/${valor.replace('-', '')}/json/`)
                    .then(res => res.json())
                    .then(dados => {
                        if (!dados.erro) {
                            document.getElementById('rua').value = dados.logradouro || '';
                            document.getElementById('bairro').value = dados.bairro || '';
                            document.getElementById('cidade').value = dados.localidade || '';
                            document.getElementById('estado').value = dados.uf || '';
                            document.getElementById('numero').focus();
                        }
                    })
                    .catch(() => {});
            }
        });

        itemAddDados.classList.add('escondido');
        itemRmvDados.classList.remove('escondido');
    });

    btnRmvDados.addEventListener('click', () => {
        containerDados.innerHTML = '';
        itemRmvDados.classList.add('escondido');
        itemAddDados.classList.remove('escondido');
    });

    // ==========================================================
    // 2. CONTROLE DAS PARADAS DINÂMICAS
    // ==========================================================
    const btnAddParada = document.getElementById('btnAddParada');
    const btnRmvParada = document.getElementById('btnRmvParada');
    const itemRmvParada = document.getElementById('itemRmvParada');
    const containerParadas = document.getElementById('container-paradas');

    function atualizarVisibilidadeRemover() {
        const total = containerParadas.children.length;
        if (total > 0) {
            itemRmvParada.classList.remove('escondido');
        } else {
            itemRmvParada.classList.add('escondido');
        }
    }

    btnAddParada.addEventListener('click', () => {
        const numero = containerParadas.children.length + 1;

        const blocoParada = document.createElement('div');
        blocoParada.className = 'box-parada';
        blocoParada.innerHTML = `
            <h3 class="titulo-parada">Parada #${numero}</h3>
            
            <label class="dados" for="parada_local_${numero}">Parada</label>
            <input class="input" type="text" id="parada_local_${numero}" name="parada_local[]"
                   placeholder="Digite o local da parada" required>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="parada_data_${numero}">Data na Parada</label>
                    <input class="input" type="date" id="parada_data_${numero}" name="parada_data[]" required>
                </div>

                <div class="campo">
                    <label class="dados" for="parada_horario_${numero}">Horário Previsto</label>
                    <input class="input" type="time" id="parada_horario_${numero}" name="parada_horario[]" required>
                </div>
            </div>
        `;

        containerParadas.appendChild(blocoParada);
        atualizarVisibilidadeRemover();
    });

    btnRmvParada.addEventListener('click', () => {
        if (containerParadas.lastElementChild) {
            containerParadas.removeChild(containerParadas.lastElementChild);
            atualizarVisibilidadeRemover();
        }
    });
</script>

<?php include 'inc/footerEMP.inc.php'; ?>