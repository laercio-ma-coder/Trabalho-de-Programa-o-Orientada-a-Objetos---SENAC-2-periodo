<?php
/**
 * Classe responsável pela conexão com o banco de dados MySQL utilizando PDO
 * (PHP Data Objects) e o padrão de projeto Singleton.
 */
class Conexao
{
    // Guarda a única instância ativa da conexão (?PDO significa que pode ser PDO ou null)
    private static ?PDO $instancia = null;

    /**
     * Retorna a conexão ativa com o banco ou cria uma nova na primeira chamada.
     */
    public static function getConexao(): PDO
    {
        // Padrão Singleton: só abre uma nova conexão se ainda não existir nenhuma na memória
        if (self::$instancia === null) {
            $host = 'localhost';
            $db   = 'boarotabus'; // Nome exato do schema criado no MySQL Workbench
            $user = 'root';
            $pass = '';           // Senha do MySQL (vazia por padrão no XAMPP/WAMP)

            try {
                // DSN (Data Source Name) especifica o driver (mysql), servidor, banco e charset utf8mb4
                self::$instancia = new PDO(
                    "mysql:host=$host;dbname=$db;charset=utf8mb4",
                    $user,
                    $pass,
                    [
                        // Lança exceções (PDOException) em caso de erro SQL, facilitando o debug
                        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                        // Faz consultas retornarem arrays associativos ['coluna' => 'valor'] por padrão
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        // Desativa emulação para usar Prepared Statements nativos do MySQL (protege contra SQL Injection)
                        PDO::ATTR_EMULATE_PREPARES   => false,
                    ]
                );
            } catch (PDOException $e) {
                // Interrompe a execução e exibe a mensagem se o MySQL estiver desligado ou a senha errada
                die('Erro na conexão com o banco de dados: ' . $e->getMessage());
            }
        }

        return self::$instancia;
    }
}