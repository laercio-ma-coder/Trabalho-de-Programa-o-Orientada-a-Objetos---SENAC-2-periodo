<?php
/**
 * Classe utilitária estática que simula tabelas de banco de dados usando arquivos .json.
 * Ideal para prototipagem rápida sem depender de servidor MySQL ativo.
 */
class BancoJson
{
    // __DIR__ aponta para a pasta atual (/classes), e '/../dados/' sobe um nível para /dados/
    private static string $pasta = __DIR__ . '/../dados/';

    /**
     * Garante que a pasta /dados/ exista antes de qualquer operação de leitura/escrita.
     */
    private static function garantirPasta(): void
    {
        if (!is_dir(self::$pasta)) {
            // 0777 define permissão total de leitura/escrita; true cria subpastas se necessário
            mkdir(self::$pasta, 0777, true);
        }
    }

    /**
     * Lê todos os registros de uma "tabela" (arquivo .json) e devolve como array PHP.
     */
    public static function ler(string $tabela): array
    {
        self::garantirPasta();

        $arquivo = self::$pasta . $tabela . '.json';

        // Se o arquivo ainda não foi criado, retorna um array vazio sem gerar erro
        if (!file_exists($arquivo)) {
            return [];
        }

        $conteudo = file_get_contents($arquivo);

        // json_decode(..., true) converte o texto JSON em array associativo PHP
        // O operador ?? [] garante retorno vazio caso o arquivo esteja corrompido/em branco
        return json_decode($conteudo, true) ?? [];
    }

    /**
     * Sobrescreve o arquivo .json com a lista atualizada de registros.
     */
    public static function salvar(string $tabela, array $dados): void
    {
        self::garantirPasta();

        $arquivo = self::$pasta . $tabela . '.json';

        // JSON_PRETTY_PRINT: formata o JSON com quebras de linha legíveis para humanos
        // JSON_UNESCAPED_UNICODE: mantém acentos (ã, é, ç) legíveis em vez de códigos \u00e3
        file_put_contents(
            $arquivo,
            json_encode($dados, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }

    /**
     * Insere um novo registro gerando ID autoincremento único e data/hora de criação.
     */
    public static function inserir(string $tabela, array $registro): array
    {
        $lista = self::ler($tabela);

        // Calcula o maior ID já existente na lista para evitar IDs duplicados após exclusões
        $idsExistentes = array_column($lista, 'id');
        $proximoId     = empty($idsExistentes) ? 1 : (max($idsExistentes) + 1);

        $registro['id']        = $proximoId;
        $registro['criado_em'] = date('d/m/Y H:i');

        $lista[] = $registro; // Adiciona o novo registro ao final do array
        self::salvar($tabela, $lista);

        return $registro;
    }
}