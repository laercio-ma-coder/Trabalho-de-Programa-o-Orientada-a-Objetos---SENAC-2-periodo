<?php
/**
 * Classe responsável por autenticar o usuário, gravar os dados na sessão ($_SESSION)
 * e direcionar automaticamente para o painel correto conforme o domínio do e-mail.
 */
class Autenticador
{
    /**
     * Valida as credenciais e cria a sessão do usuário.
     *
     * @param string $email E-mail digitado no formulário de login
     * @param string $senha Senha digitada no formulário de login
     * @return array Retorna ['sucesso' => bool, 'destino' => string] ou ['sucesso' => false, 'mensagem' => string]
     */
    public function login(string $email, string $senha): array
    {
        // Garante que a sessão PHP esteja ativa antes de gravar dados em $_SESSION
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // trim() remove espaços acidentais nas pontas; strtolower() padroniza tudo em minúsculas
        $email = trim(strtolower($email));

        // Validação básica para impedir envio de campos vazios
        if ($email === '' || $senha === '') {
            return [
                'sucesso'  => false,
                'mensagem' => 'Preencha e-mail e senha.'
            ];
        }

        // ==========================================================
        // REGRA 1: PERFIL MOTORISTA (*.motorista@empresa.com)
        // str_contains() verifica se o texto ".motorista@" existe no e-mail
        // ==========================================================
        if (str_contains($email, '.motorista@')) {
            $_SESSION['usuario_id'] = 2;
            $_SESSION['nome']       = 'Marcos Oliveira';
            $_SESSION['email']      = $email;
            $_SESSION['perfil']     = 'MOTORISTA';
            $_SESSION['empresa_id'] = 1;

            return [
                'sucesso' => true,
                'destino' => 'indexMotorista.php'
            ];
        }

        // ==========================================================
        // REGRA 2: PERFIL EMPRESA / ADMINISTRATIVO (e-mails corporativos)
        // Se NÃO terminar com provedor pessoal gratuito, trata como corporativo
        // ==========================================================
        $dominiosPessoais = ['@gmail.com', '@hotmail.com', '@outlook.com', '@yahoo.com', '@icloud.com'];
        $ehEmailPessoal   = false;

        foreach ($dominiosPessoais as $dominio) {
            // str_ends_with() checa o final exato da string (ex: "ana@gmail.com" termina com "@gmail.com")
            if (str_ends_with($email, $dominio)) {
                $ehEmailPessoal = true;
                break; // Já descobriu que é pessoal, encerra o loop
            }
        }

        if (!$ehEmailPessoal) {
            $_SESSION['empresa_id'] = 1;
            $_SESSION['nome']       = 'Gestor BusTotal';
            $_SESSION['email']      = $email;
            $_SESSION['perfil']     = 'ADMINISTRATIVO';

            // Padronizado com headerEMP.php e menuLateralEMP.php
            return [
                'sucesso' => true,
                'destino' => 'indexEmpresa.php'
            ];
        }

        // ==========================================================
        // REGRA 3: PERFIL PASSAGEIRO (e-mails pessoais comuns)
        // ==========================================================
        $_SESSION['usuario_id'] = 3;
        $_SESSION['nome']       = 'Ana Clara Souza';
        $_SESSION['email']      = $email;
        $_SESSION['perfil']     = 'PASSAGEIRO';

        return [
            'sucesso' => true,
            'destino' => 'indexPassageiro.php'
        ];
    }

    /**
     * Encerra a sessão do usuário com segurança (Logout).
     */
    public static function logout(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_unset();   // Limpa todas as variáveis de $_SESSION
        session_destroy(); // Destrói a sessão no servidor
    }
}