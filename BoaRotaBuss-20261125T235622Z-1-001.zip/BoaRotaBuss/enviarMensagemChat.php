<?php
session_start();
require_once __DIR__ . '/classes/BancoJson.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empresa  = trim($_POST['empresa'] ?? '');
    $rota     = trim($_POST['rota'] ?? '');
    $nome     = trim($_POST['nome_interessado'] ?? '');
    $contato  = trim($_POST['contato_interessado'] ?? '');
    $mensagem = trim($_POST['mensagem'] ?? '');

    if ($nome !== '' && $mensagem !== '') {
        BancoJson::inserir('chat_atendimento', [
            'empresa'   => $empresa,
            'rota'      => $rota,
            'nome'      => $nome,
            'contato'   => $contato,
            'remetente' => 'PASSAGEIRO',
            'mensagem'  => $mensagem,
            'lida'      => 'N'
        ]);
    }
}

header('Location: index.php?chat=enviado');
exit;