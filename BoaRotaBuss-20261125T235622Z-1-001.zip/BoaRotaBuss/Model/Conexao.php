<?php
namespace App\Model;

use PDO;
use PDOException;

class Conexao {
    private static ?PDO $instancia = null;

    // Construtor privado impede dar "new Conexao()" fora da classe
    private function __construct() {}

    public static function getConexao(): PDO {
        if (self::$instancia === null) {
            $host = 'localhost';
            $banco = 'boarotabus_mvc';
                $usuario = 'root';
            $senha = '';
            try {
                $dsn = "mysql:host={$host};dbname={$banco};charset=utf8mb4";
                self::$instancia = new PDO($dsn, $usuario, $senha, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]);
            } catch (PDOException $e) {
                die("Erro ao conectar ao banco de dados: " . $e->getMessage());
            }
        }
        return self::$instancia;
    }
}