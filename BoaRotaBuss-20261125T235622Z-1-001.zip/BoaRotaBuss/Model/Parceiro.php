<?php
namespace App\Model;

class Parceiro {
    private ?int $id;
    private string $nome;
    private ?string $categoria;
    private ?string $siteProprio;
    private ?string $descricao;
    private string $tipo;

    public function __construct(
        string $nome = '',
        ?string $categoria = null,
        ?string $siteProprio = null,
        ?string $descricao = null,
        string $tipo = 'PARCEIRO',
        ?int $id = null
    ) {
        $this->id = $id;
        $this->nome = $nome;
        $this->categoria = $categoria;
        $this->siteProprio = $siteProprio;
        $this->descricao = $descricao;
        $this->tipo = $tipo;
    }

    public function getId(): ?int { return $this->id; }
    public function setId(?int $id): void { $this->id = $id; }

    public function getNome(): string { return $this->nome; }
    public function setNome(string $nome): void { $this->nome = $nome; }

    public function getCategoria(): ?string { return $this->categoria; }
    public function setCategoria(?string $categoria): void { $this->categoria = $categoria; }

    public function getSiteProprio(): ?string { return $this->siteProprio; }
    public function setSiteProprio(?string $siteProprio): void { $this->siteProprio = $siteProprio; }

    public function getDescricao(): ?string { return $this->descricao; }
    public function setDescricao(?string $descricao): void { $this->descricao = $descricao; }

    public function getTipo(): string { return $this->tipo; }
    public function setTipo(string $tipo): void { $this->tipo = $tipo; }
}