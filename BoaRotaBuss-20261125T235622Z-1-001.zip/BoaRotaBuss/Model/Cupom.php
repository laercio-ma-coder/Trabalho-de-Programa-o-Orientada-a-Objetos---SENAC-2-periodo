<?php
namespace App\Model;

class Cupom {
    private ?int $id;
    private int $parceiroFk;
    private string $codigo;
    private string $desconto;
    private ?string $validade;
    private ?string $descricao;
    private ?int $quantidadeLimite;
    private string $status;
    private ?string $nomeParceiro;

    public function __construct(
        int $parceiroFk = 0,
        string $codigo = '',
        string $desconto = '',
        ?string $validade = null,
        ?string $descricao = null,
        ?int $quantidadeLimite = null,
        string $status = 'ATIVO',
        ?int $id = null,
        ?string $nomeParceiro = null
    ) {
        $this->id = $id;
        $this->parceiroFk = $parceiroFk;
        $this->codigo = strtoupper(trim($codigo));
        $this->desconto = $desconto;
        $this->validade = $validade;
        $this->descricao = $descricao;
        $this->quantidadeLimite = $quantidadeLimite;
        $this->status = $status;
        $this->nomeParceiro = $nomeParceiro;
    }

    public function getId(): ?int { return $this->id; }
    public function setId(?int $id): void { $this->id = $id; }

    public function getParceiroFk(): int { return $this->parceiroFk; }
    public function setParceiroFk(int $parceiroFk): void { $this->parceiroFk = $parceiroFk; }

    public function getCodigo(): string { return $this->codigo; }
    public function setCodigo(string $codigo): void { $this->codigo = strtoupper(trim($codigo)); }

    public function getDesconto(): string { return $this->desconto; }
    public function setDesconto(string $desconto): void { $this->desconto = $desconto; }

    public function getValidade(): ?string { return $this->validade; }
    public function setValidade(?string $validade): void { $this->validade = $validade; }

    public function getDescricao(): ?string { return $this->descricao; }
    public function setDescricao(?string $descricao): void { $this->descricao = $descricao; }

    public function getQuantidadeLimite(): ?int { return $this->quantidadeLimite; }
    public function setQuantidadeLimite(?int $quantidadeLimite): void { $this->quantidadeLimite = $quantidadeLimite; }

    public function getStatus(): string { return $this->status; }
    public function setStatus(string $status): void { $this->status = $status; }

    public function getNomeParceiro(): ?string { return $this->nomeParceiro; }
    public function setNomeParceiro(?string $nomeParceiro): void { $this->nomeParceiro = $nomeParceiro; }
}