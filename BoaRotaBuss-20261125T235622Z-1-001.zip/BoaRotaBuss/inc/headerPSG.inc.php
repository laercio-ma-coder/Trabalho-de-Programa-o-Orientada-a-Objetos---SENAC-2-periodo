<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoaRotaBuss — Área do Passageiro</title>
    <!-- Folha de estilos exclusiva do perfil Passageiro -->
    <link rel="stylesheet" href="css/stylePSG.css">
</head>
<body class="tela-passageiro">

<header class="cabecalho">
    <!-- Bloco esquerdo corrigido: a tag <a> da logo agora fecha antes de abrir o link "Home" -->
    <div class="marca-header" style="display: flex; align-items: center; gap: 8px;">
        <a href="index.php" title="Voltar para a Página Inicial" style="display: inline-flex; align-items: center;">
            <img class="logo" src="img/BRB.png" alt="Logo do BoaRotaBuss">
        </a>
        <a class="buttonnv" href="indexPassageiro.php" title="Minha Viagem">Home</a>
    </div>

    <!-- Botão hambúrguer responsivo controlado via JavaScript -->
    <button class="menu-toggle" id="menu-toggle" aria-label="Abrir menu" aria-expanded="false">☰</button>

    <!-- Navegação direita padronizada -->
    <nav class="menu" id="menu">
        <a class="buttonnv" href="empresas.php">Empresas</a>
        <a class="buttonnv" href="perfilPSG.php">Perfil</a>
        <a class="buttonnv" id="configura" href="confgPSG.php" title="Configurações" aria-label="Configurações">⚙️</a>
        <a class="buttonnv sair-psg" href="indexLoginPassageiro.php">Sair</a>
    </nav>
</header>