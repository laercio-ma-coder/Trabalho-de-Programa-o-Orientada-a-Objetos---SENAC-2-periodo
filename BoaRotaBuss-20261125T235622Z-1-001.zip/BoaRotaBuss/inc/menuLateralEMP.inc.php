<?php
// Captura apenas o nome do arquivo PHP atual que está sendo executado no servidor
// Exemplo: se a URL for .../ViagemEMP.php, $paginaAtual recebe "ViagemEMP.php"
$paginaAtual = basename($_SERVER['PHP_SELF']);
?>

<!-- Barra de navegação lateral fixa do perfil Empresa -->
<aside class="menuLateral" id="menuLateral" aria-label="Menu de navegação da empresa">
    <ul>
        <!-- O operador ternário (? :) verifica qual página está aberta e aplica a classe CSS .ativo -->
        <li>
            <a class="bttMenu <?= ($paginaAtual == 'indexEmpresarial.php' || $paginaAtual == 'indexEmpresarial.php') ? 'ativo' : '' ?>" href="indexEmpresarial.php">
                Início / Painel
            </a>
        </li>
        <li>
            <a class="bttMenu <?= in_array($paginaAtual, ['ViagemEMP.php', 'CadViagemEMP.php', 'HistViagemEMP.php']) ? 'ativo' : '' ?>" href="ViagemEMP.php">
                Viagens
            </a>
        </li>
        <li>
            <a class="bttMenu <?= ($paginaAtual == 'PassageiroEMP.php') ? 'ativo' : '' ?>" href="PassageiroEMP.php">
                Passageiros
            </a>
        </li>
        <li>
            <a class="bttMenu <?= in_array($paginaAtual, ['OnibusEMP.php', 'CadOnibusEMP.php']) ? 'ativo' : '' ?>" href="OnibusEMP.php">
                Frota / Ônibus
            </a>
        </li>
        <li>
            <a class="bttMenu <?= in_array($paginaAtual, ['MotoristaEMP.php', 'CadMotoristaEMP.php']) ? 'ativo' : '' ?>" href="MotoristaEMP.php">
                Colaboradores
            </a>
        </li>
        <li>
            <a class="bttMenu <?= in_array($paginaAtual, ['ParceiroEMP.php', 'CadParceiroEMP.php']) ? 'ativo' : '' ?>" href="ParceiroEMP.php">
                Parceiros e Cupons
            </a>
        </li>
        <li>
            <a class="bttMenu <?= ($paginaAtual == 'AvaliacaoEMP.php') ? 'ativo' : '' ?>" href="AvaliacaoEMP.php">
                Avaliações
            </a>
        </li>
    </ul>

    <!-- Grupo separado na parte inferior do menu para encerrar a sessão -->
    <ul>
        <li>
            <a class="bttMenu sair-menu" href="indexLoginEmpresa.php">Sair do Sistema</a>
        </li>
    </ul>
</aside>