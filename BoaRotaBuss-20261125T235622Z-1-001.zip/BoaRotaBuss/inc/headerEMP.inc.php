<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <!-- Define codificação UTF-8 para suportar acentos e cedilha corretamente -->
    <meta charset="UTF-8">
    <!-- Faz o layout se adaptar à largura da tela em celulares e tablets -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título exibido na aba do navegador -->
    <title>BoaRotaBuss — Painel da Empresa</title>
    <!-- Carrega a folha de estilos exclusiva do perfil Empresa -->
    <link rel="stylesheet" href="css/styleEMP.css">
</head>
<body class="tela-empresa">

<!-- Cabeçalho fixo no topo da página -->
<header class="cabecalho">
    <!-- Bloco esquerdo: Logotipo + Identificação do Perfil + Atalho para o Painel -->
    <div class="marca-header" style="display: flex; align-items: center; gap: 8px;">
        <a href="index.php" title="Voltar para a Página Inicial" style="display: inline-flex; align-items: center;">
            <img class="logo" src="img/BRB.png" alt="Logo do BoaRotaBuss">
        </a>
        <!-- Badge visual para deixar claro em qual perfil o usuário está logado -->
        <a class="buttonnv" href="indexEmpresa.php" title="Início do Painel Corporativo">EMPRESA</a>
    </div>

    <!-- Botão hambúrguer exibido apenas em telas pequenas (mobile) via CSS -->
    <button class="menu-toggle" id="menu-toggle" aria-label="Abrir menu" aria-expanded="false">☰</button>

    <!-- Barra de navegação principal do perfil Empresa -->
    <nav class="menu" id="menu">
        <a class="buttonnv" href="perfilEMP.php">Perfil</a>
        <a class="buttonnv" id="configura" href="confgEMP.php" title="Configurações" aria-label="Configurações">⚙️</a>
        <a class="buttonnv sair-topo" href="indexLoginEmpresa.php">Sair</a>
    </nav>
</header>