<!-- ==========================================================
     RODAPÉ DO PAINEL CORPORATIVO (EMPRESA)
     ========================================================== -->
<footer>
    <div class="footer-conteudo">
        <p><strong>Contato:</strong> contato@boarotabuss.com.br • (42) 3220-4500</p>
        <p>© 2026 BoaRotaBuss. Todos os direitos reservados.</p>
    </div>
</footer>

<!-- ==========================================================
     SCRIPTS GLOBAIS DO PAINEL DA EMPRESA
     ========================================================== -->
<script>
    // 1. Mantém o Modo Escuro ativo entre todas as páginas da empresa usando localStorage
    if (localStorage.getItem('brb_dark_emp') === '1') {
        document.body.classList.add('modo-escuro-emp');
    }

    // 2. Controle do menu mobile no cabeçalho da empresa
    const menuToggle = document.getElementById('menu-toggle');
    const menuNav = document.getElementById('menu');

    if (menuToggle && menuNav) {
        menuToggle.addEventListener('click', () => {
            const aberto = menuNav.classList.toggle('aberto');
            menuToggle.setAttribute('aria-expanded', aberto);
        });
    }
</script>
</body>
</html>