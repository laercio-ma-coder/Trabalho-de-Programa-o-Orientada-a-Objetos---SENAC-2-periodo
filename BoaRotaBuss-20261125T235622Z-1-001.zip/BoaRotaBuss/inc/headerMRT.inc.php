<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoaRotaBuss — Painel do Motorista</title>
    <!-- Removido styleEMP.css para evitar conflitos; o parâmetro ?v= força o navegador a carregar o CSS atualizado sem cache antigo -->
    <link rel="stylesheet" href="css/styleMTR.css?v=<?php echo time(); ?>">
</head>
<body class="tela-motorista">

<header class="cabecalho">
    <!-- Bloco esquerdo: Logo + Badge clicável que leva ao painel principal do motorista -->
    <div class="marca-mtr" style="display: flex; align-items: center; gap: 8px;">
        <a href="index.php" title="Voltar para a Página Inicial" style="display: inline-flex; align-items: center;">
            <img class="logo" src="img/BRB.png" alt="Logo do BoaRotaBuss">
        </a>
        <span class="badge-perfil-mtr">
            <a href="indexMotorista.php" title="Início do Painel do Motorista">MOTORISTA</a>
        </span>
    </div>

    <!-- Botão hambúrguer para dispositivos móveis -->
    <button class="menu-toggle" id="menu-toggle" aria-label="Abrir menu" aria-expanded="false">☰</button>

    <!-- Navegação direita padronizada com Perfil, Engrenagem de Configurações e Sair -->
    <nav class="menu" id="menu">
        <a class="buttonnv" href="perfilMTR.php">Perfil</a>
        <a class="buttonnv" id="configura" href="confgMTR.php" title="Configurações" aria-label="Configurações">⚙️</a>
        <a class="buttonnv sair-mtr" href="indexLoginPassageiro.php">Sair</a>
    </nav>
</header>