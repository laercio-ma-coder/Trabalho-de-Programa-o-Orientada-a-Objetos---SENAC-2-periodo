<!-- ==========================================================
     RODAPÉ PADRÃO DO SISTEMA (PASSAGEIRO E MOTORISTA)
     ========================================================== -->
<footer>
    <div class="footer-conteudo">
        <p><strong>Contato:</strong> contato@boarotabuss.com.br • (42) 3220-4500</p>
        <p>© 2026 BoaRotaBuss. Todos os direitos reservados.</p>
    </div>

    <!-- Botão de emergência fixado no canto direito do rodapé -->
    <button type="button" class="emergencias" id="btnEmergencias" title="Contatos de Emergência" aria-label="Botão para contatos de emergência">!</button>
</footer>

<!-- ==========================================================
     MODAL DE CONTATOS DE EMERGÊNCIA 24H
     role="dialog" e aria-modal="true" melhoram a acessibilidade para leitores de tela
     ========================================================== -->
<div class="modal-overlay escondido" id="modalEmergencia" role="dialog" aria-modal="true" aria-labelledby="tituloEmergencia">
    <div class="modal-emergencia-box">
        <div class="topo-modal-emergencia">
            <div>
                <span class="tag-urgencia">Atendimento Imediato 24h</span>
                <h2 id="tituloEmergencia">Contatos de Emergência</h2>
            </div>
            <button type="button" class="btn-fechar-modal" id="btnFecharEmergencia" aria-label="Fechar janela">×</button>
        </div>

        <p class="texto-modal-emergencia">
            Em caso de acidente, mal-estar a bordo ou situação de risco durante a viagem, acione imediatamente um dos serviços abaixo:
        </p>

        <!-- Lista de telefones com protocolo tel: (abre o discador direto no celular) -->
        <div class="lista-contatos-emergencia">
            <a href="tel:190" class="card-contato-emergencia policia">
                <div>
                    <strong>Polícia Militar</strong>
                    <span>Segurança pública e ocorrências policiais</span>
                </div>
                <span class="numero-emergencia">190</span>
            </a>

            <a href="tel:193" class="card-contato-emergencia bombeiro">
                <div>
                    <strong>Corpo de Bombeiros</strong>
                    <span>Resgate, incêndios e salvamento</span>
                </div>
                <span class="numero-emergencia">193</span>
            </a>

            <a href="tel:192" class="card-contato-emergencia hospital">
                <div>
                    <strong>SAMU / Hospital & Ambulância</strong>
                    <span>Atendimento médico de urgência</span>
                </div>
                <span class="numero-emergencia">192</span>
            </a>

            <a href="tel:191" class="card-contato-emergencia prf">
                <div>
                    <strong>Polícia Rodoviária Federal (PRF)</strong>
                    <span>Emergências em rodovias federais</span>
                </div>
                <span class="numero-emergencia">191</span>
            </a>

            <a href="tel:08007772026" class="card-contato-emergencia central">
                <div>
                    <strong>Plantão Operacional BoaRotaBuss</strong>
                    <span>Suporte direto ao passageiro e motorista em trânsito</span>
                </div>
                <span class="numero-emergencia">0800 777 2026</span>
            </a>
        </div>
    </div>
</div>

<!-- ==========================================================
     SCRIPT DE CONTROLE DO MODAL E DO MENU MOBILE
     ========================================================== -->
<script>
    // 1. Controle de abertura e fechamento do Modal de Emergência
    const btnEmergencias = document.getElementById('btnEmergencias');
    const modalEmergencia = document.getElementById('modalEmergencia');
    const btnFecharEmergencia = document.getElementById('btnFecharEmergencia');

    if (btnEmergencias && modalEmergencia) {
        // Abre o modal removendo a classe .escondido
        btnEmergencias.addEventListener('click', () => {
            modalEmergencia.classList.remove('escondido');
        });

        // Fecha ao clicar no botão "×"
        btnFecharEmergencia.addEventListener('click', () => {
            modalEmergencia.classList.add('escondido');
        });

        // Fecha ao clicar fora da caixa branca (no fundo escuro)
        modalEmergencia.addEventListener('click', (e) => {
            if (e.target === modalEmergencia) {
                modalEmergencia.classList.add('escondido');
            }
        });

        // Fecha ao pressionar a tecla ESC no teclado
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                modalEmergencia.classList.add('escondido');
            }
        });
    }

    // 2. Controle do botão hambúrguer no cabeçalho (telas mobile)
    const menuToggle = document.getElementById('menu-toggle');
    const menuNav = document.getElementById('menu');

    if (menuToggle && menuNav) {
        menuToggle.addEventListener('click', () => {
            const aberto = menuNav.classList.toggle('aberto');
            menuToggle.setAttribute('aria-expanded', aberto);
        });
    }
</script>
</body>
</html>