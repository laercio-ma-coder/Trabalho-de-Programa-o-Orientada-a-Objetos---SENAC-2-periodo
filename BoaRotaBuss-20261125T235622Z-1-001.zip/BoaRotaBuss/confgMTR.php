<?php include 'inc/headerMRT.inc.php'; ?>

<main class="pagina">
    <!-- Botão flutuante padronizado para voltar ao painel da viagem -->
    <a class="retorar" href="indexMotorista.php" aria-label="Voltar para Minha Viagem"><</a>

    <section class="card">
        <span class="badge-perfil-mtr">PREFERÊNCIAS DO PAINEL</span>
        <h2 class="titulo-painel">Configurações do Motorista</h2>
        <p class="subtitulo-painel">Ajuste as preferências operacionais do aplicativo durante a viagem.</p>

        <!-- ==========================================================
             PREFERÊNCIAS OPERACIONAIS SALVAS NO NAVEGADOR (LOCALSTORAGE)
             ========================================================== -->
        <div class="lista-config-mtr">
            <label class="item-config-mtr">
                <div>
                    <strong>Modo Direção Noturna (Baixo Brilho)</strong>
                    <small>Escurece ainda mais os painéis para não ofuscar a visão na estrada à noite.</small>
                </div>
                <input type="checkbox" id="cfg-noturno">
            </label>

            <label class="item-config-mtr">
                <div>
                    <strong>Alerta Sonoro de Novo Embarque / QR Code</strong>
                    <small>Emite um aviso sonoro sempre que um passageiro validar a passagem.</small>
                </div>
                <input type="checkbox" id="cfg-som" checked>
            </label>

            <label class="item-config-mtr">
                <div>
                    <strong>Compartilhar Localização em Tempo Real</strong>
                    <small>Permite que passageiros e a central da empresa acompanhem o trajeto no mapa.</small>
                </div>
                <input type="checkbox" id="cfg-gps" checked>
            </label>
        </div>

        <hr class="divisor-mtr">

        <!-- ==========================================================
             ALTERAÇÃO DE SENHA CORPORATIVA DO MOTORISTA
             ========================================================== -->
        <h3 class="titulo-sub-mtr">Segurança e Senha Corporativa</h3>
        <form action="alterarSenhaMotorista.php" method="post">
            <div class="campo">
                <label class="dados" for="senha-atual-mtr">Senha Atual</label>
                <input class="input" type="password" id="senha-atual-mtr" name="senha_atual" placeholder="Digite sua senha atual" required>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="nova-senha-mtr">Nova Senha</label>
                    <input class="input" type="password" id="nova-senha-mtr" name="nova_senha" placeholder="Mínimo 8 caracteres" required>
                </div>
                <div class="campo">
                    <label class="dados" for="confirma-senha-mtr">Confirmar Nova Senha</label>
                    <input class="input" type="password" id="confirma-senha-mtr" name="confirma_senha" placeholder="Repita a nova senha" required>
                </div>
            </div>

            <div class="botoes">
                <button type="submit" class="buttonLGN">Atualizar Senha</button>
                <a href="indexMotorista.php" class="buttonLGN secundario-mtr">Voltar para Minha Viagem</a>
            </div>
        </form>
    </section>
</main>

<script>
    // Sincroniza os 3 interruptores operacionais com o localStorage do dispositivo do motorista
    const chkNoturno = document.getElementById('cfg-noturno');
    const chkSom     = document.getElementById('cfg-som');
    const chkGps     = document.getElementById('cfg-gps');

    // Restaura estados salvos ao abrir a tela
    if (localStorage.getItem('mtr_noturno') === '1') {
        chkNoturno.checked = true;
        document.body.classList.add('modo-direcao-noturna');
    }
    if (localStorage.getItem('mtr_som') !== null) {
        chkSom.checked = localStorage.getItem('mtr_som') === '1';
    }
    if (localStorage.getItem('mtr_gps') !== null) {
        chkGps.checked = localStorage.getItem('mtr_gps') === '1';
    }

    // Grava cada alteração imediatamente
    chkNoturno.addEventListener('change', () => {
        document.body.classList.toggle('modo-direcao-noturna', chkNoturno.checked);
        localStorage.setItem('mtr_noturno', chkNoturno.checked ? '1' : '0');
    });

    chkSom.addEventListener('change', () => {
        localStorage.setItem('mtr_som', chkSom.checked ? '1' : '0');
    });

    chkGps.addEventListener('change', () => {
        localStorage.setItem('mtr_gps', chkGps.checked ? '1' : '0');
    });
</script>

<?php include 'inc/footer.inc.php'; ?>