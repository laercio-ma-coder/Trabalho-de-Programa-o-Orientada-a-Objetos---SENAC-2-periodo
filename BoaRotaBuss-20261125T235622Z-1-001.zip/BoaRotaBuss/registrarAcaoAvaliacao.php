<?php
session_start();
require_once __DIR__ . '/classes/BancoJson.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id   = (int) ($_POST['avaliacao_id'] ?? 0);
    $acao = trim($_POST['acao_gestao'] ?? '');

    if ($id > 0 && $acao !== '') {
        $avaliacoes = BancoJson::ler('avaliacoes');
        foreach ($avaliacoes as &$av) {
            if ((int) $av['id'] === $id) {
                $av['status_gestao'] = 'RESOLVIDO';
                $av['acao_gestao']   = $acao;
                $av['resolvido_em']  = date('d/m/Y H:i');
                break;
            }
        }
        unset($av);
        BancoJson::salvar('avaliacoes', $avaliacoes);
    }
}

$volta = $_SERVER['HTTP_REFERER'] ?? 'avaliacoesEMP.php';
header('Location: ' . $volta);
exit;