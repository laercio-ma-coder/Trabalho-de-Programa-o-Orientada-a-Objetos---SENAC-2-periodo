<?php include 'inc/headerEMP.inc.php'; ?>

<?php include 'inc/menuLateralEMP.inc.php'; ?>

<main class="tela">

    <!-- CADASTRAR CUPOM -->
    <section class="cadastrarCupon card">
        <h2 class="title">Cadastrar cupom</h2>

        <form action="salvarCupom.php" method="post">
            <div class="linha">
                <div class="campo">
                    <label class="dados" for="cp-codigo">Código</label>
                    <input class="input" type="text" id="cp-codigo" name="codigo"
                           placeholder="Ex.: BRB10" maxlength="50" required>
                </div>
                <div class="campo">
                    <label class="dados" for="cp-desconto">Desconto</label>
                    <input class="input" type="text" id="cp-desconto" name="desconto"
                           placeholder="Ex.: 10% ou R$ 50" maxlength="100" required>
                </div>
            </div>

            <div class="campo">
                <label class="dados" for="cp-descricao">Descrição</label>
                <input class="input" type="text" id="cp-descricao" name="descricao"
                       placeholder="Do que se trata o cupom" maxlength="255">
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="cp-validade">Validade</label>
                    <input class="input" type="datetime-local" id="cp-validade" name="validade">
                </div>
                <div class="campo">
                    <label class="dados" for="cp-quantidade">Quantidade disponível</label>
                    <input class="input" type="number" id="cp-quantidade" name="quantidade" min="1"
                           placeholder="Ex.: 100">
                </div>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="cp-status">Status</label>
                    <select class="input" id="cp-status" name="status">
                        <option value="ATIVO">Ativo</option>
                        <option value="INATIVO">Inativo</option>
                    </select>
                </div>
                <div class="campo">
                    <label class="dados" for="cp-empresa">Empresa que disponibiliza</label>
                    <input class="input" type="text" id="cp-empresa" name="empresa"
                           value="<?= htmlspecialchars($_SESSION['empresa_nome'] ?? '') ?>" readonly>
                </div>
            </div>

            <div class="botoes">
                <button type="submit" class="buttonLGN">Salvar cupom</button>
                <button type="reset" class="buttonLGN secundario">Limpar</button>
            </div>
        </form>
    </section>

    <!-- DADOS DE USO -->
    <section class="dadosdeuso card">
        <h2 class="title">Dados de uso</h2>

        <div class="historicoCupom">
            <p class="dados">Histórico de uso</p>

            <div class="tabela-rolagem">
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>Nº</th>
                            <th>Código</th>
                            <th>Status</th>
                            <th>Usos</th>
                            <th>Validade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php /* foreach ($cupons as $c): */ ?>
                        <tr>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>
                        <?php /* endforeach; */ ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

</main>

<?php include 'inc/footerEMP.inc.php'; ?>