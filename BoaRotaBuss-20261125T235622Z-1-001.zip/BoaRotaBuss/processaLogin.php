<?php
session_start();
require_once __DIR__ . '/classes/Autenticador.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pega o e-mail e a senha independentemente do name usado no input HTML
    $email = $_POST['email'] ?? $_POST['usuario'] ?? $_POST['login'] ?? '';
    $senha = $_POST['senha'] ?? $_POST['password'] ?? '';

    $auth = new Autenticador();
    $resultado = $auth->login($email, $senha);

    if ($resultado['sucesso']) {
        header('Location: ' . $resultado['destino']);
        exit;
    }

    // Se falhar, volta para o login com aviso
    echo "<script>alert('" . addslashes($resultado['mensagem']) . "'); window.history.back();</script>";
    exit;
}

header('Location: indexLoginPassageiro.php');
exit;