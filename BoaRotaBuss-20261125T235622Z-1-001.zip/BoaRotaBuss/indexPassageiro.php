<?php include 'inc/headerPSG.inc.php'; ?>

<main class="pagina">

    <!-- Barra de navegação entre as 4 abas da viagem do passageiro -->
    <div class="ViButtons">
        <button type="button" class="buttonvi ativo" data-alvo="painel-dados">Dados da Passagem</button>
        <button type="button" class="buttonvi" data-alvo="painel-status">Status</button>
        <button type="button" class="buttonvi" data-alvo="painel-trajeto">Trajeto</button>
        <button type="button" class="buttonvi" data-alvo="painel-info">Informações</button>
    </div>

    <!-- ==========================================================
         ABA 1: DADOS DA PASSAGEM E CHECK-IN
         ========================================================== -->
    <section class="painel card" id="painel-dados">
        <h2 class="title">Minha Passagem</h2>
        <p class="subtitle">Consulte os dados do seu bilhete ou valide seu embarque.</p>

        <form action="" method="post">
            <div class="campo">
                <label class="dados" for="reg-nome">Nome completo</label>
                <input class="input" type="text" id="reg-nome" name="nome"
                       placeholder="Digite seu nome completo" required>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="ConfCPF">CPF</label>
                    <input class="input" type="text" id="ConfCPF" name="cpf"
                           placeholder="000.000.000-00" required>
                </div>
                <div class="campo">
                    <label class="dados" for="reg-NPASS">Número da Passagem</label>
                    <input class="input" type="text" id="reg-NPASS" name="numero_passagem"
                           placeholder="Ex: BRB-9001" required>
                </div>
            </div>

            <div class="botoes">
                <button type="submit" class="buttonLGN" id="verificar-btn">Verificar</button>
                <button type="button" class="buttonLGN secundario" id="ler-qr">Ler QR Code da Passagem</button>
            </div>
        </form>

        <!-- Lista de definição (<dl>) com os dados do bilhete encontrado -->
        <dl class="detalhes">
            <div><dt>Passageiro</dt><dd>—</dd></div>
            <div><dt>Passagem</dt><dd>—</dd></div>
            <div><dt>Data da viagem</dt><dd>—</dd></div>
            <div><dt>Embarque</dt><dd>—</dd></div>
            <div><dt>Assento</dt><dd>—</dd></div>
        </dl>
    </section>

    <!-- ==========================================================
         ABA 2: CONFIRMAÇÃO DE EMBARQUE DO PASSAGEIRO
         ========================================================== -->
    <section class="painel card" id="painel-status" hidden>
        <h2 class="title">Status de Embarque</h2>
        <p class="subtitle">Clique no botão abaixo quando já estiver acomodado na sua poltrona.</p>
        <button type="button" class="status-btn" id="btn-embarque" aria-pressed="false">
            Não embarcado
        </button>
    </section>

    <!-- ==========================================================
         ABA 3: MAPA E DETALHES DO TRAJETO
         ========================================================== -->
    <section class="painel card" id="painel-trajeto" hidden>
        <h2 class="title">Acompanhamento do Trajeto</h2>
        <p class="subtitle">Visualize a rota prevista e o tempo estimado até o destino.</p>

        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1843210.5!2d-52.5!3d-25.2!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94dce12345678901%3A0x1234567890123456!2sBR-277%20Paran%C3%A1!5e0!3m2!1spt-BR!2sbr!4v1234567890123"
                    title="Mapa do trajeto" allowfullscreen loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

        <dl class="detalhes">
            <div><dt>Origem</dt><dd>Ponta Grossa - PR</dd></div>
            <div><dt>Destino</dt><dd>Foz do Iguaçu - PR</dd></div>
            <div><dt>Duração Estimada</dt><dd>07h 25min</dd></div>
        </dl>
    </section>

    <!-- ==========================================================
         ABA 4: GUIA TURÍSTICO DO DESTINO E PARCEIROS DE DESCONTO
         ========================================================== -->
    <section class="painel card card-largo" id="painel-info" hidden>
        <h2 class="title">Informações do Destino e Parceiros</h2>

        <div class="navegacao-botoes">
            <button type="button" class="buttonLGN" id="anterior">← Anterior</button>
            <button type="button" class="buttonLGN" id="proximo">Próximo →</button>
        </div>

        <div class="tela slide">
            <div class="cenario">
                <img src="img/cenario.jpg" alt="Cataratas do Iguaçu">
            </div>
            <div class="conteudo">
                <h2 class="titulo-historia">O "Descobrimento" Europeu (1542)</h2>
                <ul class="texto-historia">
                    <li><strong>Álvar Núñez Cabeza de Vaca:</strong> primeiro europeu a documentar as quedas, em 31 de janeiro de 1542.</li>
                    <li><strong>A Rota:</strong> descia o rio de canoa buscando um caminho entre Santa Catarina e Assunção.</li>
                    <li><strong>O Registro:</strong> impressionado, batizou o local de Saltos de Santa Maria.</li>
                </ul>
            </div>
        </div>

        <!-- Links externos para parceiros e botão corrigido para a página interna de cupons -->
        <div class="linksP">
            <a href="https://www.airbnb.com.br/" class="link logo-airbnb" target="_blank" rel="noopener">Airbnb</a>
            <a href="https://www.decolar.com/" class="link logo-decolar" target="_blank" rel="noopener">Decolar</a>
            <a href="#" class="link logo-befly" target="_blank" rel="noopener">BeFly</a>
            <a href="#" class="link logo-azul" target="_blank" rel="noopener">Azul Viagens</a>
            <a href="Desconto.php" class="buttonLGN" id="descontosDisponiveis">Aba de Descontos</a>
        </div>
    </section>

</main>

<!-- Lógica interativa da área do passageiro (abas, validação, status e carrossel) -->
<script src="js/passageiro.js"></script>

<!-- O controle do menu mobile (#menu-toggle) já é carregado automaticamente dentro do footer.inc.php -->
<?php include 'inc/footer.inc.php'; ?>