<?php
// Garante que a sessão esteja iniciada para identificar o gestor logado
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Importa o repositório JSON e lê as mensagens enviadas pelos interessados na vitrine (index.php)
// array_reverse() coloca as mensagens mais recentes no topo da lista
require_once __DIR__ . '/classes/BancoJson.php';
$mensagensChat = array_reverse(BancoJson::ler('chat_atendimento'));
?>
<?php include 'inc/headerEMP.inc.php'; ?>
<?php include 'inc/menuLateralEMP.inc.php'; ?>

<main class="tela">
    <h1 class="title">Painel Operacional — BoaRotaBuss</h1>
    <p class="subtitle">Acompanhe atendimentos da vitrine, cadastros rápidos e viagens em andamento.</p>

    <!-- ==========================================================
         SEÇÃO 1: INBOX DE MENSAGENS VINDAS DA VITRINE (index.php)
         ========================================================== -->
    <section class="secao-monitoramento" style="margin-top: 0; padding-top: 0; border-top: none;">
        <div class="topo-monitoramento">
            <h2 class="subtitulo-secao">Chat com Interessados (Vitrine Pública)</h2>
            <span class="link-ver-todas"><?= count($mensagensChat) ?> mensagem(ns)</span>
        </div>

        <?php if (empty($mensagensChat)): ?>
            <p class="descricao-bloco">Nenhuma mensagem recebida pela vitrine até o momento.</p>
        <?php else: ?>
            <div class="lista-viagens-cadastradas">
                <?php foreach ($mensagensChat as $msg): ?>
                    <div class="card-avaliacao">
                        <div class="cabecalho-avaliacao">
                            <div>
                                <!-- htmlspecialchars() protege contra ataques XSS ao exibir textos digitados por usuários -->
                                <strong class="viagem-avaliada"><?= htmlspecialchars($msg['nome']) ?></strong>
                                <span class="data-avaliacao"> • Contato: <?= htmlspecialchars($msg['contato']) ?></span>
                            </div>
                            <span class="nota-geral"><?= htmlspecialchars($msg['rota']) ?> • <?= htmlspecialchars($msg['criado_em']) ?></span>
                        </div>

                        <div class="comentario-avaliacao" style="margin-bottom: 8px;">
                            <p>"<?= htmlspecialchars($msg['mensagem']) ?>"</p>
                        </div>

                        <!-- Se a empresa já respondeu, mostra a resposta; senão, exibe o formulário para responder -->
                        <?php if (!empty($msg['resposta_empresa'])): ?>
                            <div class="comentario-avaliacao" style="border-left: 4px solid var(--piscina-destaque);">
                                <strong>Respondido em <?= htmlspecialchars($msg['respondido_em']) ?>:</strong>
                                <p><?= htmlspecialchars($msg['resposta_empresa']) ?></p>
                            </div>
                        <?php else: ?>
                            <form action="responderChatEmpresa.php" method="post" class="linha" style="align-items: center;">
                                <input type="hidden" name="id_original" value="<?= (int) $msg['id'] ?>">
                                <input class="input" type="text" name="resposta" placeholder="Escreva a resposta para este viajante..." required>
                                <button type="submit" class="buttonLGN" style="flex: none;">Responder</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- ==========================================================
         SEÇÃO 2: ATALHOS RÁPIDOS DE GESTÃO
         ========================================================== -->
    <div class="secao-monitoramento">
        <h2 class="subtitulo-secao">Ações Rápidas</h2>
        <ul class="grade-acoes">
            <li><a href="PassageiroEMP.php" class="cardADD">Gerenciar passageiros</a></li>
            <li><a href="CadViagemEMP.php" class="cardADD">Cadastrar viagem</a></li>
            <li><a href="MotoristaEMP.php" class="cardADD">Adicionar motorista</a></li>
            <li><a href="OnibusEMP.php" class="cardADD">Adicionar ônibus</a></li>
            <li><a href="ParceiroEMP.php" class="cardADD">Adicionar parceiro</a></li>
        </ul>
    </div>

    <!-- ==========================================================
         SEÇÃO 3: MONITORAMENTO DE VIAGENS EM TEMPO REAL
         ========================================================== -->
    <div class="secao-monitoramento">
        <div class="topo-monitoramento">
            <h2 class="subtitulo-secao">Viagens em Andamento / Hoje</h2>
            <a href="ViagemEMP.php" class="link-ver-todas">Ver todas →</a>
        </div>

        <div class="lista-viagens-ativas">
            <div class="card-viagem-ativa">
                <div class="info-viagem">
                    <span class="badge-status em-andamento">Em Trânsito</span>
                    <h3>Ponta Grossa → Foz do Iguaçu</h3>
                    <p><strong>Saída:</strong> 08:00 | <strong>Ônibus:</strong> Marcopolo Paradiso G8 (ABC-1D23)</p>
                    <p><strong>Embarques:</strong> 30 / 36 passageiros confirmados</p>
                </div>
                <div class="acoes-viagem">
                    <a href="ViagemEMP.php" class="btn-operacao">Acompanhar Viagem</a>
                    <a href="AvaliacaoEMP.php" class="btn-operacao aviso-btn">Ver Avaliações</a>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'inc/footerEMP.inc.php'; ?>