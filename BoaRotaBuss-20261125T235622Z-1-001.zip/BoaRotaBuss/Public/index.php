<?php
// Carregamento direto das classes a partir da raiz do projeto BoaRotaBuss
require_once __DIR__ . '/../Model/Conexao.php';
require_once __DIR__ . '/../Model/Parceiro.php';
require_once __DIR__ . '/../Model/Cupom.php';
require_once __DIR__ . '/../DAO/ParceiroDAO.php';
require_once __DIR__ . '/../DAO/CupomDAO.php';
require_once __DIR__ . '/../Controller/ParceiroController.php';
require_once __DIR__ . '/../Controller/CupomController.php';

use App\Controller\ParceiroController;
use App\Controller\CupomController;

$parceiroCtrl = new ParceiroController();
$cupomCtrl = new CupomController();

$mensagem = null;
$erro = null;
$parceiroEdit = null;
$cupomEdit = null;

try {
    // Processamento de formulários (POST)
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        if ($acao === 'salvar_parceiro') {
            $mensagem = $parceiroCtrl->salvar($_POST);
        } elseif ($acao === 'salvar_cupom') {
            $mensagem = $cupomCtrl->salvar($_POST);
        }
    }

    // Ações via URL (GET: editar ou excluir)
    if (isset($_GET['excluir_parceiro'])) {
        $mensagem = $parceiroCtrl->excluir((int)$_GET['excluir_parceiro']);
    }
    if (isset($_GET['excluir_cupom'])) {
        $mensagem = $cupomCtrl->excluir((int)$_GET['excluir_cupom']);
    }
    if (isset($_GET['editar_parceiro'])) {
        $parceiroEdit = $parceiroCtrl->buscar((int)$_GET['editar_parceiro']);
    }
    if (isset($_GET['editar_cupom'])) {
        $cupomEdit = $cupomCtrl->buscar((int)$_GET['editar_cupom']);
    }
} catch (Exception $e) {
    $erro = $e->getMessage();
}

$parceiros = $parceiroCtrl->listar();
$cupons = $cupomCtrl->listar();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoaRotaBuss — Gestão de Parceiros e Cupons (MVC + DAO)</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; }
        body { background: #041e29; color: #062b38; padding: 24px; }
        .container { max-width: 1200px; margin: 0 auto; }
        header { background: #073140; color: #fff; padding: 20px 26px; border-radius: 16px; margin-bottom: 20px; border: 1px solid #0e7f94; }
        header h1 { font-size: 1.5rem; }
        header p { color: #9ad8e6; font-size: 0.9rem; margin-top: 4px; }
        .alerta { padding: 12px 16px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
        .sucesso { background: #d1fae5; color: #065f46; border: 1px solid #10b981; }
        .erro { background: #fee2e2; color: #991b1b; border: 1px solid #ef4444; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 22px; }
        @media (max-width: 900px) { .grid { grid-template-columns: 1fr; } }
        .card { background: #ffffff; border-radius: 16px; padding: 22px; box-shadow: 0 12px 30px rgba(0,0,0,0.3); }
        .card h2 { color: #073140; margin-bottom: 14px; font-size: 1.2rem; border-bottom: 2px solid #e2f1f5; padding-bottom: 8px; }
        label { display: block; font-size: 0.82rem; font-weight: 700; margin-top: 10px; color: #0a485c; }
        input, select, textarea { width: 100%; padding: 9px 11px; margin-top: 4px; border: 1px solid #b8d8e0; border-radius: 8px; font-size: 0.9rem; }
        .botoes { display: flex; gap: 10px; margin-top: 14px; }
        .btn { padding: 10px 16px; border-radius: 8px; border: none; font-weight: 700; cursor: pointer; text-decoration: none; font-size: 0.85rem; display: inline-block; text-align: center; }
        .btn-primario { background: #0e7f94; color: #ffffff; flex: 1; }
        .btn-primario:hover { background: #096375; }
        .btn-secundario { background: #eef6f8; color: #073140; border: 1px solid #8ecad6; }
        .btn-editar { background: #e0f2fe; color: #0369a1; padding: 5px 10px; font-size: 0.78rem; }
        .btn-excluir { background: #fee2e2; color: #b91c1c; padding: 5px 10px; font-size: 0.78rem; }
        table { width: 100%; border-collapse: collapse; margin-top: 18px; font-size: 0.84rem; }
        th, td { text-align: left; padding: 9px 8px; border-bottom: 1px solid #e5eff2; }
        th { background: #f2f9fb; color: #073140; }
        .badge { padding: 3px 8px; border-radius: 999px; font-size: 0.72rem; font-weight: 700; }
        .ativo { background: #dcfce7; color: #166534; }
        .inativo { background: #f3f4f6; color: #4b5563; }
    </style>
</head>
<body>
<div class="container">
    <header>
        <h1>BoaRotaBuss — Rede de Parceiros & Cupons</h1>
        <p>Arquitetura POO + MVC + DAO (Relacionamento 1:N entre PARCEIRO e CUPOM)</p>
    </header>

    <?php if ($mensagem): ?>
        <div class="alerta sucesso"><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>
    <?php if ($erro): ?>
        <div class="alerta erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <div class="grid">
        <!-- COLUNA 1: TABELA PAI (PARCEIROS) -->
        <section class="card">
            <h2>1. Parceiros & Patrocinadores (Tabela Pai)</h2>
            <form method="POST" action="index.php">
                <input type="hidden" name="acao" value="salvar_parceiro">
                <input type="hidden" name="id" value="<?= $parceiroEdit?->getId() ?>">

                <label>Nome do Parceiro *</label>
                <input type="text" name="nome" required placeholder="Ex: Hotel Tarobá Foz"
                       value="<?= htmlspecialchars($parceiroEdit?->getNome() ?? '') ?>">

                <label>Categoria</label>
                <input type="text" name="categoria" placeholder="Ex: Hospedagem, Alimentação"
                       value="<?= htmlspecialchars($parceiroEdit?->getCategoria() ?? '') ?>">

                <label>Tipo de Vínculo</label>
                <select name="tipo">
                    <option value="PARCEIRO" <?= ($parceiroEdit?->getTipo() === 'PARCEIRO') ? 'selected' : '' ?>>PARCEIRO</option>
                    <option value="PATROCINADOR" <?= ($parceiroEdit?->getTipo() === 'PATROCINADOR') ? 'selected' : '' ?>>PATROCINADOR</option>
                </select>

                <label>Site Oficial</label>
                <input type="url" name="site_proprio" placeholder="https://..."
                       value="<?= htmlspecialchars($parceiroEdit?->getSiteProprio() ?? '') ?>">

                <label>Descrição do Benefício</label>
                <textarea name="descricao" rows="2"><?= htmlspecialchars($parceiroEdit?->getDescricao() ?? '') ?></textarea>

                <div class="botoes">
                    <button type="submit" class="btn btn-primario">
                        <?= $parceiroEdit ? 'Atualizar Parceiro' : 'Cadastrar Parceiro' ?>
                    </button>
                    <a href="index.php" class="btn btn-secundario">Limpar</a>
                </div>
            </form>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Parceiro</th>
                        <th>Tipo</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($parceiros as $p): ?>
                        <tr>
                            <td>#<?= $p->getId() ?></td>
                            <td>
                                <strong><?= htmlspecialchars($p->getNome()) ?></strong><br>
                                <small><?= htmlspecialchars($p->getCategoria() ?? '') ?></small>
                            </td>
                            <td><span class="badge ativo"><?= $p->getTipo() ?></span></td>
                            <td>
                                <a href="?editar_parceiro=<?= $p->getId() ?>" class="btn btn-editar">Editar</a>
                                <a href="?excluir_parceiro=<?= $p->getId() ?>" class="btn btn-excluir"
                                   onclick="return confirm('Excluir este parceiro apagará também os cupons dele. Confirmar?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- COLUNA 2: TABELA FILHO (CUPONS) -->
        <section class="card">
            <h2>2. Cupons Promocionais (Tabela Filho)</h2>
            <form method="POST" action="index.php">
                <input type="hidden" name="acao" value="salvar_cupom">
                <input type="hidden" name="id" value="<?= $cupomEdit?->getId() ?>">

                <label>Parceiro Vinculado (Chave Estrangeira) *</label>
                <select name="parceiro_fk" required>
                    <option value="">-- Selecione um Parceiro --</option>
                    <?php foreach ($parceiros as $p): ?>
                        <option value="<?= $p->getId() ?>"
                            <?= ($cupomEdit?->getParceiroFk() === $p->getId()) ? 'selected' : '' ?>>
                            #<?= $p->getId() ?> — <?= htmlspecialchars($p->getNome()) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label>Código do Cupom *</label>
                <input type="text" name="codigo" required placeholder="Ex: ROTA15"
                       value="<?= htmlspecialchars($cupomEdit?->getCodigo() ?? '') ?>">

                <label>Benefício / Desconto *</label>
                <input type="text" name="desconto" required placeholder="Ex: 15% OFF na hospedagem"
                       value="<?= htmlspecialchars($cupomEdit?->getDesconto() ?? '') ?>">

                <label>Validade</label>
                <input type="date" name="validade" value="<?= htmlspecialchars($cupomEdit?->getValidade() ?? '') ?>">

                <label>Limite de Usos</label>
                <input type="number" name="quantidade_limite" placeholder="Ex: 100"
                       value="<?= htmlspecialchars((string)($cupomEdit?->getQuantidadeLimite() ?? '')) ?>">

                <label>Status</label>
                <select name="status">
                    <option value="ATIVO" <?= ($cupomEdit?->getStatus() === 'ATIVO') ? 'selected' : '' ?>>ATIVO</option>
                    <option value="INATIVO" <?= ($cupomEdit?->getStatus() === 'INATIVO') ? 'selected' : '' ?>>INATIVO</option>
                </select>

                <div class="botoes">
                    <button type="submit" class="btn btn-primario">
                        <?= $cupomEdit ? 'Atualizar Cupom' : 'Salvar Cupom' ?>
                    </button>
                    <a href="index.php" class="btn btn-secundario">Limpar</a>
                </div>
            </form>

            <table>
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Parceiro (FK)</th>
                        <th>Desconto</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cupons as $c): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($c->getCodigo()) ?></strong></td>
                            <td><?= htmlspecialchars($c->getNomeParceiro() ?? '') ?></td>
                            <td><?= htmlspecialchars($c->getDesconto()) ?></td>
                            <td>
                                <span class="badge <?= $c->getStatus() === 'ATIVO' ? 'ativo' : 'inativo' ?>">
                                    <?= $c->getStatus() ?>
                                </span>
                            </td>
                            <td>
                                <a href="?editar_cupom=<?= $c->getId() ?>" class="btn btn-editar">Editar</a>
                                <a href="?excluir_cupom=<?= $c->getId() ?>" class="btn btn-excluir"
                                   onclick="return confirm('Deseja excluir este cupom?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
</div>
</body>
</html>