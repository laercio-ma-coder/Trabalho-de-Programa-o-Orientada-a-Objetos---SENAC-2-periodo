document.addEventListener('DOMContentLoaded', () => {

  /* ==========================================================
     CONFIGURAÇÃO
     true  = uma div por vez (clicar em outra esconde a atual)
     false = várias divs podem ficar abertas ao mesmo tempo
     ========================================================== */
  const UMA_POR_VEZ = true;

  /* ==========================================================
     ABAS / PAINÉIS
     ========================================================== */
  const abas = document.querySelectorAll('.buttonvi');
  const paineis = document.querySelectorAll('.painel');

  function abrirPainel(id) {
    if (UMA_POR_VEZ) {
      abas.forEach(a => a.classList.toggle('ativo', a.dataset.alvo === id));
      paineis.forEach(p => p.hidden = p.id !== id);
      history.replaceState(null, '', '#' + id);   // lembra a aba ao recarregar
    } else {
      const painel = document.getElementById(id);
      const aba = document.querySelector(`.buttonvi[data-alvo="${id}"]`);
      if (!painel || !aba) return;
      painel.hidden = !painel.hidden;
      aba.classList.toggle('ativo', !painel.hidden);
    }
  }

  abas.forEach(aba => {
    aba.addEventListener('click', () => abrirPainel(aba.dataset.alvo));
  });

  // Ao carregar: abre o painel indicado na URL (#painel-status) ou o primeiro
  const idInicial = location.hash.slice(1);
  const existe = [...paineis].some(p => p.id === idInicial);
  if (UMA_POR_VEZ) {
    abrirPainel(existe ? idInicial : paineis[0].id);
  }

  /* ==========================================================
     MENU HAMBÚRGUER
     ========================================================== */
  const toggle = document.getElementById('menu-toggle');
  const menu = document.getElementById('menu');

  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const aberto = menu.classList.toggle('aberto');
      toggle.setAttribute('aria-expanded', aberto);
    });
  }

  /* ==========================================================
     STATUS DE EMBARQUE (verde = embarcado, vermelho = não)
     ========================================================== */
  const btnEmb = document.getElementById('btn-embarque');

  if (btnEmb) {
    btnEmb.addEventListener('click', async () => {
      const ativo = btnEmb.getAttribute('aria-pressed') !== 'true';

      // Atualiza a interface na hora
      btnEmb.setAttribute('aria-pressed', ativo);
      btnEmb.classList.toggle('ativo', ativo);
      btnEmb.textContent = ativo ? 'Embarcado' : 'Não embarcado';

      // Salva no servidor (descomente quando o atualizarStatus.php existir)
      /*
      try {
        const resp = await fetch('atualizarStatus.php', {
          method: 'POST',
          body: new URLSearchParams({ embarcado: ativo ? 1 : 0 })
        });
        if (!resp.ok) throw new Error('Falha ao salvar');
      } catch (erro) {
        // Se falhar, desfaz a mudança visual
        btnEmb.setAttribute('aria-pressed', !ativo);
        btnEmb.classList.toggle('ativo', !ativo);
        btnEmb.textContent = !ativo ? 'Embarcado' : 'Não embarcado';
        alert('Não foi possível salvar o status. Tente novamente.');
      }
      */
    });
  }

  /* ==========================================================
     SLIDES DE INFORMAÇÕES (Anterior / Próximo)
     ========================================================== */
  const slides = document.querySelectorAll('.slide');
  const btnAnterior = document.getElementById('anterior');
  const btnProximo = document.getElementById('proximo');
  let atual = 0;

  function mostrarSlide(i) {
    if (slides.length === 0) return;
    atual = (i + slides.length) % slides.length;   // dá a volta no início/fim
    slides.forEach((s, n) => s.hidden = n !== atual);
  }

  if (btnAnterior) btnAnterior.addEventListener('click', () => mostrarSlide(atual - 1));
  if (btnProximo)  btnProximo.addEventListener('click',  () => mostrarSlide(atual + 1));
  mostrarSlide(0);

  /* ==========================================================
     MÁSCARA DE CPF: 000.000.000-00
     ========================================================== */
  const campoCPF = document.getElementById('ConfCPF');

  if (campoCPF) {
    campoCPF.addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '').slice(0, 11);
      v = v.replace(/(\d{3})(\d)/, '$1.$2')
           .replace(/(\d{3})\.(\d{3})(\d)/, '$1.$2.$3')
           .replace(/\.(\d{3})(\d{1,2})$/, '.$1-$2');
      e.target.value = v;
    });
  }

});
document.addEventListener('DOMContentLoaded', () => {

  const UMA_POR_VEZ = true;   // true = uma div por vez | false = várias abertas

  /* ===== ABAS / PAINÉIS ===== */
  const abas = document.querySelectorAll('.buttonvi');
  const paineis = document.querySelectorAll('.painel');

  if (abas.length === 0 || paineis.length === 0) {
    console.warn('[passageiro.js] Não achei botões .buttonvi ou divs .painel. Confira o HTML.');
  }

  function abrirPainel(id) {
    const painel = document.getElementById(id);
    if (!painel) {
      console.warn('[passageiro.js] Nenhuma div com id="' + id + '". Confira o data-alvo do botão.');
      return;
    }

    if (UMA_POR_VEZ) {
      abas.forEach(a => a.classList.toggle('ativo', a.dataset.alvo === id));
      paineis.forEach(p => { p.hidden = (p.id !== id); });
      history.replaceState(null, '', '#' + id);
    } else {
      painel.hidden = !painel.hidden;
      const aba = document.querySelector('.buttonvi[data-alvo="' + id + '"]');
      if (aba) aba.classList.toggle('ativo', !painel.hidden);
    }
  }

  abas.forEach(aba => {
    aba.addEventListener('click', () => abrirPainel(aba.dataset.alvo));
  });

  if (UMA_POR_VEZ && paineis.length > 0) {
    const idHash = location.hash.slice(1);
    const idValido = [...paineis].some(p => p.id === idHash);
    abrirPainel(idValido ? idHash : paineis[0].id);
  }

  /* ===== MENU HAMBÚRGUER ===== */
  const toggle = document.getElementById('menu-toggle');
  const menu = document.getElementById('menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const aberto = menu.classList.toggle('aberto');
      toggle.setAttribute('aria-expanded', aberto);
    });
  }

  /* ===== STATUS DE EMBARQUE ===== */
  const btnEmb = document.getElementById('btn-embarque');
  if (btnEmb) {
    btnEmb.addEventListener('click', () => {
      const ativo = btnEmb.getAttribute('aria-pressed') !== 'true';
      btnEmb.setAttribute('aria-pressed', ativo);
      btnEmb.classList.toggle('ativo', ativo);
      btnEmb.textContent = ativo ? 'Embarcado' : 'Não embarcado';
      // TODO: salvar no servidor com fetch('atualizarStatus.php', ...)
    });
  }

  /* ===== SLIDES ===== */
  const slides = document.querySelectorAll('.slide');
  let atual = 0;

  function mostrarSlide(i) {
    if (slides.length === 0) return;
    atual = (i + slides.length) % slides.length;
    slides.forEach((s, n) => { s.hidden = (n !== atual); });
  }

  const btnAnt = document.getElementById('anterior');
  const btnProx = document.getElementById('proximo');
  if (btnAnt)  btnAnt.addEventListener('click', () => mostrarSlide(atual - 1));
  if (btnProx) btnProx.addEventListener('click', () => mostrarSlide(atual + 1));
  mostrarSlide(0);

  /* ===== MÁSCARA DE CPF ===== */
  const campoCPF = document.getElementById('ConfCPF');
  if (campoCPF) {
    campoCPF.addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '').slice(0, 11);
      v = v.replace(/(\d{3})(\d)/, '$1.$2')
           .replace(/(\d{3})\.(\d{3})(\d)/, '$1.$2.$3')
           .replace(/\.(\d{3})(\d{1,2})$/, '.$1-$2');
      e.target.value = v;
    });
  }
});
/* ===== BOTÃO DE QR CODE: só aparece se houver câmera ===== */
const btnQR = document.getElementById('ler-qr');

async function temCamera() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return false;
  try {
    const dispositivos = await navigator.mediaDevices.enumerateDevices();
    return dispositivos.some(d => d.kind === 'videoinput');
  } catch {
    return false;
  }
}

if (btnQR) {
  temCamera().then(ok => { btnQR.hidden = !ok; });
}
const eToque = window.matchMedia('(pointer: coarse)').matches;
temCamera().then(ok => { btnQR.hidden = !(ok && eToque); });