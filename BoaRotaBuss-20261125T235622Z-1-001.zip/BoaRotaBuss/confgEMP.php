<?php include 'inc/headerEMP.inc.php'; ?>
<?php include 'inc/menuLateralEMP.inc.php'; ?>

<main class="tela">
    <section class="cadastrar-viagem" id="configuracoes">
        <div class="topo-listagem">
            <div>
                <h1 class="title">Configurações do Sistema</h1>
                <p class="subtitle">Ajuste as preferências visuais, segurança e alertas da conta empresarial.</p>
            </div>
        </div>

        <div class="lista-config">
            <!-- ==========================================================
                 OPÇÃO 1: TEMA NOTURNO (PERSISTIDO VIA LOCALSTORAGE)
                 ========================================================== -->
            <div class="item-config">
                <div class="info-config">
                    <h3>Modo Escuro na Área Interna</h3>
                    <p>Alterna o fundo dos cartões entre claro e escuro para maior conforto visual.</p>
                </div>
                <!-- Switch estilizado em CSS puro usando checkbox oculto + span.slider -->
                <label class="switch" aria-label="Ativar modo escuro">
                    <input type="checkbox" id="darkModeToggle">
                    <span class="slider"></span>
                </label>
            </div>

            <!-- ==========================================================
                 OPÇÃO 2: ALTERAÇÃO DE SENHA (PAINEL EXPANSÍVEL)
                 ========================================================== -->
            <div class="item-config-expansivel">
                <div class="item-config">
                    <div class="info-config">
                        <h3>Segurança e Senha</h3>
                        <p>Atualize a senha de acesso administrativo da empresa.</p>
                    </div>
                    <button type="button" class="btn-editar" id="btnAbrirSenha">Alterar Senha</button>
                </div>

                <!-- Formulário oculto por padrão (.escondido) até o gestor clicar em "Alterar Senha" -->
                <form action="alterarSenhaEmpresa.php" method="POST" id="box-alterar-senha" class="box-parada sub-painel-config escondido">
                    <h4 class="titulo-parada">Definir Nova Senha</h4>
                    <div class="linha">
                        <div class="campo">
                            <label class="dados" for="senha_atual">Senha Atual</label>
                            <input class="input" type="password" id="senha_atual" name="senha_atual" placeholder="Digite sua senha atual" required>
                        </div>
                        <div class="campo">
                            <label class="dados" for="nova_senha">Nova Senha</label>
                            <input class="input" type="password" id="nova_senha" name="nova_senha" placeholder="Mínimo 8 caracteres" required>
                        </div>
                    </div>
                    <div class="botoes">
                        <button type="submit" class="buttonLGN">Salvar Nova Senha</button>
                        <button type="button" class="btn-excluir" id="btnCancelarSenha">Cancelar</button>
                    </div>
                </form>
            </div>

            <!-- ==========================================================
                 OPÇÃO 3: ALERTAS OPERACIONAIS
                 ========================================================== -->
            <div class="item-config-expansivel">
                <div class="item-config">
                    <div class="info-config">
                        <h3>Notificações e Alertas</h3>
                        <p>Escolha como deseja receber avisos de embarque, avaliações e manutenção da frota.</p>
                    </div>
                    <button type="button" class="btn-editar" id="btnAbrirNotif">Configurar</button>
                </div>

                <div id="box-notificacoes" class="box-parada sub-painel-config escondido">
                    <h4 class="titulo-parada">Preferências de Alerta</h4>
                    <div class="grade-comodidades">
                        <label class="check-comodidade">
                            <input type="checkbox" checked>
                            <span>Novas avaliações de passageiros</span>
                        </label>
                        <label class="check-comodidade">
                            <input type="checkbox" checked>
                            <span>Vencimento de CNH de motoristas</span>
                        </label>
                        <label class="check-comodidade">
                            <input type="checkbox" checked>
                            <span>Manutenção preventiva da frota</span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- ==========================================================
                 OPÇÃO 4: CONFORMIDADE COM A LGPD
                 ========================================================== -->
            <div class="item-config">
                <div class="info-config">
                    <h3>Privacidade e LGPD</h3>
                    <p>Avaliações anônimas têm a identidade do passageiro ocultada automaticamente nos relatórios.</p>
                </div>
                <span class="badge-paradas com-paradas">Proteção Ativa</span>
            </div>
        </div>
    </section>
</main>

<script>
    // 1. Modo Escuro: lê o estado salvo no navegador ao carregar a página
    const darkToggle = document.getElementById('darkModeToggle');
    if (localStorage.getItem('brb_dark_emp') === '1') {
        document.body.classList.add('modo-escuro-emp');
        darkToggle.checked = true;
    }

    // Salva a nova escolha no localStorage sempre que o switch for clicado
    darkToggle.addEventListener('change', () => {
        document.body.classList.toggle('modo-escuro-emp', darkToggle.checked);
        localStorage.setItem('brb_dark_emp', darkToggle.checked ? '1' : '0');
    });

    // 2. Abre/fecha o formulário de troca de senha
    const boxSenha = document.getElementById('box-alterar-senha');
    document.getElementById('btnAbrirSenha').addEventListener('click', () => {
        boxSenha.classList.toggle('escondido');
    });
    document.getElementById('btnCancelarSenha').addEventListener('click', () => {
        boxSenha.classList.add('escondido');
    });

    // 3. Abre/fecha as preferências de notificações
    const boxNotif = document.getElementById('box-notificacoes');
    document.getElementById('btnAbrirNotif').addEventListener('click', () => {
        boxNotif.classList.toggle('escondido');
    });
</script>

<?php include 'inc/footerEMP.inc.php'; ?>