DROP DATABASE IF EXISTS boarotabus_mvc;
CREATE DATABASE boarotabus_mvc CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE boarotabus_mvc;

-- Tabela Pai: PARCEIRO
CREATE TABLE PARCEIRO (
    PARCEIRO_ID INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    NOME VARCHAR(100) NOT NULL,
    CATEGORIA VARCHAR(50),
    SITE_PROPRIO VARCHAR(255),
    DESCRICAO TEXT,
    TIPO ENUM('PARCEIRO', 'PATROCINADOR') NOT NULL DEFAULT 'PARCEIRO'
);

-- Tabela Filho: CUPOM (relacionada a PARCEIRO pela chave estrangeira PARCEIRO_FK)
CREATE TABLE CUPOM (
    CUPOM_ID INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    PARCEIRO_FK INT NOT NULL,
    CODIGO VARCHAR(50) NOT NULL UNIQUE,
    DESCONTO VARCHAR(100) NOT NULL,
    VALIDADE DATE NULL,
    DESCRICAO VARCHAR(255),
    QUANTIDADE_LIMITE INT NULL,
    STATUS ENUM('ATIVO', 'INATIVO') NOT NULL DEFAULT 'ATIVO',

    CONSTRAINT fk_cupom_parceiro
        FOREIGN KEY (PARCEIRO_FK) REFERENCES PARCEIRO(PARCEIRO_ID)
        ON DELETE CASCADE
);

-- Dados iniciais para demonstração
INSERT INTO PARCEIRO (NOME, CATEGORIA, SITE_PROPRIO, DESCRICAO, TIPO) VALUES
('Hotel Tarobá Foz', 'Hospedagem', 'https://hoteltarobafoz.com.br', 'Desconto exclusivo em diárias para passageiros BoaRotaBuss.', 'PARCEIRO'),
('Café & Estrada Campos Gerais', 'Alimentação', 'https://cafeestrada.com.br', 'Combo café colonial nas paradas da BR-277.', 'PATROCINADOR');

INSERT INTO CUPOM (PARCEIRO_FK, CODIGO, DESCONTO, VALIDADE, DESCRICAO, QUANTIDADE_LIMITE, STATUS) VALUES
(1, 'ROTAFOZ15', '15% OFF na diária', '2026-12-31', 'Apresentar passagem ativa no check-in.', 100, 'ATIVO'),
(2, 'CAFE277', '10% OFF no lanche', '2026-12-31', 'Válido nas unidades credenciadas.', 200, 'ATIVO');