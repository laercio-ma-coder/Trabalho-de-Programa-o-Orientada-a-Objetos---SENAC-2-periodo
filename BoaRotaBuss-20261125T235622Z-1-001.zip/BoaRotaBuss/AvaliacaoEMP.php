<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/classes/BancoJson.php';

$avaliacoes = BancoJson::ler('avaliacoes');

// Popula com exemplos iniciais caso o JSON ainda esteja vazio
if (empty($avaliacoes)) {
    $avaliacoes = [
        [
            'id'           => 1,
            'rota'         => 'Ponta Grossa - PR → Curitiba - PR',
            'data'         => '15/11/2026 às 11:20',
            'avaliador'    => 'Ana Beatriz Oliveira',
            'motorista'    => 'Carlos Mendes',
            'nota_geral'   => 4.8,
            'conforto'     => 5.0,
            'motorista_nt' => 5.0,
            'pontualidade' => 4.5,
            'comentario'   => 'Ônibus muito limpo, ar-condicionado funcionando perfeitamente e o motorista Carlos foi super atencioso. Apenas um pequeno atraso de 10 minutos na saída da segunda parada.',
            'status_gestao'=> 'PENDENTE',
            'acao_gestao'  => ''
        ],
        [
            'id'           => 2,
            'rota'         => 'Curitiba - PR → Guarapuava - PR',
            'data'         => '10/11/2026 às 14:05',
            'avaliador'    => 'Mariana Souza Lima',
            'motorista'    => 'Marcos Oliveira',
            'nota_geral'   => 3.3,
            'conforto'     => 3.0,
            'motorista_nt' => 4.5,
            'pontualidade' => 2.5,
            'comentario'   => 'O motorista conduziu muito bem, mas houve demora excessiva em uma das paradas intermediárias e o encosto da poltrona 14 estava com dificuldade para reclinar.',
            'status_gestao'=> 'PENDENTE',
            'acao_gestao'  => ''
        ],
        [
            'id'           => 3,
            'rota'         => 'Ponta Grossa - PR → Foz do Iguaçu - PR',
            'data'         => '18/11/2026 às 09:40',
            'avaliador'    => 'Lucas Henrique Prado',
            'motorista'    => 'Marcos Oliveira',
            'nota_geral'   => 4.9,
            'conforto'     => 5.0,
            'motorista_nt' => 5.0,
            'pontualidade' => 4.8,
            'comentario'   => 'Excelente experiência! Chegamos no horário exato e o acompanhamento das paradas pelo sistema ajudou muito.',
            'status_gestao'=> 'RESOLVIDO',
            'acao_gestao'  => 'Agradecimento enviado ao passageiro e bônus de pontualidade registrado para o motorista.'
        ]
    ];
    BancoJson::salvar('avaliacoes', $avaliacoes);
}

// Cálculos automáticos dos indicadores (KPIs)
$total = count($avaliacoes);
$somaGeral = $somaConforto = $somaMotorista = $somaPontualidade = 0;
$totalQueixas = 0;

foreach ($avaliacoes as $a) {
    $somaGeral        += (float) $a['nota_geral'];
    $somaConforto     += (float) $a['conforto'];
    $somaMotorista    += (float) $a['motorista_nt'];
    $somaPontualidade += (float) $a['pontualidade'];
    if ((float) $a['nota_geral'] < 4.0) {
        $totalQueixas++;
    }
}

$mediaGeral        = $total > 0 ? number_format($somaGeral / $total, 1) : '0.0';
$mediaConforto     = $total > 0 ? number_format($somaConforto / $total, 1) : '0.0';
$mediaMotorista    = $total > 0 ? number_format($somaMotorista / $total, 1) : '0.0';
$mediaPontualidade = $total > 0 ? number_format($somaPontualidade / $total, 1) : '0.0';
?>

<?php include 'inc/headerEMP.inc.php'; ?>
<?php include 'inc/menuLateralEMP.inc.php'; ?>

<div class="tela">
    <div class="topo-listagem">
        <div>
            <h1 class="title">Avaliações Ocorridas</h1>
            <p style="color: #547280; font-size: 0.9rem; margin-top: 2px;">Monitoramento de qualidade da frota, condutores e pontualidade das rotas</p>
        </div>
        <span class="badge-paradas com-paradas"><?= $total ?> Feedbacks Registrados</span>
    </div>

    <!-- PAINEL DE RESUMO / MÉDIAS AUTOMÁTICAS -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; margin: 16px 0 20px;">
        <div style="background: #06303d; color: #fff; padding: 16px; border-radius: 14px;">
            <span style="font-size: 0.8rem; opacity: 0.8;">Nota Média Geral</span>
            <strong style="display: block; font-size: 1.6rem; margin-top: 4px;"><?= $mediaGeral ?> <span style="color:#ffd166;">★</span></strong>
        </div>
        <div style="background: #f2f8fa; border: 1px solid #cde4e9; color: #06303d; padding: 16px; border-radius: 14px;">
            <span style="font-size: 0.8rem; color: #547280;">Carro / Conforto</span>
            <strong style="display: block; font-size: 1.4rem; margin-top: 4px;"><?= $mediaConforto ?> ★</strong>
        </div>
        <div style="background: #f2f8fa; border: 1px solid #cde4e9; color: #06303d; padding: 16px; border-radius: 14px;">
            <span style="font-size: 0.8rem; color: #547280;">Motoristas</span>
            <strong style="display: block; font-size: 1.4rem; margin-top: 4px;"><?= $mediaMotorista ?> ★</strong>
        </div>
        <div style="background: #f2f8fa; border: 1px solid #cde4e9; color: #06303d; padding: 16px; border-radius: 14px;">
            <span style="font-size: 0.8rem; color: #547280;">Pontualidade</span>
            <strong style="display: block; font-size: 1.4rem; margin-top: 4px;"><?= $mediaPontualidade ?> ★</strong>
        </div>
        <div style="background: #fff5f5; border: 1px solid #f5c2c7; color: #842029; padding: 16px; border-radius: 14px;">
            <span style="font-size: 0.8rem;">Alertas / Queixas (< 4.0)</span>
            <strong style="display: block; font-size: 1.4rem; margin-top: 4px;"><?= $totalQueixas ?> ocorrência(s)</strong>
        </div>
    </div>

    <!-- BARRA DE FILTROS E BUSCA -->
    <div style="display: flex; flex-wrap: wrap; gap: 10px; justify-content: space-between; align-items: center; margin-bottom: 18px;">
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button type="button" class="btn-filtro-av ativo" data-filtro="todas"
                    style="padding: 8px 14px; border-radius: 10px; border: 1px solid #0e7f94; background: #0e7f94; color: #fff; font-weight: 600; cursor: pointer;">
                Todas (<?= $total ?>)
            </button>
            <button type="button" class="btn-filtro-av" data-filtro="elogios"
                    style="padding: 8px 14px; border-radius: 10px; border: 1px solid #cde4e9; background: #fff; color: #06303d; font-weight: 600; cursor: pointer;">
                Elogios (4.0+ ★)
            </button>
            <button type="button" class="btn-filtro-av" data-filtro="queixas"
                    style="padding: 8px 14px; border-radius: 10px; border: 1px solid #f5c2c7; background: #fff; color: #842029; font-weight: 600; cursor: pointer;">
                Com Queixa / Alerta (<?= $totalQueixas ?>)
            </button>
        </div>

        <input type="search" id="buscaAvaliacao" placeholder="Buscar por rota, motorista ou passageiro..."
               style="padding: 9px 14px; border: 1px solid #cde4e9; border-radius: 10px; min-width: 260px;">
    </div>

    <!-- LISTA DE AVALIAÇÕES -->
    <div class="lista-avaliacoes">
        <?php foreach (array_reverse($avaliacoes) as $av): 
            $ehQueixa = (float) $av['nota_geral'] < 4.0;
            $resolvido = ($av['status_gestao'] ?? 'PENDENTE') === 'RESOLVIDO';
        ?>
            <div class="card-avaliacao item-avaliacao" data-tipo="<?= $ehQueixa ? 'queixas' : 'elogios' ?>">
                <div class="cabecalho-avaliacao">
                    <div>
                        <h3 class="viagem-avaliada"><?= htmlspecialchars($av['rota']) ?></h3>
                        <span class="data-avaliacao">
                            Avaliado em <strong><?= htmlspecialchars($av['data']) ?></strong> por <strong><?= htmlspecialchars($av['avaliador']) ?></strong>
                            <?php if (!empty($av['motorista'])): ?>
                                • Motorista: <strong><?= htmlspecialchars($av['motorista']) ?></strong>
                            <?php endif; ?>
                        </span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                        <?php if ($resolvido): ?>
                            <span style="background: #d1e7dd; color: #0f5132; padding: 5px 10px; border-radius: 999px; font-size: 0.78rem; font-weight: 700;">✔ Tratado</span>
                        <?php elseif ($ehQueixa): ?>
                            <span style="background: #f8d7da; color: #842029; padding: 5px 10px; border-radius: 999px; font-size: 0.78rem; font-weight: 700;">⚠ Requer Atenção</span>
                        <?php endif; ?>

                        <span class="nota-geral <?= $ehQueixa ? 'alerta' : '' ?>">
                            Nota Geral: <?= number_format((float) $av['nota_geral'], 1) ?> / 5
                        </span>
                    </div>
                </div>

                <div class="criterios-avaliacao">
                    <div class="chip-criterio">
                        <span>Carro / Conforto:</span>
                        <strong><?= number_format((float) $av['conforto'], 1) ?> ★</strong>
                    </div>
                    <div class="chip-criterio">
                        <span>Motorista:</span>
                        <strong><?= number_format((float) $av['motorista_nt'], 1) ?> ★</strong>
                    </div>
                    <div class="chip-criterio">
                        <span>Rota / Pontualidade:</span>
                        <strong><?= number_format((float) $av['pontualidade'], 1) ?> ★</strong>
                    </div>
                </div>

                <div class="comentario-avaliacao <?= $ehQueixa ? 'queixa' : '' ?>">
                    <strong>Queixas e Comentários do Avaliador:</strong>
                    <p>"<?= htmlspecialchars($av['comentario']) ?>"</p>
                </div>

                <!-- TRATATIVA DA EMPRESA -->
                <?php if ($resolvido && !empty($av['acao_gestao'])): ?>
                    <div style="margin-top: 12px; padding: 10px 14px; border-radius: 10px; background: #e8f6f8; border-left: 3px solid #0e7f94; color: #06303d; font-size: 0.88rem;">
                        <strong>Ação Registrada pela Gestão<?= !empty($av['resolvido_em']) ? ' (' . htmlspecialchars($av['resolvido_em']) . ')' : '' ?>:</strong>
                        <?= htmlspecialchars($av['acao_gestao']) ?>
                    </div>
                <?php else: ?>
                    <form action="registrarAcaoAvaliacao.php" method="post" style="display: flex; gap: 8px; margin-top: 12px;">
                        <input type="hidden" name="avaliacao_id" value="<?= (int) $av['id'] ?>">
                        <input type="text" name="acao_gestao" placeholder="Registrar providência tomada ou resposta ao passageiro..." required
                               style="flex: 1; padding: 9px 12px; border: 1px solid #cde4e9; border-radius: 10px; font-size: 0.88rem;">
                        <button type="submit" style="padding: 9px 16px; border: none; border-radius: 10px; background: #0e7f94; color: #fff; font-weight: 600; cursor: pointer;">
                            Marcar como Tratado
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
    // Filtro por categoria (Todas / Elogios / Queixas) e busca por texto
    const botoesFiltro = document.querySelectorAll('.btn-filtro-av');
    const cardsAvaliacao = document.querySelectorAll('.item-avaliacao');
    const inputBusca = document.getElementById('buscaAvaliacao');
    let filtroAtual = 'todas';

    function aplicarFiltrosAvaliacao() {
        const termo = inputBusca.value.toLowerCase().trim();
        cardsAvaliacao.forEach(card => {
            const bateTipo = (filtroAtual === 'todas') || (card.dataset.tipo === filtroAtual);
            const bateTexto = (termo === '') || card.textContent.toLowerCase().includes(termo);
            card.style.display = (bateTipo && bateTexto) ? '' : 'none';
        });
    }

    botoesFiltro.forEach(btn => {
        btn.addEventListener('click', () => {
            botoesFiltro.forEach(b => {
                b.style.background = '#fff';
                b.style.color = b.dataset.filtro === 'queixas' ? '#842029' : '#06303d';
            });
            btn.style.background = btn.dataset.filtro === 'queixas' ? '#842029' : '#0e7f94';
            btn.style.color = '#fff';

            filtroAtual = btn.dataset.filtro;
            aplicarFiltrosAvaliacao();
        });
    });

    inputBusca.addEventListener('input', aplicarFiltrosAvaliacao);
</script>

<?php include 'inc/footerEMP.inc.php'; ?>