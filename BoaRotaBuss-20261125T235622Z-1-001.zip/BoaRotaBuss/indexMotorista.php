<?php include 'inc/headerMRT.inc.php'; ?>

<main class="pagina">

    <!-- CABEÇALHO DA VIAGEM ATUAL -->
    <section class="banner-viagem-mtr">
        <div class="info-banner-mtr">
            <span class="tag-viagem-ativa" id="badge-status-topo">EM TRÂNSITO</span>
            <h1>Ponta Grossa → Foz do Iguaçu</h1>
            <p>Ônibus: <strong>Marcopolo Paradiso G8 (Placa ABC-1D23)</strong> • Saída: 08:00</p>
        </div>
        <div class="resumo-ocupacao-mtr">
            <span>Embarcados</span>
            <strong id="contador-embarcados">0 / 0</strong>
        </div>
    </section>

    <!-- BOTÕES DAS 4 ABAS -->
    <div class="ViButtons">
        <button type="button" class="buttonvi ativo" data-alvo="painel-passageiros">Passageiros</button>
        <button type="button" class="buttonvi" data-alvo="painel-trajeto">Trajeto</button>
        <button type="button" class="buttonvi" data-alvo="painel-cadastro">Cadastro</button>
        <button type="button" class="buttonvi" data-alvo="painel-info">Informações</button>
    </div>

    <!-- ==========================================================
         ABA 1: MAPA DE POLTRONAS E VERIFICAÇÃO DE PASSAGEIROS
         ========================================================== -->
    <section class="painel card card-largo" id="painel-passageiros">
        <div class="topo-painel-mtr">
            <div>
                <h2 class="titulo-painel">Mapa de Poltronas e Embarque</h2>
                <p class="subtitulo-painel">Clique em qualquer poltrona para ver os dados do passageiro, confirmar presença ou enviar aviso.</p>
            </div>
            <button type="button" class="buttonLGN btn-aviso-geral" id="btnAbrirAvisoGeral">
                Notificação Geral aos Passageiros
            </button>
        </div>

        <!-- Legenda -->
        <div class="legenda-poltronas">
            <span><i class="dot presente"></i> Presente no ônibus</span>
            <span><i class="dot ausente"></i> Ocupado / Não embarcado</span>
            <span><i class="dot vazio"></i> Poltrona vazia</span>
        </div>

        <!-- Desenho do Ônibus Rodoviário -->
        <div class="onibus-rodoviario" id="onibusRodoviario">
            <div class="frente-onibus">
                <div class="posto-motorista">
                    <span class="volante-icon">⚙</span>
                    <div>
                        <strong>Motorista</strong>
                        <small>Cabine</small>
                    </div>
                </div>
                <div class="parabrisa-linha">FRENTE DO ÔNIBUS</div>
                <div class="entrada-porta">
                    <div>
                        <strong>Porta / Escada</strong>
                        <small>Embarque</small>
                    </div>
                    <span class="porta-icon">🚪</span>
                </div>
            </div>

            <div class="salao-poltronas" id="gradePoltronas"></div>

            <div class="traseira-onibus">
                <span>Saída de Emergência</span>
                <span>Bagageiro / Motor Traseiro</span>
            </div>
        </div>
    </section>

    <!-- ==========================================================
         ABA 2: GERENCIAMENTO DE TRAJETO E STATUS DA VIAGEM
         ========================================================== -->
    <section class="painel card card-largo" id="painel-trajeto" hidden>
        <h2 class="titulo-painel">Gerenciamento da Viagem e Rota</h2>
        <p class="subtitulo-painel">Atualize o andamento da viagem em tempo real ou registre desvios na rota.</p>

        <div class="linha-paradas-mtr">
            <div class="parada-item concluida"><span>1</span><strong>Ponta Grossa</strong><small>Saída 08:00</small></div>
            <div class="parada-item concluida"><span>2</span><strong>Prudentópolis</strong><small>09:35</small></div>
            <div class="parada-item atual"><span>3</span><strong>Guarapuava</strong><small>Próxima</small></div>
            <div class="parada-item"><span>4</span><strong>Cantagalo</strong><small>Prev. 11:50</small></div>
            <div class="parada-item"><span>5</span><strong>Cascavel</strong><small>Prev. 13:40</small></div>
            <div class="parada-item"><span>6</span><strong>Foz do Iguaçu</strong><small>Destino 15:25</small></div>
        </div>

        <div class="grid-trajeto-mtr">
            <div class="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1843210.5!2d-52.5!3d-25.2!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94dce12345678901%3A0x1234567890123456!2sBR-277%20Paran%C3%A1!5e0!3m2!1spt-BR!2sbr!4v1234567890123"
                        title="Mapa do trajeto" allowfullscreen loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

            <div class="controles-viagem-mtr">
                <form action="atualizarStatusViagem.php" method="post" id="formStatusViagem">
                    <label class="dados" for="select-status-viagem">Status Atual da Viagem</label>
                    <select class="input" id="select-status-viagem" name="status_viagem">
                        <option value="AGUARDANDO EMBARQUE">Aguardando Embarque</option>
                        <option value="EM TRÂNSITO" selected>Em Trânsito</option>
                        <option value="PARADA TÉCNICA / LANCHE">Parada Técnica / Lanche</option>
                        <option value="ATRASO NA VIA">Atraso na Via</option>
                        <option value="VIAGEM CONCLUÍDA">Viagem Concluída</option>
                    </select>

                    <label class="dados" for="check-alterar-rota">
                        <input type="checkbox" id="check-alterar-rota" name="alterar_rota" value="1">
                        Necessário fazer alteração / desvio na rota
                    </label>

                    <div id="box-motivo-rota" class="escondido">
                        <label class="dados" for="nova-rota">Trecho / Desvio Alternativo</label>
                        <input class="input" type="text" id="nova-rota" name="nova_rota"
                               placeholder="Ex: Desvio pela PR-151 devido a interdição na BR-277">

                        <label class="dados" for="motivo-rota">Motivo da Alteração (Obrigatório)</label>
                        <textarea class="input" id="motivo-rota" name="motivo_rota" rows="3"
                                  placeholder="Descreva o motivo (obras, acidente, bloqueio climático...)"></textarea>
                    </div>

                    <div class="botoes">
                        <button type="submit" class="buttonLGN">Salvar Atualização da Viagem</button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- ==========================================================
         ABA 3: CADASTRO DE PASSAGEIRO PARA APROVAÇÃO DA EMPRESA
         ========================================================== -->
    <section class="painel card" id="painel-cadastro" hidden>
        <div class="alerta-aprovacao-adm">
            <strong>Solicitação para Administração:</strong> Use este formulário apenas em caso de falha no sistema ou embarque emergencial. O cadastro será enviado para aprovação de um administrador da empresa.
        </div>

        <h2 class="titulo-painel">Pré-Cadastro de Passageiro</h2>
        <p class="subtitulo-painel">Preencha os dados do passageiro para vincular à viagem atual.</p>

        <form action="solicitarCadastroPassageiro.php" method="post">
            <div class="campo">
                <label class="dados" for="cad-nome">Nome completo do passageiro</label>
                <input class="input" type="text" id="cad-nome" name="nome" placeholder="Nome completo" required>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="cad-cpf">CPF</label>
                    <input class="input" type="text" id="cad-cpf" name="cpf" placeholder="000.000.000-00" required>
                </div>
                <div class="campo">
                    <label class="dados" for="cad-tel">Telefone / WhatsApp (Emergência)</label>
                    <input class="input" type="tel" id="cad-tel" name="telefone" placeholder="(42) 99999-9999" required>
                </div>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="cad-poltrona">Poltrona designada</label>
                    <input class="input" type="number" id="cad-poltrona" name="poltrona" min="1" max="46" placeholder="Ex: 14" required>
                </div>
                <div class="campo">
                    <label class="dados" for="cad-motivo">Motivo do cadastro manual</label>
                    <select class="input" id="cad-motivo" name="motivo" required>
                        <option value="Erro na leitura do QR Code">Erro na leitura do QR Code</option>
                        <option value="Passagem emitida no balcão sem sincronizar">Passagem emitida no balcão sem sincronizar</option>
                        <option value="Troca de horário / encaixe autorizado">Troca de horário / encaixe autorizado</option>
                    </select>
                </div>
            </div>

            <div class="campo">
                <label class="dados" for="cad-obs">Observação para o ADM da empresa</label>
                <textarea class="input" id="cad-obs" name="observacao" rows="2" placeholder="Detalhes adicionais para conferência..."></textarea>
            </div>

            <div class="botoes">
                <button type="submit" class="buttonLGN">Enviar Cadastro para Aprovação da Empresa</button>
            </div>
        </form>
    </section>

    <!-- ==========================================================
         ABA 4: INFORMAÇÕES GERAIS (ESTILO ANTIGO + NAVEGAÇÃO POR PARADA)
         ========================================================== -->
    <section class="painel card card-largo" id="painel-info" hidden>
        <h2 class="titulo-painel">Informes Gerais do Destino e Operação</h2>

        <div class="navegacao-botoes">
            <button type="button" class="buttonLGN" id="anterior">← Anterior</button>
            <span class="indicador-parada-slide" id="indicador-parada">Parada 1 de 6</span>
            <button type="button" class="buttonLGN" id="proximo">Próximo →</button>
        </div>

        <div class="tela slide">
            <div class="cenario">
                <img src="img/cenario.jpg" alt="Imagem da parada" id="img-slide">
            </div>
            <div class="conteudo">
                <h2 class="titulo-historia" id="titulo-slide">Parada 1: Ponta Grossa (Saída 08:00)</h2>
                <ul class="texto-historia" id="lista-slide"></ul>
            </div>
        </div>
    </section>

</main>

<!-- ==========================================================
     MODAL 1: DADOS DA POLTRONA / PASSAGEIRO
     ========================================================== -->
<div class="modal-overlay escondido" id="modalPoltrona" role="dialog" aria-modal="true">
    <div class="modal-mtr-box">
        <div class="topo-modal-mtr">
            <div>
                <span class="tag-poltrona" id="modalTagPoltrona">Poltrona 01</span>
                <h2 id="modalNomePassageiro">Nome do Passageiro</h2>
            </div>
            <button type="button" class="btn-fechar-modal" id="fecharModalPoltrona">×</button>
        </div>

        <div class="dados-modal-passageiro" id="modalDetalhesPassageiro">
            <p><strong>CPF:</strong> <span id="modalCpfPassageiro">—</span></p>
            <p><strong>Passagem:</strong> <span id="modalPassagemPassageiro">—</span></p>
            <p><strong>Embarque:</strong> <span id="modalEmbarquePassageiro">—</span></p>
            <p><strong>Status:</strong> <span id="modalStatusPassageiro">—</span></p>
        </div>

        <div class="box-aviso-direto" id="boxAvisoDireto">
            <label class="dados" for="textoAvisoDireto">Enviar aviso direto para este passageiro:</label>
            <div class="linha-aviso">
                <input class="input" type="text" id="textoAvisoDireto" placeholder="Ex: O ônibus sairá em 5 minutos, retorne ao embarque.">
                <button type="button" class="buttonLGN" id="btnEnviarAvisoDireto">Enviar</button>
            </div>
        </div>

        <div class="botoes modal-acoes-mtr">
            <button type="button" class="buttonLGN" id="btnAlternarPresenca">Confirmar Presença</button>
            <a href="tel:0000000000" class="buttonLGN btn-emergencia-psg" id="btnContatoEmergenciaPsg">
                Contato de Emergência
            </a>
        </div>
    </div>
</div>

<!-- ==========================================================
     MODAL 2: NOTIFICAÇÃO GERAL AOS PASSAGEIROS
     ========================================================== -->
<div class="modal-overlay escondido" id="modalAvisoGeral" role="dialog" aria-modal="true">
    <div class="modal-mtr-box">
        <div class="topo-modal-mtr">
            <div>
                <span class="tag-poltrona">Transmissão para todos a bordo</span>
                <h2>Notificação Geral aos Passageiros</h2>
            </div>
            <button type="button" class="btn-fechar-modal" id="fecharModalAvisoGeral">×</button>
        </div>

        <p class="subtitulo-painel">Selecione um aviso rápido ou escreva uma mensagem personalizada para todos os passageiros desta viagem:</p>

        <div class="chips-avisos-rapidos">
            <button type="button" class="chip-aviso" data-msg="Atenção passageiros: iniciaremos o embarque. Dirijam-se à plataforma.">Aviso de Embarque</button>
            <button type="button" class="chip-aviso" data-msg="Atenção: saída prevista em 5 minutos. Todos aos seus assentos.">Aviso de Saída (5 min)</button>
            <button type="button" class="chip-aviso" data-msg="Parada técnica de 20 minutos para lanche e sanitários.">Parada de 20 min</button>
        </div>

        <textarea class="input" id="mensagemGeralTexto" rows="3" placeholder="Digite o comunicado geral..."></textarea>

        <div class="botoes">
            <button type="button" class="buttonLGN" id="btnDispararGeral">Enviar Notificação para Todos</button>
        </div>
    </div>
</div>

<script>
    // 1. Navegação entre as 4 abas
    const botoesAbas = document.querySelectorAll('.buttonvi');
    const paineis = document.querySelectorAll('.painel');

    botoesAbas.forEach(btn => {
        btn.addEventListener('click', () => {
            botoesAbas.forEach(b => b.classList.remove('ativo'));
            btn.classList.add('ativo');

            const alvo = btn.dataset.alvo;
            paineis.forEach(p => {
                p.hidden = (p.id !== alvo);
            });
        });
    });

    // 2. 46 poltronas padrão rodoviário
    const poltronas = [
        { num: 1,  status: 'presente', nome: 'Ana Clara Souza',      cpf: '123.456.789-00', passagem: 'BRB-9001', embarque: 'Ponta Grossa',  tel: '42999112233' },
        { num: 2,  status: 'presente', nome: 'Carlos Eduardo Lima',  cpf: '234.567.890-11', passagem: 'BRB-9002', embarque: 'Ponta Grossa',  tel: '42998223344' },
        { num: 4,  status: 'presente', nome: 'João Pedro Santos',    cpf: '456.789.012-33', passagem: 'BRB-9004', embarque: 'Ponta Grossa',  tel: '42996445566' },
        { num: 3,  status: 'ausente',  nome: 'Mariana Oliveira',     cpf: '345.678.901-22', passagem: 'BRB-9003', embarque: 'Guarapuava',    tel: '42997334455' },

        { num: 5,  status: 'vazio' },
        { num: 6,  status: 'presente', nome: 'Fernanda Costa',       cpf: '567.890.123-44', passagem: 'BRB-9006', embarque: 'Ponta Grossa',  tel: '42995556677' },
        { num: 8,  status: 'ausente',  nome: 'Juliana Ferreira',     cpf: '789.012.345-66', passagem: 'BRB-9008', embarque: 'Cascavel',      tel: '45993778899' },
        { num: 7,  status: 'presente', nome: 'Rafael Almeida',       cpf: '678.901.234-55', passagem: 'BRB-9007', embarque: 'Prudentópolis', tel: '42994667788' },

        { num: 9,  status: 'presente', nome: 'Lucas Martins',        cpf: '890.123.456-77', passagem: 'BRB-9009', embarque: 'Ponta Grossa',  tel: '42992889900' },
        { num: 10, status: 'vazio' },
        { num: 12, status: 'presente', nome: 'Gabriel Ribeiro',      cpf: '012.345.678-99', passagem: 'BRB-9012', embarque: 'Ponta Grossa',  tel: '42990112233' },
        { num: 11, status: 'presente', nome: 'Beatriz Rocha',        cpf: '901.234.567-88', passagem: 'BRB-9011', embarque: 'Ponta Grossa',  tel: '42991990011' },

        { num: 13, status: 'presente', nome: 'Patrícia Mendes',      cpf: '111.222.333-44', passagem: 'BRB-9013', embarque: 'Prudentópolis', tel: '42988112233' },
        { num: 14, status: 'vazio' },
        { num: 16, status: 'ausente',  nome: 'Camila Araújo',        cpf: '333.444.555-66', passagem: 'BRB-9016', embarque: 'Guarapuava',    tel: '42986334455' },
        { num: 15, status: 'presente', nome: 'Thiago Barbosa',       cpf: '222.333.444-55', passagem: 'BRB-9015', embarque: 'Ponta Grossa',  tel: '42987223344' },

        { num: 17, status: 'presente', nome: 'Bruno Carvalho',       cpf: '444.555.666-77', passagem: 'BRB-9017', embarque: 'Ponta Grossa',  tel: '42985445566' },
        { num: 18, status: 'presente', nome: 'Larissa Gomes',        cpf: '555.666.777-88', passagem: 'BRB-9018', embarque: 'Ponta Grossa',  tel: '42984556677' },
        { num: 20, status: 'presente', nome: 'Diego Nascimento',     cpf: '666.777.888-99', passagem: 'BRB-9020', embarque: 'Ponta Grossa',  tel: '42983667788' },
        { num: 19, status: 'vazio' },

        { num: 21, status: 'presente', nome: 'Renata Monteiro',      cpf: '777.888.999-00', passagem: 'BRB-9021', embarque: 'Ponta Grossa',  tel: '42982112233' },
        { num: 22, status: 'vazio' },
        { num: 24, status: 'presente', nome: 'Felipe Nogueira',      cpf: '888.999.000-11', passagem: 'BRB-9024', embarque: 'Guarapuava',    tel: '42981223344' },
        { num: 23, status: 'presente', nome: 'Amanda Teixeira',      cpf: '999.000.111-22', passagem: 'BRB-9023', embarque: 'Ponta Grossa',  tel: '42980334455' },

        { num: 25, status: 'ausente',  nome: 'Rodrigo Vieira',       cpf: '101.202.303-44', passagem: 'BRB-9025', embarque: 'Cascavel',      tel: '45999445566' },
        { num: 26, status: 'presente', nome: 'Vanessa Cardoso',      cpf: '202.303.404-55', passagem: 'BRB-9026', embarque: 'Ponta Grossa',  tel: '42998556677' },
        { num: 28, status: 'vazio' },
        { num: 27, status: 'presente', nome: 'Gustavo Freitas',      cpf: '303.404.505-66', passagem: 'BRB-9027', embarque: 'Prudentópolis', tel: '42997667788' },

        { num: 29, status: 'presente', nome: 'Tatiane Moura',        cpf: '404.505.606-77', passagem: 'BRB-9029', embarque: 'Ponta Grossa',  tel: '42996778899' },
        { num: 30, status: 'presente', nome: 'Marcelo Dias',         cpf: '505.606.707-88', passagem: 'BRB-9030', embarque: 'Ponta Grossa',  tel: '42995889900' },
        { num: 32, status: 'presente', nome: 'Isabela Farias',       cpf: '606.707.808-99', passagem: 'BRB-9032', embarque: 'Guarapuava',    tel: '42994990011' },
        { num: 31, status: 'vazio' },

        { num: 33, status: 'presente', nome: 'Eduardo Azevedo',      cpf: '707.808.909-00', passagem: 'BRB-9033', embarque: 'Ponta Grossa',  tel: '42993112233' },
        { num: 34, status: 'ausente',  nome: 'Bianca Correia',       cpf: '808.909.010-11', passagem: 'BRB-9034', embarque: 'Cantagalo',     tel: '42992223344' },
        { num: 36, status: 'presente', nome: 'Vinícius Lopes',       cpf: '909.010.121-22', passagem: 'BRB-9036', embarque: 'Ponta Grossa',  tel: '42991334455' },
        { num: 35, status: 'presente', nome: 'Natália Rezende',      cpf: '010.121.232-33', passagem: 'BRB-9035', embarque: 'Ponta Grossa',  tel: '42990445566' },

        { num: 37, status: 'vazio' },
        { num: 38, status: 'presente', nome: 'André Cavalcanti',     cpf: '121.232.343-44', passagem: 'BRB-9038', embarque: 'Ponta Grossa',  tel: '42989556677' },
        { num: 40, status: 'presente', nome: 'Sabrina Pacheco',      cpf: '232.343.454-55', passagem: 'BRB-9040', embarque: 'Prudentópolis', tel: '42988667788' },
        { num: 39, status: 'presente', nome: 'Henrique Tavares',     cpf: '343.454.565-66', passagem: 'BRB-9039', embarque: 'Ponta Grossa',  tel: '42987778899' },

        { num: 41, status: 'presente', nome: 'Letícia Prado',        cpf: '454.565.676-77', passagem: 'BRB-9041', embarque: 'Ponta Grossa',  tel: '42986889900' },
        { num: 42, status: 'vazio' },
        { num: 44, status: 'ausente',  nome: 'Fábio Antunes',        cpf: '565.676.787-88', passagem: 'BRB-9044', embarque: 'Cascavel',      tel: '45985990011' },
        { num: 43, status: 'presente', nome: 'Débora Macedo',        cpf: '676.787.898-99', passagem: 'BRB-9043', embarque: 'Ponta Grossa',  tel: '42984112233' },

        { num: 45, status: 'presente', nome: 'Otávio Siqueira',      cpf: '787.898.909-00', passagem: 'BRB-9045', embarque: 'Ponta Grossa',  tel: '42983223344' },
        { num: 46, status: 'vazio' }
    ];

    const gradePoltronas = document.getElementById('gradePoltronas');
    const modalPoltrona = document.getElementById('modalPoltrona');
    let poltronaSelecionada = null;

    function criarBotaoPoltrona(p) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = `poltrona-btn ${p.status}`;
        btn.innerHTML = `
            <span class="encosto-poltrona"></span>
            <span class="num-poltrona">${String(p.num).padStart(2, '0')}</span>
        `;
        btn.title = p.status === 'vazio'
            ? `Poltrona ${p.num} — Livre`
            : `Poltrona ${p.num} — ${p.nome}`;
        btn.addEventListener('click', () => abrirModalPoltrona(p));
        return btn;
    }

    function renderizarPoltronas() {
        gradePoltronas.innerHTML = '';
        let presentes = 0;
        let ocupados = 0;

        poltronas.forEach(p => {
            if (p.status !== 'vazio') ocupados++;
            if (p.status === 'presente') presentes++;
        });

        // Monta 12 colunas de fileiras (4 assentos por coluna: 2 janela/corredor superior + 2 corredor/janela inferior)
        // Na 12ª coluna (índice 11), as 2 posições superiores ficam para o WC e as 2 inferiores recebem 45 e 46
        for (let col = 0; col < 12; col++) {
            const base = col * 4;
            const pJanelaSup = poltronas[base];
            const pCorredorSup = poltronas[base + 1];
            const pCorredorInf = poltronas[base + 2];
            const pJanelaInf = poltronas[base + 3];

            const colunaEl = document.createElement('div');
            colunaEl.className = 'coluna-fileira-onibus';

            const blocoSup = document.createElement('div');
            blocoSup.className = 'par-poltronas';

            if (col === 11) {
                const wc = document.createElement('div');
                wc.className = 'banheiro-onibus';
                wc.innerHTML = '<strong>WC</strong><small>Sanitário</small>';
                blocoSup.appendChild(wc);
            } else {
                if (pJanelaSup) blocoSup.appendChild(criarBotaoPoltrona(pJanelaSup));
                if (pCorredorSup) blocoSup.appendChild(criarBotaoPoltrona(pCorredorSup));
            }

            const corredor = document.createElement('div');
            corredor.className = 'corredor-onibus';
            corredor.textContent = col === 5 ? 'CORREDOR' : '';

            const blocoInf = document.createElement('div');
            blocoInf.className = 'par-poltronas';
            if (pCorredorInf) blocoInf.appendChild(criarBotaoPoltrona(pCorredorInf));
            if (pJanelaInf) blocoInf.appendChild(criarBotaoPoltrona(pJanelaInf));

            colunaEl.appendChild(blocoSup);
            colunaEl.appendChild(corredor);
            colunaEl.appendChild(blocoInf);
            gradePoltronas.appendChild(colunaEl);
        }

        document.getElementById('contador-embarcados').textContent = `${presentes} / ${ocupados}`;
    }

    function abrirModalPoltrona(p) {
        poltronaSelecionada = p;
        document.getElementById('modalTagPoltrona').textContent = `Poltrona ${String(p.num).padStart(2, '0')}`;

        const boxDetalhes = document.getElementById('modalDetalhesPassageiro');
        const boxAviso = document.getElementById('boxAvisoDireto');
        const btnPresenca = document.getElementById('btnAlternarPresenca');
        const btnEmergencia = document.getElementById('btnContatoEmergenciaPsg');

        if (p.status === 'vazio') {
            document.getElementById('modalNomePassageiro').textContent = 'Poltrona Vazia / Disponível';
            boxDetalhes.classList.add('escondido');
            boxAviso.classList.add('escondido');
            btnPresenca.classList.add('escondido');
            btnEmergencia.classList.add('escondido');
        } else {
            document.getElementById('modalNomePassageiro').textContent = p.nome;
            document.getElementById('modalCpfPassageiro').textContent = p.cpf;
            document.getElementById('modalPassagemPassageiro').textContent = p.passagem;
            document.getElementById('modalEmbarquePassageiro').textContent = p.embarque;
            document.getElementById('modalStatusPassageiro').textContent =
                p.status === 'presente' ? 'Presente no ônibus' : 'Não embarcado / Ausente';

            boxDetalhes.classList.remove('escondido');
            boxAviso.classList.remove('escondido');
            btnPresenca.classList.remove('escondido');
            btnEmergencia.classList.remove('escondido');

            btnPresenca.textContent = p.status === 'presente' ? 'Marcar como Ausente' : 'Confirmar Presença';
            btnEmergencia.href = `tel:${p.tel}`;
            btnEmergencia.textContent = `Emergência: (${p.tel.slice(0,2)}) ${p.tel.slice(2,7)}-${p.tel.slice(7)}`;
        }

        modalPoltrona.classList.remove('escondido');
    }

    document.getElementById('btnAlternarPresenca').addEventListener('click', () => {
        if (!poltronaSelecionada || poltronaSelecionada.status === 'vazio') return;
        poltronaSelecionada.status = poltronaSelecionada.status === 'presente' ? 'ausente' : 'presente';
        renderizarPoltronas();
        abrirModalPoltrona(poltronaSelecionada);
    });

    document.getElementById('btnEnviarAvisoDireto').addEventListener('click', () => {
        const input = document.getElementById('textoAvisoDireto');
        if (!input.value.trim()) return;
        alert(`Aviso enviado para ${poltronaSelecionada.nome}: "${input.value}"`);
        input.value = '';
    });

    document.getElementById('fecharModalPoltrona').addEventListener('click', () => {
        modalPoltrona.classList.add('escondido');
    });

    // 3. Notificação Geral
    const modalAvisoGeral = document.getElementById('modalAvisoGeral');
    document.getElementById('btnAbrirAvisoGeral').addEventListener('click', () => {
        modalAvisoGeral.classList.remove('escondido');
    });
    document.getElementById('fecharModalAvisoGeral').addEventListener('click', () => {
        modalAvisoGeral.classList.add('escondido');
    });

    document.querySelectorAll('.chip-aviso').forEach(chip => {
        chip.addEventListener('click', () => {
            document.getElementById('mensagemGeralTexto').value = chip.dataset.msg;
        });
    });

    document.getElementById('btnDispararGeral').addEventListener('click', () => {
        const msg = document.getElementById('mensagemGeralTexto').value.trim();
        if (!msg) return;
        alert(`Notificação enviada para todos os passageiros da viagem:\n"${msg}"`);
        document.getElementById('mensagemGeralTexto').value = '';
        modalAvisoGeral.classList.add('escondido');
    });

    // 4. Alteração de rota e status no Trajeto
    const checkAlterarRota = document.getElementById('check-alterar-rota');
    const boxMotivoRota = document.getElementById('box-motivo-rota');
    checkAlterarRota.addEventListener('change', () => {
        boxMotivoRota.classList.toggle('escondido', !checkAlterarRota.checked);
    });

    document.getElementById('select-status-viagem').addEventListener('change', (e) => {
        document.getElementById('badge-status-topo').textContent = e.target.value;
    });

    // 5. Aba Informações: botões Anterior e Próximo pulam entre os cards/paradas até o destino final
    const paradasInfo = [
        {
            titulo: 'Parada 1: Ponta Grossa (Saída 08:00)',
            imagem: 'img/cenario.jpg',
            alt: 'Ponta Grossa — Campos Gerais',
            itens: [
                { rotulo: 'História', texto: 'Conhecida como a "Princesa dos Campos", cresceu no caminho das tropas (tropeirismo) e no entroncamento ferroviário dos Campos Gerais.' },
                { rotulo: 'Fatos', texto: 'Polo logístico e industrial importante do Paraná, cortado por rodovias estratégicas como a BR-376 e a BR-277.' },
                { rotulo: 'Turismo', texto: 'Parque Estadual de Vila Velha (arenitos e Furnas), Buraco do Padre e Parque Municipal Lago de Olarias.' },
                { rotulo: 'Fato', texto: 'É referência regional na produção de grãos, leite e indústria de base nos Campos Gerais.' },
                { rotulo: 'Parceiros próximos', texto: 'Terminal Rodoviário de Ponta Grossa • Café & Estrada Campos Gerais • Auto Socorro 24h BR-376.' }
            ]
        },
        {
            titulo: 'Parada 2: Prudentópolis (Prev. 09:35)',
            imagem: 'img/cenario.jpg',
            alt: 'Prudentópolis — Terra das Cachoeiras Gigantes',
            itens: [
                { rotulo: 'História', texto: 'Marcada pela imigração ucraniana no fim do século XIX, preservando tradições culturais, ritos religiosos e gastronomia típica.' },
                { rotulo: 'Fatos', texto: 'Possui um dos maiores territórios municipais do Paraná e relevo acidentado que forma dezenas de quedas d’água.' },
                { rotulo: 'Turismo', texto: 'Salto São Francisco (uma das maiores quedas d’água do Sul do Brasil), Recanto Rickli e trilhas ecológicas.' },
                { rotulo: 'Fato', texto: 'É conhecida nacionalmente como a "Terra das Cachoeiras Gigantes" e capital da cultura ucraniana no estado.' },
                { rotulo: 'Parceiros próximos', texto: 'Parada do Viajante Prudentópolis • Pousada & Lanches Salto • Posto Parceiro BR-277 km 264.' }
            ]
        },
        {
            titulo: 'Parada 3: Guarapuava (Próxima • 10:50)',
            imagem: 'img/cenario.jpg',
            alt: 'Guarapuava — Centro-Sul do Paraná',
            itens: [
                { rotulo: 'História', texto: 'Fundada no século XIX no terceiro planalto paranaense, teve papel histórico na ocupação do interior e na pecuária regional.' },
                { rotulo: 'Fatos', texto: 'Centro regional de comércio, serviços e agropecuária do Centro-Sul do Paraná, com clima ameno e campos nativos.' },
                { rotulo: 'Turismo', texto: 'Parque Natural Municipal das Araucárias, Lagoa das Lágrimas e rotas de turismo rural e histórico.' },
                { rotulo: 'Fato', texto: 'Possui forte tradição na produção de cevada, trigo e pecuária de corte e leite.' },
                { rotulo: 'Parceiros próximos', texto: 'Rodoviária de Guarapuava • Churrascaria & Café Planalto • Borracharia Parceira Trevo BR-277.' }
            ]
        },
        {
            titulo: 'Parada 4: Cantagalo (Prev. 11:50)',
            imagem: 'img/cenario.jpg',
            alt: 'Cantagalo — Centro-Oeste do Paraná',
            itens: [
                { rotulo: 'História', texto: 'Formado a partir de frentes extrativistas e agrícolas ao longo do eixo da BR-277 no centro-oeste paranaense.' },
                { rotulo: 'Fatos', texto: 'Ponto de passagem estratégico entre Guarapuava e Laranjeiras do Sul, com economia ligada à agricultura familiar e serviços.' },
                { rotulo: 'Turismo', texto: 'Áreas de mata nativa, rios da bacia do Iguaçu e mirantes rurais às margens da rodovia.' },
                { rotulo: 'Fato', texto: 'O nome Cantagalo remete ao canto das aves silvestres observadas na região pelos primeiros moradores.' },
                { rotulo: 'Parceiros próximos', texto: 'Restaurante Ponto de Apoio Cantagalo • Conveniência Rota 277 • Apoio Mecânico Centro-Oeste.' }
            ]
        },
        {
            titulo: 'Parada 5: Cascavel (Prev. 13:40)',
            imagem: 'img/cenario.jpg',
            alt: 'Cascavel — Oeste do Paraná',
            itens: [
                { rotulo: 'História', texto: 'Surgida no início da década de 1950 impulsionada pela extração de madeira e pela abertura da rodovia até a fronteira.' },
                { rotulo: 'Fatos', texto: 'Principal polo urbano, comercial, médico e universitário do Oeste do Paraná.' },
                { rotulo: 'Turismo', texto: 'Catedral Nossa Senhora Aparecida, Parque Ecológico Paulo Gorski e Zoológico Municipal.' },
                { rotulo: 'Fato', texto: 'É um dos maiores centros do agronegócio brasileiro, com forte integração entre lavouras, avicultura, suinocultura e leite.' },
                { rotulo: 'Parceiros próximos', texto: 'Terminal Rodoviário de Cascavel • Hotel & Descanso Oeste • Farmácia e Apoio ao Viajante BR-277.' }
            ]
        },
        {
            titulo: 'Destino Final (Parada 6): Foz do Iguaçu (15:25)',
            imagem: 'img/cenario.jpg',
            alt: 'Foz do Iguaçu — Cataratas e Tríplice Fronteira',
            itens: [
                { rotulo: 'História', texto: 'Marco da tríplice fronteira entre Brasil, Paraguai e Argentina, ganhou projeção mundial com o turismo e a hidrelétrica binacional.' },
                { rotulo: 'Fatos', texto: 'Ponto de desembarque no Terminal Internacional; orienta-se conferir documentos com foto antes de circular pela fronteira.' },
                { rotulo: 'Turismo', texto: 'Cataratas do Iguaçu (Parque Nacional do Iguaçu), Usina de Itaipu, Parque das Aves e Marco das Três Fronteiras.' },
                { rotulo: 'Fato', texto: 'As Cataratas do Iguaçu reúnem cerca de 275 quedas d’água e são Patrimônio Natural da Humanidade pela UNESCO.' },
                { rotulo: 'Parceiros próximos', texto: 'Rodoviária Internacional de Foz • Receptivo & Passeios Fronteira • Rede Parceira Hotelaria & Transfer.' }
            ]
        }
    ];

    let indiceParadaAtual = 0;
    const tituloSlide = document.getElementById('titulo-slide');
    const listaSlide = document.getElementById('lista-slide');
    const imgSlide = document.getElementById('img-slide');
    const indicadorParada = document.getElementById('indicador-parada');

    function renderizarSlideParada() {
        const atual = paradasInfo[indiceParadaAtual];
        if (!atual || !tituloSlide || !listaSlide) return;

        tituloSlide.textContent = atual.titulo;
        if (imgSlide) {
            imgSlide.src = atual.imagem;
            imgSlide.alt = atual.alt;
        }
        if (indicadorParada) {
            indicadorParada.textContent = `Parada ${indiceParadaAtual + 1} de ${paradasInfo.length}`;
        }

        listaSlide.innerHTML = atual.itens
            .map(item => `<li><strong>${item.rotulo}:</strong> ${item.texto}</li>`)
            .join('');
    }

    document.getElementById('anterior')?.addEventListener('click', () => {
        indiceParadaAtual = (indiceParadaAtual - 1 + paradasInfo.length) % paradasInfo.length;
        renderizarSlideParada();
    });

    document.getElementById('proximo')?.addEventListener('click', () => {
        indiceParadaAtual = (indiceParadaAtual + 1) % paradasInfo.length;
        renderizarSlideParada();
    });

    // 6. Menu Mobile
    const btnMenu = document.getElementById('menu-toggle');
    const navMenu = document.getElementById('menu');
    if (btnMenu && navMenu) {
        btnMenu.addEventListener('click', () => {
            const aberto = navMenu.classList.toggle('aberto');
            btnMenu.setAttribute('aria-expanded', aberto);
        });
    }

    renderizarPoltronas();
    renderizarSlideParada();
</script>

<?php include 'inc/footer.inc.php'; ?>