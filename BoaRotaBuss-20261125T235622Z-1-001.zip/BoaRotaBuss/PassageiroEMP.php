<?php include 'inc/headerEMP.inc.php'; ?>

<?php include 'inc/menuLateralEMP.inc.php'; ?>

<!-- ==========================================================
     BLOCO 1: CADASTRO DE PASSAGEIROS PELA EMPRESA
     ========================================================== -->
<div class="tela">
    <section class="cadastrar-viagem" id="cadastrodepassageiros">
        <h1 class="title">Cadastro de Passageiros</h1>
        <p class="subtitle">Cadastre passageiros vinculados diretamente à empresa para controle de embarque</p>

        <form action="cadastrarPassageiro.php" method="POST">
            <div class="linha">
                <div class="campo">
                    <label class="dados" for="nome">Nome Completo</label>
                    <input class="input" type="text" id="nome" name="nome"
                           placeholder="Digite o nome completo do passageiro" required>
                </div>

                <div class="campo">
                    <label class="dados" for="email">E-mail</label>
                    <input class="input" type="email" id="email" name="email"
                           placeholder="exemplo@email.com" required>
                </div>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="telefone">Telefone / WhatsApp</label>
                    <input class="input" type="tel" id="telefone" name="telefone"
                           placeholder="(00) 00000-0000" maxlength="15" required>
                </div>

                <div class="campo">
                    <label class="dados" for="documento">Documento (CPF/RG)</label>
                    <input class="input" type="text" id="documento" name="documento"
                           placeholder="Digite o CPF ou RG" maxlength="18" required>
                </div>
            </div>

            <div class="botoes">
                <button type="submit" class="buttonLGN">Cadastrar Passageiro</button>
            </div>
        </form>
    </section>
</div>

<!-- ==========================================================
     BLOCO 2: PASSAGEIROS CADASTRADOS (EMPRESA E CONTA PRÓPRIA)
     ========================================================== -->
<div class="tela">
    <!-- SUBSEÇÃO A: PASSAGEIROS CADASTRADOS PELA EMPRESA -->
    <div class="topo-listagem">
        <h1 class="title">Passageiros Cadastrados pela Empresa</h1>
        <span class="badge-paradas com-paradas">2 passageiros cadastrados</span>
    </div>

    <div class="tabela-responsiva">
        <table class="tabela-frota">
            <thead>
                <tr>
                    <th>Passageiro</th>
                    <th>Documento</th>
                    <th>Histórico de Presença</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <!-- Exemplo 1 -->
                <tr>
                    <td>
                        <strong>Ana Beatriz Oliveira</strong><br>
                        <small>ana.oliveira@email.com • (42) 99811-2233</small>
                    </td>
                    <td><code>123.456.789-00</code></td>
                    <td>
                        <span class="badge-paradas com-paradas">14 presenças</span>
                        <span class="badge-paradas alerta-cnh">1 falta</span>
                        <br><small>Última viagem: Ponta Grossa → Curitiba (15/11/2026)</small>
                    </td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarPassageiro.php?id=1" class="btn-editar">Editar</a>
                            <a href="removerPassageiro.php?id=1" class="btn-excluir">Remover</a>
                        </div>
                    </td>
                </tr>

                <!-- Exemplo 2 -->
                <tr>
                    <td>
                        <strong>Lucas Gabriel Costa</strong><br>
                        <small>lucas.costa@email.com • (42) 99122-4455</small>
                    </td>
                    <td><code>987.654.321-11</code></td>
                    <td>
                        <span class="badge-paradas com-paradas">8 presenças (100%)</span>
                        <br><small>Última viagem: Ponta Grossa → Castro (12/11/2026)</small>
                    </td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarPassageiro.php?id=2" class="btn-editar">Editar</a>
                            <a href="removerPassageiro.php?id=2" class="btn-excluir">Remover</a>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- SUBSEÇÃO B: PASSAGEIROS COM CONTA PRÓPRIA -->
    <div class="topo-listagem subsecao-espaco">
        <h2 class="title titulo-menor">Passageiros com Conta Própria (Viajaram com a Empresa)</h2>
        <span class="badge-paradas direta">2 contas externas</span>
    </div>

    <div class="tabela-responsiva">
        <table class="tabela-frota">
            <thead>
                <tr>
                    <th>Passageiro (Conta Própria)</th>
                    <th>Documento</th>
                    <th>Histórico de Viagens / Presença</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <!-- Exemplo 1 -->
                <tr>
                    <td>
                        <strong>Mariana Souza Lima</strong><br>
                        <small>mariana.lima@email.com • (41) 98765-4321</small>
                    </td>
                    <td><code>456.789.123-22</code></td>
                    <td>
                        <span class="badge-paradas com-paradas">5 viagens concluídas</span>
                        <br><small>Última viagem: Curitiba → Guarapuava (10/11/2026)</small>
                    </td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarPassageiro.php?id=101" class="btn-editar">Editar</a>
                            <a href="removerPassageiro.php?id=101" class="btn-excluir">Remover</a>
                        </div>
                    </td>
                </tr>

                <!-- Exemplo 2 -->
                <tr>
                    <td>
                        <strong>Pedro Henrique Rocha</strong><br>
                        <small>pedro.rocha@email.com • (42) 99988-7766</small>
                    </td>
                    <td><code>321.654.987-33</code></td>
                    <td>
                        <span class="badge-paradas com-paradas">2 presenças</span>
                        <span class="badge-paradas alerta-cnh">1 não compareceu</span>
                        <br><small>Última viagem: Ponta Grossa → Curitiba (05/11/2026)</small>
                    </td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarPassageiro.php?id=102" class="btn-editar">Editar</a>
                            <a href="removerPassageiro.php?id=102" class="btn-excluir">Remover</a>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>



<script>
    // Máscara de Telefone
    document.getElementById('telefone').addEventListener('input', (e) => {
        let v = e.target.value.replace(/\D/g, '');
        v = v.replace(/^(\d{2})(\d)/g, '($1) $2');
        v = v.replace(/(\d)(\d{4})$/, '$1-$2');
        e.target.value = v;
    });
</script>

<?php include 'inc/footerEMP.inc.php'; ?>