<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$erroLogin = $_SESSION['erro_login'] ?? '';
unset($_SESSION['erro_login']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoaRotaBuss — Acesso Empresarial</title>
    <!-- Folha de estilos corporativa -->
    <link rel="stylesheet" href="css/styleEMP.css">
</head>
<body class="empresa">

    <!-- Botão flutuante para voltar ao login de passageiro -->
    <a class="retorar" href="indexLoginPassageiro.php" aria-label="Voltar"><</a>

    <main class="container">

        <!-- ==========================================================
             CARTÃO CIRCULAR 1: LOGIN EMPRESARIAL
             ========================================================== -->
        <section class="login" id="login">
            <h1 class="title">Portal Corporativo</h1>
            <p class="subtitle">
                Gerencie suas rotas, frotas, motoristas e passageiros com facilidade.
            </p>

            <?php if ($erroLogin !== ''): ?>
                <div class="aviso" style="color: #ffb3b9; margin-bottom: 8px;"><?= htmlspecialchars($erroLogin) ?></div>
            <?php endif; ?>

            <!-- Envia para processaLogin.php (ou direto para indexEmpresarial.php se preferir) -->
            <form action="processaLogin.php" method="post">
                <label class="dados" for="login-usuarioEMP">E-mail empresarial</label>
                <input class="input" type="email" id="login-usuarioEMP" name="usuario"
                       placeholder="Ex: gestor@viacaoboarota.com.br" required>

                <label class="dados" for="login-senha">Senha</label>
                <input class="input" type="password" id="login-senha" name="senha"
                       placeholder="Digite sua senha" required>

                <div class="botoes">
                    <button type="submit" class="buttonLGN" id="login-btn">Entrar</button>
                    <button type="button" class="buttonLGN secundario" id="ir-registrar">Registrar</button>
                </div>
            </form>
        </section>

        <!-- ==========================================================
             CARTÃO CIRCULAR 2: CADASTRO DE NOVA EMPRESA
             ========================================================== -->
        <section class="registrar escondido" id="registrar">
            <h1 class="title">Cadastrar Empresa</h1>
            <p class="subtitle">Preencha os dados corporativos para publicar suas rotas.</p>

            <form action="registrarEmpresa.php" method="post">
                <div class="campo">
                    <label class="dados" for="reg-nome">Nome fantasia</label>
                    <input class="input" type="text" id="reg-nome" name="nome"
                           placeholder="Digite o nome fantasia da viação" required>
                </div>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="reg-email">E-mail empresarial</label>
                        <input class="input" type="email" id="reg-email" name="email"
                               placeholder="contato@empresa.com.br" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="reg-cnpj">CNPJ</label>
                        <input class="input" type="text" id="reg-cnpj" name="cnpj"
                               inputmode="numeric" maxlength="18"
                               placeholder="00.000.000/0000-00" required>
                    </div>
                </div>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="reg-senha">Senha</label>
                        <input class="input" type="password" id="reg-senha" name="senha"
                               placeholder="Digite sua senha" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="reg-senha2">Confirmar senha</label>
                        <input class="input" type="password" id="reg-senha2" name="senha2"
                               placeholder="Repita a senha" required>
                    </div>
                </div>

                <p class="aviso">Sua senha deve ter no mínimo:</p>
                <ul class="lista-regras">
                    <li class="regras">8 caracteres</li>
                    <li class="regras">Letras maiúsculas</li>
                    <li class="regras">Letras minúsculas</li>
                    <li class="regras">Números</li>
                    <li class="regras">Caracteres especiais</li>
                </ul>

                <div class="botoes">
                    <!-- Corrigido: type="button" para voltar e type="submit" para enviar o cadastro -->
                    <button type="button" class="buttonLGN secundario" id="voltar-login">Voltar</button>
                    <button type="submit" class="buttonLGN" id="registrar-btn">Registrar</button>
                </div>
            </form>
        </section>

    </main>

    <script>
        // Alterna entre as telas de Login e Cadastro
        const login     = document.getElementById('login');
        const registrar = document.getElementById('registrar');

        document.getElementById('ir-registrar').addEventListener('click', () => {
            login.classList.add('escondido');
            registrar.classList.remove('escondido');
        });

        document.getElementById('voltar-login').addEventListener('click', () => {
            registrar.classList.add('escondido');
            login.classList.remove('escondido');
        });

        // Máscara automática de CNPJ no formato 00.000.000/0000-00 usando Expressões Regulares (Regex)
        document.getElementById('reg-cnpj').addEventListener('input', (e) => {
            let v = e.target.value.replace(/\D/g, '').slice(0, 14); // Remove tudo que não é dígito e limita a 14 números
            v = v.replace(/^(\d{2})(\d)/, '$1.$2')
                 .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
                 .replace(/\.(\d{3})(\d)/, '.$1/$2')
                 .replace(/(\d{4})(\d)/, '$1-$2');
            e.target.value = v;
        });
    </script>
