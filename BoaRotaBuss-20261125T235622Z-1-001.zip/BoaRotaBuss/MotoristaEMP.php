<?php include 'inc/headerEMP.inc.php'; ?>

<?php include 'inc/menuLateralEMP.inc.php'; ?>

<!-- BLOCO 1: FORMULÁRIO DE CADASTRO DE MOTORISTA -->
<div class="tela">
    <section class="cadastrar-viagem" id="cadastrar-motorista">
        <h1 class="title">Cadastrar Motorista</h1>
        <p class="subtitle">Informe os dados do motorista da frota e crie suas credenciais de acesso</p>

        <form action="." method="post">
            <!-- Dados Pessoais -->
            <div class="linha">
                <div class="campo">
                    <label class="dados" for="nome_motorista">Nome Completo</label>
                    <input class="input" type="text" id="nome_motorista" name="nome_motorista"
                           placeholder="Digite o nome completo do motorista" required>
                </div>

                <div class="campo">
                    <label class="dados" for="data_nascimento">Data de Nascimento <span id="preview-idade" class="tag-idade"></span></label>
                    <input class="input" type="date" id="data_nascimento" name="data_nascimento" required>
                </div>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="cpf">CPF</label>
                    <input class="input" type="text" id="cpf" name="cpf"
                           placeholder="000.000.000-00" maxlength="14" required>
                </div>

                <div class="campo">
                    <label class="dados" for="telefone">Telefone / WhatsApp</label>
                    <input class="input" type="tel" id="telefone" name="telefone"
                           placeholder="(00) 00000-0000" maxlength="15" required>
                </div>
            </div>

            <!-- Dados da CNH -->
            <div class="linha">
                <div class="campo">
                    <label class="dados" for="cnh">Número da CNH</label>
                    <input class="input" type="text" id="cnh" name="cnh"
                           placeholder="Digite o registro da CNH" maxlength="11" required>
                </div>

                <div class="campo">
                    <label class="dados" for="categoria_cnh">Categoria</label>
                    <select class="input" id="categoria_cnh" name="categoria_cnh" required>
                        <option value="" disabled selected>Selecione</option>
                        <option value="D">Categoria D (Ônibus / Micro-ônibus)</option>
                        <option value="E">Categoria E (Veículos Articulados)</option>
                    </select>
                </div>

                <div class="campo">
                    <label class="dados" for="validade_cnh">Validade da CNH</label>
                    <input class="input" type="date" id="validade_cnh" name="validade_cnh" required>
                </div>
            </div>

            <!-- Credenciais de Acesso à Área do Motorista -->
            <div class="box-parada bloco-acesso">
                <h3 class="titulo-parada">Credenciais de Acesso do Motorista</h3>
                <p class="descricao-bloco">Este usuário e senha serão utilizados pelo motorista para acessar o painel de embarque e rotas.</p>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="usuario_motorista">Usuário / Login</label>
                        <input class="input" type="text" id="usuario_motorista" name="usuario_motorista"
                               placeholder="Ex: joao.silva" autocomplete="off" required>
                    </div>

                    <div class="campo">
                        <label class="dados" for="senha_motorista">Senha de Acesso</label>
                        <div class="campo-senha-wrapper">
                            <input class="input" type="password" id="senha_motorista" name="senha_motorista"
                                   placeholder="Crie uma senha" autocomplete="new-password" required>
                            <button type="button" class="btn-mini-acao" id="btnToggleSenha" title="Mostrar ou ocultar senha">Ver</button>
                            <button type="button" class="btn-mini-acao gerar" id="btnGerarSenha" title="Gerar senha automática">Gerar</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Botão para abrir Dados de Endereço (Opcional) -->
            <ul class="grade-acoes" id="itemAddDados">
                <li><button type="button" class="cardADD" id="btnAddDados">Adicionar Dados de Endereço</button></li>
            </ul>

            <!-- Área onde os dados de endereço serão abertos -->
            <div id="container-dados" class="container-paradas"></div>

            <!-- Botão de remover logo abaixo dos dados -->
            <ul class="grade-acoes escondido" id="itemRmvDados">
                <li><button type="button" class="cardRMV" id="btnRmvDados">Remover Dados</button></li>
            </ul>

            <div class="botoes">
                <button type="submit" class="buttonLGN" id="cadastrarMotoristaBtn">Salvar Motorista</button>
            </div>
        </form>
    </section>
</div>

<!-- BLOCO 2: TABELA / LISTAGEM VISUAL DE MOTORISTAS CADASTRADOS -->
<div class="tela">
    <div class="topo-listagem">
        <h1 class="title">Motoristas da Frota</h1>
        <span class="badge-paradas com-paradas">3 motoristas ativos</span>
    </div>

    <div class="tabela-responsiva">
        <table class="tabela-frota">
            <thead>
                <tr>
                    <th>Motorista</th>
                    <th>Idade</th>
                    <th>CNH</th>
                    <th>Usuário de Acesso</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <!-- Exemplo 1 -->
                <tr>
                    <td>
                        <strong>Carlos Eduardo Mendes</strong><br>
                        <small>(42) 99912-3456</small>
                    </td>
                    <td>41 anos</td>
                    <td>
                        <span class="badge-cnh">Cat. D</span>
                        <span class="num-cnh">04829103845</span>
                    </td>
                    <td><code>carlos.mendes</code></td>
                    <td><span class="badge-paradas com-paradas">CNH Regular</span></td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarMotorista.php?id=1" class="btn-editar">Editar</a>
                            <a href="excluirMotorista.php?id=1" class="btn-excluir">Excluir</a>
                        </div>
                    </td>
                </tr>

                <!-- Exemplo 2 -->
                <tr>
                    <td>
                        <strong>Marcos Vinícius Ferreira</strong><br>
                        <small>(42) 98845-1122</small>
                    </td>
                    <td>35 anos</td>
                    <td>
                        <span class="badge-cnh">Cat. E</span>
                        <span class="num-cnh">05910293847</span>
                    </td>
                    <td><code>marcos.ferreira</code></td>
                    <td><span class="badge-paradas com-paradas">CNH Regular</span></td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarMotorista.php?id=2" class="btn-editar">Editar</a>
                            <a href="excluirMotorista.php?id=2" class="btn-excluir">Excluir</a>
                        </div>
                    </td>
                </tr>

                <!-- Exemplo 3 -->
                <tr>
                    <td>
                        <strong>Roberto Almeida Santos</strong><br>
                        <small>(42) 99104-7788</small>
                    </td>
                    <td>52 anos</td>
                    <td>
                        <span class="badge-cnh">Cat. D</span>
                        <span class="num-cnh">03192837465</span>
                    </td>
                    <td><code>roberto.santos</code></td>
                    <td><span class="badge-paradas alerta-cnh">Vence em 15 dias</span></td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarMotorista.php?id=3" class="btn-editar">Editar</a>
                            <a href="excluirMotorista.php?id=3" class="btn-excluir">Excluir</a>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    // ==========================================================
    // 1. CÁLCULO AUTOMÁTICO DE IDADE E MÁSCARAS (CPF / TELEFONE)
    // ==========================================================
    const inputNasc = document.getElementById('data_nascimento');
    const previewIdade = document.getElementById('preview-idade');

    inputNasc.addEventListener('change', () => {
        if (!inputNasc.value) {
            previewIdade.textContent = '';
            return;
        }
        const hoje = new Date();
        const nasc = new Date(inputNasc.value + 'T00:00:00');
        let idade = hoje.getFullYear() - nasc.getFullYear();
        const mes = hoje.getMonth() - nasc.getMonth();
        if (mes < 0 || (mes === 0 && hoje.getDate() < nasc.getDate())) {
            idade--;
        }
        previewIdade.textContent = idade >= 0 ? `(${idade} anos)` : '';
    });

    // Máscara de CPF
    document.getElementById('cpf').addEventListener('input', (e) => {
        let v = e.target.value.replace(/\D/g, '');
        v = v.replace(/(\d{3})(\d)/, '$1.$2');
        v = v.replace(/(\d{3})(\d)/, '$1.$2');
        v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
        e.target.value = v;
    });

    // Máscara de Telefone
    document.getElementById('telefone').addEventListener('input', (e) => {
        let v = e.target.value.replace(/\D/g, '');
        v = v.replace(/^(\d{2})(\d)/g, '($1) $2');
        v = v.replace(/(\d)(\d{4})$/, '$1-$2');
        e.target.value = v;
    });

    // Sugestão automática de usuário baseada no nome
    const inputNome = document.getElementById('nome_motorista');
    const inputUsuario = document.getElementById('usuario_motorista');
    inputNome.addEventListener('blur', () => {
        if (!inputUsuario.value && inputNome.value.trim()) {
            const partes = inputNome.value.trim().toLowerCase()
                .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                .split(/\s+/);
            if (partes.length >= 2) {
                inputUsuario.value = `${partes[0]}.${partes[partes.length - 1]}`;
            } else {
                inputUsuario.value = partes[0];
            }
        }
    });

    // ==========================================================
    // 2. MOSTRAR / GERAR SENHA DO MOTORISTA
    // ==========================================================
    const inputSenha = document.getElementById('senha_motorista');
    const btnToggleSenha = document.getElementById('btnToggleSenha');
    const btnGerarSenha = document.getElementById('btnGerarSenha');

    btnToggleSenha.addEventListener('click', () => {
        const isPassword = inputSenha.type === 'password';
        inputSenha.type = isPassword ? 'text' : 'password';
        btnToggleSenha.textContent = isPassword ? 'Ocultar' : 'Ver';
    });

    btnGerarSenha.addEventListener('click', () => {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789@#';
        let senha = '';
        for (let i = 0; i < 8; i++) {
            senha += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        inputSenha.value = senha;
        inputSenha.type = 'text';
        btnToggleSenha.textContent = 'Ocultar';
    });

    // ==========================================================
    // 3. CONTROLE DOS DADOS DE ENDEREÇO (CEP AUTOMÁTICO)
    // ==========================================================
    const btnAddDados = document.getElementById('btnAddDados');
    const btnRmvDados = document.getElementById('btnRmvDados');
    const itemAddDados = document.getElementById('itemAddDados');
    const itemRmvDados = document.getElementById('itemRmvDados');
    const containerDados = document.getElementById('container-dados');

    btnAddDados.addEventListener('click', () => {
        containerDados.innerHTML = `
            <div class="box-parada">
                <h3 class="titulo-parada">Dados de Endereço</h3>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="cep">CEP</label>
                        <input class="input" type="text" id="cep" name="cep" placeholder="00000-000" maxlength="9" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="numero">Número</label>
                        <input class="input" type="text" id="numero" name="numero" placeholder="Ex: 123" required>
                    </div>
                </div>

                <label class="dados" for="rua">Rua / Logradouro</label>
                <input class="input" type="text" id="rua" name="rua" placeholder="Digite o nome da rua ou avenida" required>

                <label class="dados" for="bairro">Bairro</label>
                <input class="input" type="text" id="bairro" name="bairro" placeholder="Digite o bairro" required>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="cidade">Cidade</label>
                        <input class="input" type="text" id="cidade" name="cidade" placeholder="Digite a cidade" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="estado">Estado (UF)</label>
                        <input class="input" type="text" id="estado" name="estado" placeholder="Ex: PR" maxlength="2" required>
                    </div>
                </div>
            </div>
        `;

        const inputCep = document.getElementById('cep');
        inputCep.addEventListener('input', (e) => {
            let valor = e.target.value.replace(/\D/g, '');
            if (valor.length > 5) {
                valor = valor.replace(/^(\d{5})(\d)/, '$1-$2');
            }
            e.target.value = valor;

            if (valor.replace('-', '').length === 8) {
                fetch(`https://viacep.com.br/ws/${valor.replace('-', '')}/json/`)
                    .then(res => res.json())
                    .then(dados => {
                        if (!dados.erro) {
                            document.getElementById('rua').value = dados.logradouro || '';
                            document.getElementById('bairro').value = dados.bairro || '';
                            document.getElementById('cidade').value = dados.localidade || '';
                            document.getElementById('estado').value = dados.uf || '';
                            document.getElementById('numero').focus();
                        }
                    })
                    .catch(() => {});
            }
        });

        itemAddDados.classList.add('escondido');
        itemRmvDados.classList.remove('escondido');
    });

    btnRmvDados.addEventListener('click', () => {
        containerDados.innerHTML = '';
        itemRmvDados.classList.add('escondido');
        itemAddDados.classList.remove('escondido');
    });
</script>

<?php include 'inc/footerEMP.inc.php'; ?>