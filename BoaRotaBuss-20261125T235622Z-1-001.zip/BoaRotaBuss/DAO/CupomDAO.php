<?php
namespace App\DAO;

use App\Model\Conexao;
use App\Model\Cupom;
use PDO;

class CupomDAO {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = Conexao::getConexao();
    }

    // CREATE
    public function criar(Cupom $cupom): bool {
        $sql = "INSERT INTO CUPOM (PARCEIRO_FK, CODIGO, DESCONTO, VALIDADE, DESCRICAO, QUANTIDADE_LIMITE, STATUS)
                VALUES (:parceiro_fk, :codigo, :desconto, :validade, :descricao, :limite, :status)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            ':parceiro_fk' => $cupom->getParceiroFk(),
            ':codigo'      => $cupom->getCodigo(),
            ':desconto'    => $cupom->getDesconto(),
            ':validade'    => $cupom->getValidade() ?: null,
            ':descricao'   => $cupom->getDescricao(),
            ':limite'      => $cupom->getQuantidadeLimite() ?: null,
            ':status'      => $cupom->getStatus()
        ]);
    }

    // READ (Listar todos com JOIN na tabela pai PARCEIRO)
    public function listarTodos(): array {
        $sql = "SELECT c.*, p.NOME AS NOME_PARCEIRO
                FROM CUPOM c
                INNER JOIN PARCEIRO p ON p.PARCEIRO_ID = c.PARCEIRO_FK
                ORDER BY c.CUPOM_ID DESC";
        $stmt = $this->pdo->query($sql);
        $lista = [];

        while ($row = $stmt->fetch()) {
            $lista[] = new Cupom(
                (int)$row['PARCEIRO_FK'],
                $row['CODIGO'],
                $row['DESCONTO'],
                $row['VALIDADE'],
                $row['DESCRICAO'],
                $row['QUANTIDADE_LIMITE'] !== null ? (int)$row['QUANTIDADE_LIMITE'] : null,
                $row['STATUS'],
                (int)$row['CUPOM_ID'],
                $row['NOME_PARCEIRO']
            );
        }
        return $lista;
    }

    // READ (Buscar 1 para edição)
    public function buscarPorId(int $id): ?Cupom {
        $sql = "SELECT * FROM CUPOM WHERE CUPOM_ID = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();

        if (!$row) return null;

        return new Cupom(
            (int)$row['PARCEIRO_FK'],
            $row['CODIGO'],
            $row['DESCONTO'],
            $row['VALIDADE'],
            $row['DESCRICAO'],
            $row['QUANTIDADE_LIMITE'] !== null ? (int)$row['QUANTIDADE_LIMITE'] : null,
            $row['STATUS'],
            (int)$row['CUPOM_ID']
        );
    }

    // UPDATE
    public function atualizar(Cupom $cupom): bool {
        $sql = "UPDATE CUPOM
                SET PARCEIRO_FK = :parceiro_fk, CODIGO = :codigo, DESCONTO = :desconto,
                    VALIDADE = :validade, DESCRICAO = :descricao,
                    QUANTIDADE_LIMITE = :limite, STATUS = :status
                WHERE CUPOM_ID = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            ':parceiro_fk' => $cupom->getParceiroFk(),
            ':codigo'      => $cupom->getCodigo(),
            ':desconto'    => $cupom->getDesconto(),
            ':validade'    => $cupom->getValidade() ?: null,
            ':descricao'   => $cupom->getDescricao(),
            ':limite'      => $cupom->getQuantidadeLimite() ?: null,
            ':status'      => $cupom->getStatus(),
            ':id'          => $cupom->getId()
        ]);
    }

    // DELETE
    public function deletar(int $id): bool {
        $sql = "DELETE FROM CUPOM WHERE CUPOM_ID = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}