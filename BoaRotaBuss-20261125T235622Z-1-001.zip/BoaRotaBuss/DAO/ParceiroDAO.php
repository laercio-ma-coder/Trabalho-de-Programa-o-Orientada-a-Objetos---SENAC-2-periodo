<?php
namespace App\DAO;

use App\Model\Conexao;
use App\Model\Parceiro;
use PDO;

class ParceiroDAO {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = Conexao::getConexao();
    }

    // CREATE
    public function criar(Parceiro $parceiro): bool {
        $sql = "INSERT INTO PARCEIRO (NOME, CATEGORIA, SITE_PROPRIO, DESCRICAO, TIPO)
                VALUES (:nome, :categoria, :site, :descricao, :tipo)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            ':nome'      => $parceiro->getNome(),
            ':categoria' => $parceiro->getCategoria(),
            ':site'      => $parceiro->getSiteProprio(),
            ':descricao' => $parceiro->getDescricao(),
            ':tipo'      => $parceiro->getTipo()
        ]);
    }

    // READ (Listar todos)
    public function listarTodos(): array {
        $sql = "SELECT * FROM PARCEIRO ORDER BY PARCEIRO_ID DESC";
        $stmt = $this->pdo->query($sql);
        $lista = [];

        while ($row = $stmt->fetch()) {
            $lista[] = new Parceiro(
                $row['NOME'],
                $row['CATEGORIA'],
                $row['SITE_PROPRIO'],
                $row['DESCRICAO'],
                $row['TIPO'],
                (int)$row['PARCEIRO_ID']
            );
        }
        return $lista;
    }

    // READ (Buscar 1 para edição)
    public function buscarPorId(int $id): ?Parceiro {
        $sql = "SELECT * FROM PARCEIRO WHERE PARCEIRO_ID = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();

        if (!$row) return null;

        return new Parceiro(
            $row['NOME'],
            $row['CATEGORIA'],
            $row['SITE_PROPRIO'],
            $row['DESCRICAO'],
            $row['TIPO'],
            (int)$row['PARCEIRO_ID']
        );
    }

    // UPDATE
    public function atualizar(Parceiro $parceiro): bool {
        $sql = "UPDATE PARCEIRO
                SET NOME = :nome, CATEGORIA = :categoria, SITE_PROPRIO = :site,
                    DESCRICAO = :descricao, TIPO = :tipo
                WHERE PARCEIRO_ID = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            ':nome'      => $parceiro->getNome(),
            ':categoria' => $parceiro->getCategoria(),
            ':site'      => $parceiro->getSiteProprio(),
            ':descricao' => $parceiro->getDescricao(),
            ':tipo'      => $parceiro->getTipo(),
            ':id'        => $parceiro->getId()
        ]);
    }

    // DELETE
    public function deletar(int $id): bool {
        $sql = "DELETE FROM PARCEIRO WHERE PARCEIRO_ID = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}