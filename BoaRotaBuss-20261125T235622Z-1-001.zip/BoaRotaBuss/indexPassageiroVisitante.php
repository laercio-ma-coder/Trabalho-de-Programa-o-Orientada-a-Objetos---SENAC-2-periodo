<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoaRotaBuss — Consulta Rápida de Passagem</title>
    <link rel="stylesheet" href="css/stylePSG.css">
</head>
<body>

    <!-- Cabeçalho simplificado para acesso rápido sem login -->
    <header class="cabecalho">
        <div class="marca-header" style="display: flex; align-items: center; gap: 8px;">
            <a href="index.php" title="Voltar para a Página Inicial" style="display: inline-flex; align-items: center;">
                <img class="logo" src="img/BRB.png" alt="Logo do BoaRotaBuss">
            </a>
            <span class="buttonnv" style="cursor: default;">Acesso Rápido • Visitante</span>
        </div>

        <nav class="menu">
            <a class="buttonnv" href="indexLoginPassageiro.php">Voltar ao Login</a>
        </nav>
    </header>

    <main class="pagina">
        <section class="card">
            <h1 class="title">Consultar Viagem pelo Bilhete / QR Code</h1>
            <p class="subtitle">
                Não tem conta cadastrada? Digite o código da sua passagem e seu CPF para acompanhar o ônibus e o trajeto.
            </p>

            <!-- Formulário de consulta rápida -->
            <form id="formVisitante">
                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="vis-codigo">Código da Passagem</label>
                        <input class="input" type="text" id="vis-codigo" placeholder="Ex: BRB-9001" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="vis-cpf">CPF do Passageiro</label>
                        <input class="input" type="text" id="vis-cpf" placeholder="000.000.000-00" maxlength="14" required>
                    </div>
                </div>

                <div class="botoes">
                    <button type="submit" class="buttonLGN">Consultar Passagem</button>
                    <button type="button" class="buttonLGN secundario" id="btnSimularQr">Simular Leitura QR Code</button>
                </div>
            </form>

            <!-- Resultado da consulta (aparece após consultar) -->
            <div id="resultadoVisitante" class="escondido" style="margin-top: 16px;">
                <dl class="detalhes">
                    <div><dt>Passageiro</dt><dd id="resNome">Ana Clara Souza</dd></div>
                    <div><dt>Código / Assento</dt><dd id="resBilhete">BRB-9001 • Poltrona 01</dd></div>
                    <div><dt>Rota</dt><dd>Ponta Grossa - PR → Foz do Iguaçu - PR</dd></div>
                    <div><dt>Saída / Status</dt><dd>21/11/2026 às 08:00 • Em Trânsito</dd></div>
                </dl>

                <div class="botoes">
                    <a href="indexPassageiro.php" class="buttonLGN">Abrir Painel Completo da Viagem →</a>
                </div>
            </div>
        </section>
    </main>

    <script>
        // Máscara automática de CPF (000.000.000-00)
        document.getElementById('vis-cpf').addEventListener('input', (e) => {
            let v = e.target.value.replace(/\D/g, '').slice(0, 11);
            v = v.replace(/(\d{3})(\d)/, '$1.$2')
                 .replace(/(\d{3})(\d)/, '$1.$2')
                 .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            e.target.value = v;
        });

        // Exibe os dados simulados da passagem ao enviar o formulário
        document.getElementById('formVisitante').addEventListener('submit', (e) => {
            e.preventDefault();
            const codigo = document.getElementById('vis-codigo').value.toUpperCase();
            document.getElementById('resBilhete').textContent = `${codigo} • Poltrona 01`;
            document.getElementById('resultadoVisitante').classList.remove('escondido');
        });

        // Preenche automaticamente para demonstração rápida da leitura de QR Code
        document.getElementById('btnSimularQr').addEventListener('click', () => {
            document.getElementById('vis-codigo').value = 'BRB-9001';
            document.getElementById('vis-cpf').value = '123.456.789-00';
            document.getElementById('resultadoVisitante').classList.remove('escondido');
        });
    </script>

<?php include 'inc/footer.inc.php'; ?>