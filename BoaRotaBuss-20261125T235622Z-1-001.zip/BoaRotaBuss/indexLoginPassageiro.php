<?php
// Inicia a sessão para exibir mensagens de erro de login, caso existam
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$erroLogin = $_SESSION['erro_login'] ?? '';
unset($_SESSION['erro_login']); // Limpa o erro após exibir uma vez
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoaRotaBuss — Acesso Passageiro e Motorista</title>
    <!-- Folha de estilos da área do passageiro -->
    <link rel="stylesheet" href="css/stylePSG.css">
</head>
<body class="tela-login">
    <main class="container">

        <!-- Botão flutuante para retornar à vitrine inicial -->
        <a class="retorar" href="index.php" aria-label="Voltar para a página inicial"><</a>

        <!-- ==========================================================
             CARTÃO CIRCULAR 1: FORMULÁRIO DE LOGIN
             Envia os dados via POST para processaLogin.php (que usa Autenticador.php)
             ========================================================== -->
        <section class="login" id="login">
            <h1 class="title">Bem-vindo ao BoaRotaBuss</h1>
            <p class="subtitle">
                Acompanhe sua viagem, confira sua poltrona e receba avisos em tempo real.
            </p>

            <!-- Exibe alerta visual caso o e-mail ou senha sejam rejeitados -->
            <?php if ($erroLogin !== ''): ?>
                <div class="erro"><?= htmlspecialchars($erroLogin) ?></div>
            <?php endif; ?>

            <form action="processaLogin.php" method="post">
                <label class="dados" for="login-usuario">Usuário ou e-mail</label>
                <input class="input" type="text" id="login-usuario" name="usuario"
                       placeholder="Ex: ana@gmail.com" required>

                <label class="dados" for="login-senha">Senha</label>
                <input class="input" type="password" id="login-senha" name="senha"
                       placeholder="Digite sua senha" required>

                <div class="botoes">
                    <button type="submit" class="buttonLGN" id="login-btn">Entrar</button>
                    <button type="button" class="buttonLGN secundario" id="ir-registrar">Registrar</button>
                    <!-- Acesso rápido sem senha para quem tem o código/QR Code da passagem -->
                    <a href="indexPassageiroVisitante.php" class="buttonLGN" id="ir-terceiro">Ler QR Code</a>
                </div>
            </form>

            <!-- Atalho para a tela de login exclusivo de empresas -->
            <a href="indexLoginEmpresa.php" class="link">Entrar com login empresarial</a>
        </section>

        <!-- ==========================================================
             CARTÃO CIRCULAR 2: FORMULÁRIO DE CADASTRO (OCULTO POR PADRÃO)
             ========================================================== -->
        <section class="registrar escondido" id="registrar">
            <h1 class="title">Criar Conta</h1>
            <p class="subtitle">Preencha os campos abaixo para criar sua conta de passageiro.</p>

            <form action="registrarPassageiro.php" method="post">
                <div class="campo">
                    <label class="dados" for="reg-nome">Nome completo</label>
                    <input class="input" type="text" id="reg-nome" name="nome"
                           placeholder="Digite seu nome completo" required>
                </div>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="reg-email">E-mail</label>
                        <input class="input" type="email" id="reg-email" name="email"
                               placeholder="Digite seu e-mail" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="reg-tel">Telefone</label>
                        <input class="input" type="tel" id="reg-tel" name="telefone"
                               placeholder="(42) 99999-9999" required>
                    </div>
                </div>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="reg-senha">Senha</label>
                        <input class="input" type="password" id="reg-senha" name="senha"
                               placeholder="Digite sua senha" required>
                    </div>
                    <div class="campo">
                        <label class="dados" for="reg-senha2">Confirmar senha</label>
                        <input class="input" type="password" id="reg-senha2" name="senha2"
                               placeholder="Repita a senha" required>
                    </div>
                </div>

                <p class="aviso">Sua senha deve ter no mínimo:</p>
                <ul class="lista-regras">
                    <li class="regras">8 caracteres</li>
                    <li class="regras">Letras maiúsculas</li>
                    <li class="regras">Letras minúsculas</li>
                    <li class="regras">Números</li>
                    <li class="regras">Caracteres especiais</li>
                </ul>

                <div class="botoes">
                    <button type="button" class="buttonLGN secundario" id="voltar-login">Voltar</button>
                    <button type="submit" class="buttonLGN" id="registrar-btn">Registrar</button>
                </div>
            </form>
        </section>
    </main>

    <script>
        // Alterna a exibição entre os círculos de Login e Cadastro sem recarregar a página
        const login     = document.getElementById('login');
        const registrar = document.getElementById('registrar');

        document.getElementById('ir-registrar').addEventListener('click', () => {
            login.classList.add('escondido');
            registrar.classList.remove('escondido');
        });

        document.getElementById('voltar-login').addEventListener('click', () => {
            registrar.classList.add('escondido');
            login.classList.remove('escondido');
        });
    </script>
</body>
</html>