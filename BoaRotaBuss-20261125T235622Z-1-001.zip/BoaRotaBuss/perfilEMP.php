<?php include 'inc/headerEMP.inc.php'; ?>
<?php include 'inc/menuLateralEMP.inc.php'; ?>

<main class="tela">
    <section class="cadastrar-viagem" id="perfil-empresa">
        <div class="topo-listagem">
            <h1 class="title">Perfil Empresarial</h1>
            <a class="btn-excluir" id="sair" href="indexLoginEmpresa.php">Sair da Conta</a>
        </div>

        <!-- ==========================================================
             CARTÃO DE IDENTIDADE CORPORATIVA
             ========================================================== -->
        <div class="cabecalho-perfil-emp">
            <div class="avatar-empresa">
                <img src="img/BRB.png" alt="Logo da Empresa">
            </div>

            <div class="dados-principais-emp">
                <span class="badge-paradas com-paradas">Empresa Verificada</span>
                <h2>Viação BoaRota Transportes Ltda.</h2>
                <p class="cnpj-emp"><strong>CNPJ:</strong> 12.345.678/0001-90</p>
            </div>
        </div>

        <!-- ==========================================================
             GRADE DE DADOS CADASTRAIS DA EMPRESA
             ========================================================== -->
        <div class="grid-info-empresa">
            <div class="card-info-emp">
                <span class="rotulo-info">E-mail Corporativo</span>
                <strong>contato@boarotabuss.com.br</strong>
            </div>

            <div class="card-info-emp">
                <span class="rotulo-info">Telefone / Central</span>
                <strong>(42) 3220-4500</strong>
            </div>

            <div class="card-info-emp">
                <span class="rotulo-info">Sede / Garagem Principal</span>
                <strong>Ponta Grossa - PR</strong>
            </div>

            <div class="card-info-emp">
                <span class="rotulo-info">Frota e Equipe Ativa</span>
                <strong>4 Ônibus • 3 Motoristas</strong>
            </div>

            <div class="card-info-emp linha-inteira">
                <span class="rotulo-info">Sobre a Empresa</span>
                <p>Especializada no transporte intermunicipal e fretamento corporativo na região dos Campos Gerais e Curitiba, com foco em pontualidade, conforto e segurança.</p>
            </div>
        </div>

        <div class="botoes">
            <button type="button" class="buttonLGN" id="btnEditarPerfil">Editar Dados da Empresa</button>
        </div>

        <!-- ==========================================================
             FORMULÁRIO EXPANSÍVEL DE EDIÇÃO
             ========================================================== -->
        <form action="atualizarPerfilEmpresa.php" method="POST" id="form-editar-perfil" class="box-parada sub-painel-config escondido">
            <h3 class="titulo-parada">Atualizar Informações Empresariais</h3>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="razao_social">Razão Social</label>
                    <input class="input" type="text" id="razao_social" name="razao_social" value="Viação BoaRota Transportes Ltda." required>
                </div>
                <div class="campo">
                    <label class="dados" for="cnpj">CNPJ</label>
                    <input class="input" type="text" id="cnpj" name="cnpj" value="12.345.678/0001-90" maxlength="18" required>
                </div>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="email_emp">E-mail Corporativo</label>
                    <input class="input" type="email" id="email_emp" name="email_emp" value="contato@boarotabuss.com.br" required>
                </div>
                <div class="campo">
                    <label class="dados" for="telefone_emp">Telefone</label>
                    <input class="input" type="tel" id="telefone_emp" name="telefone_emp" value="(42) 3220-4500" required>
                </div>
            </div>

            <label class="dados" for="descricao_emp">Descrição / Informações da Empresa</label>
            <textarea class="input" id="descricao_emp" name="descricao_emp" rows="3">Especializada no transporte intermunicipal e fretamento corporativo na região dos Campos Gerais e Curitiba, com foco em pontualidade, conforto e segurança.</textarea>

            <div class="botoes">
                <button type="submit" class="buttonLGN">Salvar Alterações</button>
                <button type="button" class="btn-excluir" id="btnCancelarPerfil">Cancelar</button>
            </div>
        </form>
    </section>
</main>

<script>
    // Alterna a visibilidade do formulário de edição e rola suavemente até ele
    const btnEditarPerfil   = document.getElementById('btnEditarPerfil');
    const btnCancelarPerfil = document.getElementById('btnCancelarPerfil');
    const formEditarPerfil  = document.getElementById('form-editar-perfil');

    btnEditarPerfil.addEventListener('click', () => {
        formEditarPerfil.classList.toggle('escondido');
        if (!formEditarPerfil.classList.contains('escondido')) {
            formEditarPerfil.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    });

    btnCancelarPerfil.addEventListener('click', () => {
        formEditarPerfil.classList.add('escondido');
    });
</script>

<?php include 'inc/footerEMP.inc.php'; ?>