<?php
require_once __DIR__ . '/classes/BancoJson.php';
$historicoMensagens = BancoJson::ler('chat_atendimento');
$empresasCadastradas = BancoJson::ler('empresas');

// Empresas padrão da vitrine caso ainda não haja cadastros extras no JSON
if (empty($empresasCadastradas)) {
    $empresasCadastradas = [
        [
            'nome_fantasia' => 'Viação BoaRota',
            'razao_social'  => 'Viação BoaRota Transportes Rodoviários Ltda',
            'logo'          => 'img/BRB.png',
            'descricao'     => 'Operação monitorada em tempo real nos Campos Gerais com check-in digital de poltronas.'
        ],
        [
            'nome_fantasia' => 'Expresso Campos Gerais',
            'razao_social'  => 'Expresso Campos Gerais Fretamento & Turismo S.A.',
            'logo'          => 'img/BRB.png',
            'descricao'     => 'Microescapadas de fim de semana, fretamento turístico e linhas intermunicipais.'
        ],
        [
            'nome_fantasia' => 'TransParaná Turismo',
            'razao_social'  => 'TransParaná Agência e Receptivo Turístico Ltda',
            'logo'          => 'img/BRB.png',
            'descricao'     => 'Pacotes rodoviários completos com receptivo local e suporte 24h ao viajante.'
        ]
    ];
}
?>
<script>
    const DADOS_CHAT_SALVOS = <?= json_encode($historicoMensagens, JSON_UNESCAPED_UNICODE) ?>;
</script>
<?php if (isset($_GET['chat']) && $_GET['chat'] === 'enviado'): ?>
<script>
    window.addEventListener('DOMContentLoaded', () => {
        alert('Mensagem enviada com sucesso! A empresa responderá em breve no seu contato informado.');
    });
</script>
<?php endif; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoaRotaBuss — Conexão Inteligente de Rotas e Turismo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- ==========================================================
         HEADER COM LOGO, BARRA DE PESQUISA E BOTÕES
         ========================================================== -->
    <header class="cabecalho-home">
        <a href="index.php" class="logo-home">
            <img src="img/BRB.png" alt="Logo BoaRotaBuss">
            <span>BoaRota<strong>Buss</strong></span>
        </a>

        <!-- Barra de pesquisa rápida -->
        <form class="barra-pesquisa-header" id="formPesquisaHeader" onsubmit="return false;">
            <input type="search" id="inputPesquisaHome"
                   placeholder="Pesquisar destino, pacote, origem ou empresa..."
                   aria-label="Pesquisar rotas e pacotes">
            <button type="submit" id="btnPesquisarHome">Buscar</button>
        </form>

        <!-- Botões de navegação -->
        <nav class="nav-home">
            <a href="#viagens-mes" class="link-nav">Rotas em Alta</a>
            <a href="#empresas-afiliadas" class="link-nav">Empresas</a>
            <a href="indexLoginPassageiro.php" class="btn-entrar-header">Acessar Minha Viagem</a>
        </nav>
    </header>

    <!-- ==========================================================
         HERO / CHAMADA SOBRE O FUNDO DE PAISAGEM
         ========================================================== -->
    <section class="hero-paisagem">
        <div class="hero-conteudo">
            <span class="tag-hero">Conectando viajantes, motoristas e empresas de turismo</span>
            <h1>Descubra rotas em alta e fale direto com quem opera sua viagem</h1>
            <p>Explore destinos intermunicipais e pacotes turísticos publicados por viações parceiras, tire dúvidas no chat direto e acompanhe todo o trajeto pelo sistema.</p>
        </div>
    </section>

    <!-- ==========================================================
         TELA EM BRANCO PRINCIPAL
         ========================================================== -->
    <main class="tela-branca-home">

        <!-- 1. ROTAS E PACOTES PUBLICADOS PELAS EMPRESAS (CARROSSEL BANNER) -->
        <section class="secao-home">
            <div class="topo-secao-home">
                <div>
                    <span class="etiqueta-secao">Publicações em Destaque</span>
                    <h2>Rotas e Pacotes Divulgados pelas Empresas</h2>
                </div>
                <span class="info-contador">Atendimento direto sem intermediários</span>
            </div>

            <div class="carrossel-destaque-wrapper">
                <!-- Seta Esquerda -->
                <button type="button" class="seta-carrossel seta-anterior" id="btnSlideAnterior" aria-label="Viagem anterior">❮</button>

                <div class="carrossel-viewport">
                    <div class="carrossel-trilho" id="trilhoDestaque">

                        <!-- Slide 1 -->
                        <article class="slide-destaque item-buscavel">
                            <div class="slide-imagem-box">
                                <img src="https://images.unsplash.com/photo-1589394815804-964ed0be2eb5?auto=format&fit=crop&w=900&q=80"
                                     onerror="this.src='img/BRB.png'"
                                     alt="Cataratas do Iguaçu — Foz do Iguaçu">
                                <span class="slide-selo-foto">Destino #1 em Procura</span>
                            </div>

                            <div class="slide-info-box">
                                <div>
                                    <div class="slide-topo-empresa">
                                        <span class="nome-empresa-badge">Viação BoaRota</span>
                                        <span class="tag-patrocinado">Em Alta</span>
                                    </div>
                                    <h3 class="slide-titulo-rota">Ponta Grossa - PR → Foz do Iguaçu - PR</h3>
                                    <div class="slide-lista-detalhes">
                                        <span><strong>Próxima Saída:</strong> 21/11/2026 às 08:00</span>
                                        <span><strong>Pacote Incluso:</strong> Transporte Leito + Receptivo Cataratas + Seguro Viagem</span>
                                        <span><strong>Conforto a Bordo:</strong> Poltrona Reclinável • Wi-Fi • Ar-condicionado • WC</span>
                                    </div>
                                </div>

                                <div class="slide-rodape">
                                    <div class="preco-box">
                                        <small>Referência a partir de</small>
                                        <strong>R$ 145,00</strong>
                                    </div>
                                    <button type="button" class="btn-reservar btn-abrir-chat"
                                            data-empresa="Viação BoaRota"
                                            data-rota="Ponta Grossa - PR → Foz do Iguaçu - PR"
                                            data-saida="21/11/2026 às 08:00">
                                        Falar com a Empresa →
                                    </button>
                                </div>
                            </div>
                        </article>

                        <!-- Slide 2 -->
                        <article class="slide-destaque item-buscavel">
                            <div class="slide-imagem-box">
                                <img src="https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=900&q=80"
                                     onerror="this.src='img/BRB.png'"
                                     alt="Serra do Mar — Morretes e Antonina">
                                <span class="slide-selo-foto">Bate e Volta de Fim de Semana</span>
                            </div>

                            <div class="slide-info-box">
                                <div>
                                    <div class="slide-topo-empresa">
                                        <span class="nome-empresa-badge">Expresso Campos Gerais</span>
                                        <span class="tag-patrocinado">Microescapada</span>
                                    </div>
                                    <h3 class="slide-titulo-rota">Curitiba - PR → Morretes & Antonina</h3>
                                    <div class="slide-lista-detalhes">
                                        <span><strong>Próxima Saída:</strong> 22/11/2026 às 07:00</span>
                                        <span><strong>Pacote Incluso:</strong> Ida e Volta + Guia Local + Parada Gastronômica (Barreado)</span>
                                        <span><strong>Conforto a Bordo:</strong> Ônibus Executivo • Ar-condicionado • Seguro</span>
                                    </div>
                                </div>

                                <div class="slide-rodape">
                                    <div class="preco-box">
                                        <small>Referência a partir de</small>
                                        <strong>R$ 89,90</strong>
                                    </div>
                                    <button type="button" class="btn-reservar btn-abrir-chat"
                                            data-empresa="Expresso Campos Gerais"
                                            data-rota="Curitiba - PR → Morretes & Antonina"
                                            data-saida="22/11/2026 às 07:00">
                                        Falar com a Empresa →
                                    </button>
                                </div>
                            </div>
                        </article>

                        <!-- Slide 3 -->
                        <article class="slide-destaque item-buscavel">
                            <div class="slide-imagem-box">
                                <img src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=900&q=80"
                                     onerror="this.src='img/BRB.png'"
                                     alt="Serra Catarinense — Urubici">
                                <span class="slide-selo-foto">Especial Feriado</span>
                            </div>

                            <div class="slide-info-box">
                                <div>
                                    <div class="slide-topo-empresa">
                                        <span class="nome-empresa-badge">TransParaná Turismo</span>
                                        <span class="tag-patrocinado">Feriado</span>
                                    </div>
                                    <h3 class="slide-titulo-rota">Ponta Grossa - PR → Serra Catarinense (Urubici)</h3>
                                    <div class="slide-lista-detalhes">
                                        <span><strong>Próxima Saída:</strong> 27/11/2026 às 22:00</span>
                                        <span><strong>Pacote Incluso:</strong> Ônibus Semi-leito + Traslado nos Mirantes + Guia</span>
                                        <span><strong>Conforto a Bordo:</strong> Semi-leito • Mantas • Wi-Fi • WC</span>
                                    </div>
                                </div>

                                <div class="slide-rodape">
                                    <div class="preco-box">
                                        <small>Referência a partir de</small>
                                        <strong>R$ 210,00</strong>
                                    </div>
                                    <button type="button" class="btn-reservar btn-abrir-chat"
                                            data-empresa="TransParaná Turismo"
                                            data-rota="Ponta Grossa - PR → Serra Catarinense"
                                            data-saida="27/11/2026 às 22:00">
                                        Falar com a Empresa →
                                    </button>
                                </div>
                            </div>
                        </article>

                    </div>
                </div>

                <!-- Seta Direita -->
                <button type="button" class="seta-carrossel seta-proxima" id="btnSlideProximo" aria-label="Próxima viagem">❯</button>
            </div>

            <!-- Bolinhas de navegação -->
            <div class="indicadores-carrossel" id="indicadoresCarrossel">
                <button type="button" class="ponto-carrossel ativo" data-slide="0" aria-label="Slide 1"></button>
                <button type="button" class="ponto-carrossel" data-slide="1" aria-label="Slide 2"></button>
                <button type="button" class="ponto-carrossel" data-slide="2" aria-label="Slide 3"></button>
            </div>
        </section>

        <hr class="divisor-home">

        <!-- 2. TOP 3 DESTINOS MAIS PROCURADOS NA PLATAFORMA -->
        <section class="secao-home">
            <div class="topo-secao-home">
                <div>
                    <span class="etiqueta-secao">Termômetro de Viagens</span>
                    <h2>Top 3 Rotas Mais Procuradas na Plataforma</h2>
                </div>
            </div>

            <div class="grid-top3">
                <!-- Top 1 -->
                <div class="card-top3 item-buscavel">
                    <div class="ranking-numero">#1</div>
                    <div class="info-top3">
                        <span class="empresa-top3">Viação BoaRota</span>
                        <h3>Ponta Grossa → Curitiba</h3>
                        <p>Saídas diárias • <strong>Próxima: 21/11/2026 às 08:00</strong> • Ref. R$ 42,90</p>
                    </div>
                    <button type="button" class="btn-top3 btn-abrir-chat"
                            data-empresa="Viação BoaRota"
                            data-rota="Ponta Grossa → Curitiba"
                            data-saida="21/11/2026 às 08:00">
                        Consultar Empresa
                    </button>
                </div>

                <!-- Top 2 -->
                <div class="card-top3 item-buscavel">
                    <div class="ranking-numero">#2</div>
                    <div class="info-top3">
                        <span class="empresa-top3">Expresso Campos Gerais</span>
                        <h3>Ponta Grossa → Foz do Iguaçu</h3>
                        <p>Rota turística • <strong>Próxima: 21/11/2026 às 08:00</strong> • Ref. R$ 145,00</p>
                    </div>
                    <button type="button" class="btn-top3 btn-abrir-chat"
                            data-empresa="Expresso Campos Gerais"
                            data-rota="Ponta Grossa → Foz do Iguaçu"
                            data-saida="21/11/2026 às 08:00">
                        Consultar Empresa
                    </button>
                </div>

                <!-- Top 3 -->
                <div class="card-top3 item-buscavel">
                    <div class="ranking-numero">#3</div>
                    <div class="info-top3">
                        <span class="empresa-top3">Viação BoaRota</span>
                        <h3>Ponta Grossa → Castro (Rota Cultural)</h3>
                        <p>Bate e volta • <strong>Próxima: 22/11/2026 às 14:30</strong> • Ref. R$ 24,00</p>
                    </div>
                    <button type="button" class="btn-top3 btn-abrir-chat"
                            data-empresa="Viação BoaRota"
                            data-rota="Ponta Grossa → Castro"
                            data-saida="22/11/2026 às 14:30">
                        Consultar Empresa
                    </button>
                </div>
            </div>
        </section>

        <hr class="divisor-home">

        <!-- 3. GRADE COMPLETA DE PUBLICAÇÕES DO MÊS -->
        <section class="secao-home secao-discreta" id="viagens-mes">
            <div class="topo-secao-home">
                <div>
                    <h2>Agenda de Viagens Publicadas no Mês (Novembro/2026)</h2>
                    <p class="sub-discreto">Escolha uma saída e abra o chat direto com a empresa para combinar embarque e pacote</p>
                </div>
                <span class="contador-mes" id="contadorViagensMes">6 publicações ativas</span>
            </div>

            <div class="tabela-responsiva-home">
                <table class="tabela-mes">
                    <thead>
                        <tr>
                            <th>Saída Prevista</th>
                            <th>Rota / Destino</th>
                            <th>Empresa Responsável</th>
                            <th>Modalidade / Pacote</th>
                            <th>Valor Ref.</th>
                            <th>Atendimento</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="item-buscavel">
                            <td>21/11/2026 - 08:00</td>
                            <td><strong>Ponta Grossa → Foz do Iguaçu</strong></td>
                            <td>Viação BoaRota</td>
                            <td>Transporte + Receptivo</td>
                            <td>R$ 145,00</td>
                            <td><button type="button" class="link-tabela btn-abrir-chat" data-empresa="Viação BoaRota" data-rota="Ponta Grossa → Foz do Iguaçu" data-saida="21/11/2026 - 08:00">Iniciar Chat</button></td>
                        </tr>
                        <tr class="item-buscavel">
                            <td>21/11/2026 - 08:00</td>
                            <td><strong>Ponta Grossa → Curitiba</strong></td>
                            <td>Viação BoaRota</td>
                            <td>Linha Direta (3 paradas)</td>
                            <td>R$ 42,90</td>
                            <td><button type="button" class="link-tabela btn-abrir-chat" data-empresa="Viação BoaRota" data-rota="Ponta Grossa → Curitiba" data-saida="21/11/2026 - 08:00">Iniciar Chat</button></td>
                        </tr>
                        <tr class="item-buscavel">
                            <td>22/11/2026 - 07:00</td>
                            <td><strong>Curitiba → Morretes & Antonina</strong></td>
                            <td>Expresso Campos Gerais</td>
                            <td>Bate e Volta + Guia</td>
                            <td>R$ 89,90</td>
                            <td><button type="button" class="link-tabela btn-abrir-chat" data-empresa="Expresso Campos Gerais" data-rota="Curitiba → Morretes & Antonina" data-saida="22/11/2026 - 07:00">Iniciar Chat</button></td>
                        </tr>
                        <tr class="item-buscavel">
                            <td>22/11/2026 - 14:30</td>
                            <td><strong>Ponta Grossa → Castro</strong></td>
                            <td>Viação BoaRota</td>
                            <td>Excursão Cultural</td>
                            <td>R$ 24,00</td>
                            <td><button type="button" class="link-tabela btn-abrir-chat" data-empresa="Viação BoaRota" data-rota="Ponta Grossa → Castro" data-saida="22/11/2026 - 14:30">Iniciar Chat</button></td>
                        </tr>
                        <tr class="item-buscavel">
                            <td>24/11/2026 - 22:30</td>
                            <td><strong>Ponta Grossa → Londrina</strong></td>
                            <td>TransParaná Turismo</td>
                            <td>Semi-leito Noturno</td>
                            <td>R$ 95,00</td>
                            <td><button type="button" class="link-tabela btn-abrir-chat" data-empresa="TransParaná Turismo" data-rota="Ponta Grossa → Londrina" data-saida="24/11/2026 - 22:30">Iniciar Chat</button></td>
                        </tr>
                        <tr class="item-buscavel">
                            <td>27/11/2026 - 22:00</td>
                            <td><strong>Ponta Grossa → Serra Catarinense</strong></td>
                            <td>TransParaná Turismo</td>
                            <td>Pacote Fim de Semana</td>
                            <td>R$ 210,00</td>
                            <td><button type="button" class="link-tabela btn-abrir-chat" data-empresa="TransParaná Turismo" data-rota="Ponta Grossa → Serra Catarinense" data-saida="27/11/2026 - 22:00">Iniciar Chat</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>

        <hr class="divisor-home">

        <!-- 4. EMPRESAS AFILIADAS (VITRINE COM LOGO E RAZÃO SOCIAL) -->
        <section class="secao-home" id="empresas-afiliadas">
            <div class="topo-secao-home">
                <div>
                    <span class="etiqueta-secao">Ecossistema Conectado</span>
                    <h2>Empresas Afiliadas</h2>
                </div>
                <a href="indexLoginEmpresa.php" class="link-anunciar">Cadastre sua empresa e publique rotas →</a>
            </div>

            <div class="grid-afiliadas-home">
                <?php foreach ($empresasCadastradas as $emp): 
                    $logoEmp = !empty($emp['logo']) ? $emp['logo'] : 'img/BRB.png';
                    $razaoEmp = $emp['razao_social'] ?? $emp['nome_fantasia'] ?? 'Empresa Parceira';
                    $fantasiaEmp = $emp['nome_fantasia'] ?? $razaoEmp;
                ?>
                    <article class="card-afiliada-home item-buscavel">
                        <img class="logo-afiliada-home"
                             src="<?= htmlspecialchars($logoEmp) ?>"
                             alt="Logo de <?= htmlspecialchars($razaoEmp) ?>">

                        <div class="info-afiliada-home">
                            <h3><?= htmlspecialchars($razaoEmp) ?></h3>
                            <?php if (!empty($emp['descricao'])): ?>
                                <p><?= htmlspecialchars($emp['descricao']) ?></p>
                            <?php endif; ?>
                        </div>

                        <button type="button" class="btn-reservar btn-abrir-chat"
                                data-empresa="<?= htmlspecialchars($fantasiaEmp) ?>"
                                data-rota="Atendimento Geral — <?= htmlspecialchars($fantasiaEmp) ?>"
                                data-saida="A combinar com a empresa">
                            Falar com a Empresa
                        </button>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

    </main>

    <!-- ==========================================================
         FOOTER COM CONTATOS, REDES SOCIAIS E BOTÃO DE EMERGÊNCIAS
         ========================================================== -->
    <footer class="rodape-home">
        <div class="conteudo-rodape">
            <div class="coluna-rodape">
                <h3>BoaRotaBuss</h3>
                <p>Plataforma inteligente de conexão, monitoramento operacional e experiência em viagens rodoviárias.</p>
                <p class="copyright">© 2026 BoaRotaBuss. Todos os direitos reservados.</p>
            </div>

            <div class="coluna-rodape">
                <h4>Contatos</h4>
                <p>E-mail: contato@boarotabuss.com.br</p>
                <p>Central de Atendimento: (42) 3220-4500</p>
                <p>Ponta Grossa — Paraná, Brasil</p>
            </div>

            <div class="coluna-rodape">
                <h4>Redes Sociais</h4>
                <div class="redes-sociais">
                    <a href="#" aria-label="Instagram">Instagram</a>
                    <a href="#" aria-label="Facebook">Facebook</a>
                    <a href="#" aria-label="WhatsApp">WhatsApp</a>
                </div>
            </div>

            <div class="coluna-rodape coluna-emergencia">
                <h4>Apoio ao Passageiro</h4>
                <button type="button" class="btn-emergencia" id="btnAbrirEmergencia" title="Contatos de Emergência">
                    !
                </button>
            </div>
        </div>
    </footer>

    <!-- ==========================================================
         MODAL 1: CHAT DIRETO COM A EMPRESA (NEGOCIAÇÃO / PACOTE)
         ========================================================== -->
    <div class="modal-overlay escondido" id="modalChatEmpresa" role="dialog" aria-modal="true" aria-labelledby="tituloChatEmpresa">
        <div class="modal-emergencia-box">
            <div class="topo-modal-emergencia">
                <div>
                    <span class="tag-urgencia" style="background: rgba(14,127,148,0.15); color: #0a4a5c;" id="chatNomeEmpresa">Empresa</span>
                    <h2 id="tituloChatEmpresa">Chat Direto sobre a Viagem</h2>
                </div>
                <button type="button" class="btn-fechar-modal" id="btnFecharChat" aria-label="Fechar chat">×</button>
            </div>

            <p class="texto-modal-emergencia" id="chatResumoRota" style="margin-bottom: 12px;">
                Rota selecionada
            </p>

            <!-- Histórico visual da conversa -->
            <div id="historicoChatHome" style="background:#f4f9fa; border:1px solid #cde4e9; border-radius:14px; padding:14px; max-height:190px; overflow-y:auto; margin-bottom:14px; font-size:0.88rem;">
                <div style="background:#e1f3f6; color:#06303d; padding:10px 12px; border-radius:12px; margin-bottom:8px;">
                    <strong id="chatBoasVindasEmpresa">Atendimento:</strong> Olá! Envie sua mensagem abaixo para consultar poltronas disponíveis, pontos de embarque ou detalhes do pacote incluso.
                </div>
            </div>

            <form action="enviarMensagemChat.php" method="post" id="formChatHome">
                <input type="hidden" name="empresa" id="inputChatEmpresa">
                <input type="hidden" name="rota" id="inputChatRota">

                <div style="display:flex; gap:8px; margin-bottom:8px;">
                    <input type="text" name="nome_interessado" id="inputChatNome" placeholder="Seu nome" required
                           style="flex:1; padding:10px 12px; border:1px solid #cde4e9; border-radius:10px; font-size:0.88rem;">
                    <input type="text" name="contato_interessado" id="inputChatContato" placeholder="Seu WhatsApp ou E-mail" required
                           style="flex:1; padding:10px 12px; border:1px solid #cde4e9; border-radius:10px; font-size:0.88rem;">
                </div>

                <div style="display:flex; gap:8px;">
                    <input type="text" name="mensagem" id="inputChatMensagem" placeholder="Escreva sua dúvida ou pedido de reserva..." required
                           style="flex:1; padding:10px 12px; border:1px solid #cde4e9; border-radius:10px; font-size:0.88rem;">
                    <button type="submit" class="btn-reservar" style="border:none; cursor:pointer;">Enviar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ==========================================================
         MODAL 2: CONTATOS DE EMERGÊNCIA
         ========================================================== -->
    <div class="modal-overlay escondido" id="modalEmergencia" role="dialog" aria-modal="true" aria-labelledby="tituloEmergencia">
        <div class="modal-emergencia-box">
            <div class="topo-modal-emergencia">
                <div>
                    <span class="tag-urgencia">Atendimento Imediato 24h</span>
                    <h2 id="tituloEmergencia">Contatos de Emergência</h2>
                </div>
                <button type="button" class="btn-fechar-modal" id="btnFecharEmergencia" aria-label="Fechar janela">×</button>
            </div>

            <p class="texto-modal-emergencia">
                Em caso de acidente, mal-estar a bordo ou situação de risco durante a viagem, acione imediatamente um dos serviços abaixo:
            </p>

            <div class="lista-contatos-emergencia">
                <a href="tel:190" class="card-contato-emergencia policia">
                    <div>
                        <strong>Polícia Militar</strong>
                        <span>Segurança pública e ocorrências policiais</span>
                    </div>
                    <span class="numero-emergencia">190</span>
                </a>

                <a href="tel:193" class="card-contato-emergencia bombeiro">
                    <div>
                        <strong>Corpo de Bombeiros</strong>
                        <span>Resgate, incêndios e salvamento</span>
                    </div>
                    <span class="numero-emergencia">193</span>
                </a>

                <a href="tel:192" class="card-contato-emergencia hospital">
                    <div>
                        <strong>SAMU / Hospital & Ambulância</strong>
                        <span>Atendimento médico de urgência</span>
                    </div>
                    <span class="numero-emergencia">192</span>
                </a>

                <a href="tel:191" class="card-contato-emergencia prf">
                    <div>
                        <strong>Polícia Rodoviária Federal (PRF)</strong>
                        <span>Emergências em rodovias federais</span>
                    </div>
                    <span class="numero-emergencia">191</span>
                </a>

                <a href="tel:08007772026" class="card-contato-emergencia central">
                    <div>
                        <strong>Plantão Operacional BoaRotaBuss</strong>
                        <span>Suporte direto ao passageiro em trânsito</span>
                    </div>
                    <span class="numero-emergencia">0800 777 2026</span>
                </a>
            </div>
        </div>
    </div>

    <script>
        // 1. Pesquisa em tempo real na página inicial
        const inputPesquisa = document.getElementById('inputPesquisaHome');
        const itensBuscaveis = document.querySelectorAll('.item-buscavel');

        function filtrarPaginaHome() {
            const termo = inputPesquisa.value.toLowerCase().trim();
            itensBuscaveis.forEach(item => {
                const texto = item.textContent.toLowerCase();
                item.classList.toggle('escondido', termo !== '' && !texto.includes(termo));
            });
        }

        inputPesquisa.addEventListener('input', filtrarPaginaHome);
        document.getElementById('btnPesquisarHome').addEventListener('click', () => {
            filtrarPaginaHome();
            document.querySelector('.tela-branca-home').scrollIntoView({ behavior: 'smooth' });
        });

        // 2. Chat Direto com a Empresa (com histórico dinâmico)
        const modalChat = document.getElementById('modalChatEmpresa');
        const historicoChat = document.getElementById('historicoChatHome');

        document.querySelectorAll('.btn-abrir-chat').forEach(btn => {
            btn.addEventListener('click', () => {
                const empresa = btn.dataset.empresa;
                const rota = btn.dataset.rota;
                const saida = btn.dataset.saida;

                document.getElementById('chatNomeEmpresa').textContent = empresa;
                document.getElementById('chatResumoRota').innerHTML = `<strong>Rota:</strong> ${rota} • <strong>Saída:</strong> ${saida}`;
                document.getElementById('inputChatEmpresa').value = empresa;
                document.getElementById('inputChatRota').value = rota;

                historicoChat.innerHTML = `
                    <div style="background:#e1f3f6; color:#06303d; padding:10px 12px; border-radius:12px; margin-bottom:8px;">
                        <strong>${empresa}:</strong> Olá! Envie sua mensagem abaixo para consultar poltronas disponíveis, pontos de embarque ou detalhes do pacote incluso.
                    </div>
                `;

                const msgsDaRota = DADOS_CHAT_SALVOS.filter(m => m.rota === rota);
                msgsDaRota.forEach(m => {
                    historicoChat.innerHTML += `
                        <div style="background:#0e7f94; color:#ffffff; padding:10px 12px; border-radius:12px; margin-bottom:8px; text-align:right;">
                            <strong>${m.nome}:</strong> ${m.mensagem}
                            <div style="font-size:0.72rem; opacity:0.85; margin-top:2px;">${m.criado_em}</div>
                        </div>
                    `;

                    if (m.resposta_empresa) {
                        historicoChat.innerHTML += `
                            <div style="background:#dff3f7; color:#06303d; border-left:3px solid #0e7f94; padding:10px 12px; border-radius:12px; margin-bottom:8px;">
                                <strong>${m.respondido_por || empresa}:</strong> ${m.resposta_empresa}
                                <div style="font-size:0.72rem; opacity:0.75; margin-top:2px;">${m.respondido_em || ''}</div>
                            </div>
                        `;
                    }
                });

                modalChat.classList.remove('escondido');
                historicoChat.scrollTop = historicoChat.scrollHeight;
            });
        });

        document.getElementById('btnFecharChat').addEventListener('click', () => {
            modalChat.classList.add('escondido');
        });

        // 3. Controle da Tela/Modal de Emergências
        const modalEmergencia = document.getElementById('modalEmergencia');
        document.getElementById('btnAbrirEmergencia').addEventListener('click', () => {
            modalEmergencia.classList.remove('escondido');
        });
        document.getElementById('btnFecharEmergencia').addEventListener('click', () => {
            modalEmergencia.classList.add('escondido');
        });

        [modalEmergencia, modalChat].forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) modal.classList.add('escondido');
            });
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                modalEmergencia.classList.add('escondido');
                modalChat.classList.add('escondido');
            }
        });

        // 4. Controle do Carrossel de Propaganda em Destaque
        const trilhoDestaque = document.getElementById('trilhoDestaque');
        const slidesDestaque = document.querySelectorAll('.slide-destaque');
        const pontosCarrossel = document.querySelectorAll('.ponto-carrossel');
        let slideAtual = 0;

        function irParaSlide(indice) {
            if (!trilhoDestaque || slidesDestaque.length === 0) return;
            slideAtual = (indice + slidesDestaque.length) % slidesDestaque.length;
            trilhoDestaque.style.transform = `translateX(-${slideAtual * 100}%)`;

            pontosCarrossel.forEach((ponto, i) => {
                ponto.classList.toggle('ativo', i === slideAtual);
            });
        }

        document.getElementById('btnSlideProximo')?.addEventListener('click', () => irParaSlide(slideAtual + 1));
        document.getElementById('btnSlideAnterior')?.addEventListener('click', () => irParaSlide(slideAtual - 1));

        pontosCarrossel.forEach(ponto => {
            ponto.addEventListener('click', () => irParaSlide(Number(ponto.dataset.slide)));
        });

        let timerCarrossel = setInterval(() => irParaSlide(slideAtual + 1), 6000);
        const wrapperCarrossel = document.querySelector('.carrossel-destaque-wrapper');
        wrapperCarrossel?.addEventListener('mouseenter', () => clearInterval(timerCarrossel));
        wrapperCarrossel?.addEventListener('mouseleave', () => {
            timerCarrossel = setInterval(() => irParaSlide(slideAtual + 1), 6000);
        });
    </script>

</body>
</html>