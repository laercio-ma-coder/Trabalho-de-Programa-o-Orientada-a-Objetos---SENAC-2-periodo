<?php
// Recupera os dados do passageiro da sessão (ou usa valores padrão para demonstração)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$nomePsg  = $_SESSION['nome']  ?? 'Ana Clara Souza';
$emailPsg = $_SESSION['email'] ?? 'ana.clara@gmail.com';
?>
<?php include 'inc/headerPSG.inc.php'; ?>

<main class="pagina">
    <!-- Botão flutuante padronizado para voltar à viagem -->
    <a class="retorar" href="indexPassageiro.php" aria-label="Voltar para Minha Viagem"><</a>

    <section class="perfil">
        <h2>Meu Perfil</h2>

        <!-- Avatar com fallback automático de iniciais caso não haja foto cadastrada -->
        <img src="img/avatar-passageiro.png" alt="Foto do Passageiro"
             onerror="this.style.display='none'; this.nextElementSibling.style.display='grid';">
        <div style="display: none; place-items: center; width: 90px; height: 90px; margin: 0 auto 14px; border-radius: 50%; background: linear-gradient(135deg, var(--destaque-1), var(--destaque-2)); border: 2px solid var(--foco); font-size: 1.5rem; font-weight: 800; color: #fff;">
            AC
        </div>

        <p id="txt-nome-psg"><?= htmlspecialchars($nomePsg) ?></p>
        <p><strong>E-mail:</strong> <span id="txt-email-psg"><?= htmlspecialchars($emailPsg) ?></span></p>
        <p><strong>Telefone:</strong> <span id="txt-tel-psg">(42) 99911-2233</span></p>
        <p><strong>Contato de Emergência:</strong> <span id="txt-emerg-psg">Maria Souza — (42) 99877-6655</span></p>
        <p><strong>Status da Conta:</strong> Passageiro Verificado • 4 viagens realizadas</p>

        <div class="botoes" style="justify-content: center;">
            <button type="button" id="editarPerfil">Editar Perfil</button>
            <a id="sair" href="indexLoginPassageiro.php">Sair</a>
        </div>

        <!-- ==========================================================
             FORMULÁRIO EXPANSÍVEL DE EDIÇÃO DO PERFIL DO PASSAGEIRO
             ========================================================== -->
        <form id="formEditarPerfilPSG" class="escondido" style="margin-top: 16px; padding-top: 14px; border-top: 1px solid rgba(255,255,255,0.2);">
            <div class="campo">
                <label class="dados" for="edit-nome-psg">Nome Completo</label>
                <input class="input" type="text" id="edit-nome-psg" value="<?= htmlspecialchars($nomePsg) ?>" required>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="edit-email-psg">E-mail</label>
                    <input class="input" type="email" id="edit-email-psg" value="<?= htmlspecialchars($emailPsg) ?>" required>
                </div>
                <div class="campo">
                    <label class="dados" for="edit-tel-psg">Telefone</label>
                    <input class="input" type="tel" id="edit-tel-psg" value="(42) 99911-2233" required>
                </div>
            </div>

            <div class="campo">
                <label class="dados" for="edit-emerg-psg">Contato de Emergência (Nome e Telefone)</label>
                <input class="input" type="text" id="edit-emerg-psg" value="Maria Souza — (42) 99877-6655" required>
            </div>

            <div class="botoes">
                <button type="submit" class="buttonLGN">Salvar Alterações</button>
                <button type="button" class="buttonLGN secundario" id="cancelarEditarPSG">Cancelar</button>
            </div>
        </form>
    </section>
</main>

<script>
    // Abre/fecha o formulário de edição de perfil do passageiro
    const formPsg = document.getElementById('formEditarPerfilPSG');

    document.getElementById('editarPerfil').addEventListener('click', () => {
        formPsg.classList.toggle('escondido');
    });

    document.getElementById('cancelarEditarPSG').addEventListener('click', () => {
        formPsg.classList.add('escondido');
    });

    // Atualiza os dados na tela imediatamente ao salvar
    formPsg.addEventListener('submit', (e) => {
        e.preventDefault();
        document.getElementById('txt-nome-psg').textContent  = document.getElementById('edit-nome-psg').value;
        document.getElementById('txt-email-psg').textContent = document.getElementById('edit-email-psg').value;
        document.getElementById('txt-tel-psg').textContent   = document.getElementById('edit-tel-psg').value;
        document.getElementById('txt-emerg-psg').textContent = document.getElementById('edit-emerg-psg').value;
        formPsg.classList.add('escondido');
        alert('Perfil atualizado com sucesso!');
    });
</script>

<?php include 'inc/footer.inc.php'; ?>