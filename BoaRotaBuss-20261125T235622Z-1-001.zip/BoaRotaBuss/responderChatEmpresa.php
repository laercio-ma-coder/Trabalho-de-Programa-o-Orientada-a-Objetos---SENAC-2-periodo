<?php
session_start();
require_once __DIR__ . '/classes/BancoJson.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idOriginal = (int) ($_POST['id_original'] ?? 0);
    $resposta   = trim($_POST['resposta'] ?? '');
    $empresa    = $_SESSION['nome'] ?? 'Empresa Parceira';

    if ($idOriginal > 0 && $resposta !== '') {
        $mensagens = BancoJson::ler('chat_atendimento');

        foreach ($mensagens as &$item) {
            if ((int) $item['id'] === $idOriginal) {
                $item['lida'] = 'S';
                $item['resposta_empresa'] = $resposta;
                $item['respondido_por']   = $empresa;
                $item['respondido_em']    = date('d/m/Y H:i');
                break;
            }
        }
        unset($item);

        BancoJson::salvar('chat_atendimento', $mensagens);
    }
}

$volta = $_SERVER['HTTP_REFERER'] ?? 'indexEmpresarial.php';
header('Location: ' . $volta);
exit;