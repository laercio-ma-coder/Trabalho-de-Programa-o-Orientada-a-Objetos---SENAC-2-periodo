<?php include 'inc/headerMRT.inc.php'; ?>

<main class="pagina">
    <!-- Botão flutuante padronizado para voltar à operação -->
    <a class="retorar" href="indexMotorista.php" aria-label="Voltar para Minha Viagem"><</a>

    <section class="perfil-mtr card">
        <span class="badge-perfil-mtr">COLABORADOR OPERACIONAL</span>
        <h2>Meu Perfil — Motorista</h2>

        <!-- Avatar com fallback automático caso a imagem não exista na pasta img/ -->
        <div class="avatar-perfil-mtr">
            <img src="img/avatar-motorista.png" alt="Foto do Motorista" onerror="this.style.display='none'; this.nextElementSibling.style.display='grid';">
            <div class="avatar-fallback" style="display: none;">MO</div>
        </div>

        <p class="nome-principal-mtr" id="txt-nome-mtr">Marcos Oliveira</p>

        <!-- Dados corporativos (somente leitura) e pessoais (editáveis) -->
        <div class="lista-dados-perfil">
            <p><strong>Empresa Vinculada:</strong> BusTotal Transportes Rodoviários</p>
            <p><strong>E-mail Corporativo (Login):</strong> marcos.motorista@bustotal.com</p>
            <p><strong>E-mail Pessoal:</strong> <span id="txt-email-pessoal">marcos.oliveira@gmail.com</span></p>
            <p><strong>Telefone / Emergência:</strong> <span id="txt-tel-mtr">(42) 99988-7766</span></p>
            <p><strong>CNH / Categoria:</strong> 04829104822 — Categoria D (EAR)</p>
            <p><strong>Status Operacional:</strong> Ativo em Viagem</p>
        </div>

        <div class="botoes">
            <button type="button" class="buttonLGN" id="editarPerfil">Editar Contato</button>
            <a class="buttonLGN sair-mtr" id="sair" href="indexLoginPassageiro.php">Sair do Sistema</a>
        </div>
    </section>
</main>

<!-- ==========================================================
     MODAL PARA EDITAR DADOS DE CONTATO DO MOTORISTA
     ========================================================== -->
<div class="modal-overlay escondido" id="modalEditarPerfilMTR" role="dialog" aria-modal="true">
    <div class="modal-mtr-box">
        <div class="topo-modal-mtr">
            <div>
                <span class="tag-poltrona">Atualização Cadastral</span>
                <h2>Editar Contato do Motorista</h2>
            </div>
            <button type="button" class="btn-fechar-modal" id="fecharModalPerfil">×</button>
        </div>

        <p class="subtitulo-painel">Dados corporativos (e-mail da empresa e CNH) só podem ser alterados pelo administrador.</p>

        <form action="atualizarPerfilMotorista.php" method="post" id="formEditarPerfilMTR">
            <label class="dados" for="edit-email-mtr">E-mail Pessoal</label>
            <input class="input" type="email" id="edit-email-mtr" name="email_pessoal" value="marcos.oliveira@gmail.com" required>

            <label class="dados" for="edit-tel-mtr">Telefone / WhatsApp</label>
            <input class="input" type="tel" id="edit-tel-mtr" name="telefone" value="(42) 99988-7766" required>

            <div class="botoes">
                <button type="submit" class="buttonLGN">Salvar Alterações</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modalPerfil = document.getElementById('modalEditarPerfilMTR');

    document.getElementById('editarPerfil').addEventListener('click', () => {
        modalPerfil.classList.remove('escondido');
    });

    document.getElementById('fecharModalPerfil').addEventListener('click', () => {
        modalPerfil.classList.add('escondido');
    });

    // Atualiza imediatamente na interface para demonstração visual
    document.getElementById('formEditarPerfilMTR').addEventListener('submit', (e) => {
        e.preventDefault();
        document.getElementById('txt-email-pessoal').textContent = document.getElementById('edit-email-mtr').value;
        document.getElementById('txt-tel-mtr').textContent       = document.getElementById('edit-tel-mtr').value;
        modalPerfil.classList.add('escondido');
        alert('Dados de contato atualizados!');
    });
</script>

<?php include 'inc/footer.inc.php'; ?>