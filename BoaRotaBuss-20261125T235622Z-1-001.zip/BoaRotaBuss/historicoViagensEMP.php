<?php include 'inc/headerEMP.inc.php'; ?>

<?php include 'inc/menuLateralEMP.inc.php'; ?>

<div class="tela">
    <div class="historico-viagens" id="historico-viagens">
        <div class="topo-listagem">
            <div>
                <h1 class="title">Histórico de Viagens</h1>
                <p class="subtitle">Acompanhe o histórico de viagens realizadas pela empresa, incluindo detalhes de embarque e desembarque.</p>
            </div>
            <a href="ViagemEMP.php" class="btn-historico">← Voltar para Viagens</a>
        </div>

        <!-- Barra de Filtros por Status + Pesquisa -->
        <div class="controles-frota">
            <div class="grupo-filtros-status" role="group" aria-label="Filtrar histórico por status">
                <button type="button" class="btn-filtro-status ativo" data-status="todos">
                    Todas (4)
                </button>
                <button type="button" class="btn-filtro-status disponivel" data-status="concluida">
                    Concluídas (2)
                </button>
                <button type="button" class="btn-filtro-status rota" data-status="andamento">
                    Em Andamento (1)
                </button>
                <button type="button" class="btn-filtro-status cancelada" data-status="cancelada">
                    Canceladas (1)
                </button>
            </div>

            <div class="caixa-pesquisa-frota">
                <input type="search" class="input" id="pesquisa-historico"
                       placeholder="Buscar por ID, rota, motorista ou placa...">
            </div>
        </div>

        <!-- Tabela de Histórico -->
        <div class="tabela-responsiva">
            <table class="tabela-frota" id="tabela-historico">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Rota</th>
                        <th>Data / Saída</th>
                        <th>Motorista / Ônibus</th>
                        <th>Passageiros Embarcados</th>
                        <th>Status</th>
                        <th>Detalhes</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Viagem 001 -->
                    <tr data-status="concluida">
                        <td><code>#001</code></td>
                        <td><strong>Ponta Grossa → Curitiba</strong></td>
                        <td>
                            15/11/2026<br>
                            <small>Saída: 08:00 • Chegada: 09:50</small>
                        </td>
                        <td>
                            <strong>Carlos Eduardo Mendes</strong><br>
                            <small>Marcopolo G7 (ABC-1234)</small>
                        </td>
                        <td>
                            <span class="badge-paradas com-paradas">38 / 44 embarques</span>
                        </td>
                        <td><span class="badge-paradas direta">Concluída</span></td>
                        <td>
                            <button type="button" class="btn-editar btn-detalhes"
                                    data-id="#001"
                                    data-rota="Ponta Grossa → Curitiba"
                                    data-data="15/11/2026 (08:00 às 09:50)"
                                    data-motorista="Carlos Eduardo Mendes"
                                    data-onibus="Marcopolo Paradiso G7 (ABC-1234)"
                                    data-embarques="38 embarques confirmados • 6 reservas não compareceram"
                                    data-paradas="Rodoviária de Palmeira (08:45 - 6 embarques) • Campo Largo (09:20 - 4 desembarques)">
                                Embarque / Desembarque
                            </button>
                        </td>
                    </tr>

                    <!-- Viagem 002 -->
                    <tr data-status="concluida">
                        <td><code>#002</code></td>
                        <td><strong>Curitiba → Ponta Grossa</strong></td>
                        <td>
                            16/11/2026<br>
                            <small>Saída: 18:00 • Chegada: 19:45</small>
                        </td>
                        <td>
                            <strong>Marcos Vinícius Ferreira</strong><br>
                            <small>Comil Invictus (DEF-5678)</small>
                        </td>
                        <td>
                            <span class="badge-paradas com-paradas">40 / 46 embarques</span>
                        </td>
                        <td><span class="badge-paradas direta">Concluída</span></td>
                        <td>
                            <button type="button" class="btn-editar btn-detalhes"
                                    data-id="#002"
                                    data-rota="Curitiba → Ponta Grossa"
                                    data-data="16/11/2026 (18:00 às 19:45)"
                                    data-motorista="Marcos Vinícius Ferreira"
                                    data-onibus="Comil Campione Invictus (DEF-5678)"
                                    data-embarques="40 embarques confirmados • 100% dos check-ins realizados"
                                    data-paradas="Viagem Direta (sem paradas intermediárias)">
                                Embarque / Desembarque
                            </button>
                        </td>
                    </tr>

                    <!-- Viagem 003 -->
                    <tr data-status="andamento">
                        <td><code>#003</code></td>
                        <td><strong>Curitiba → Guarapuava</strong></td>
                        <td>
                            17/11/2026<br>
                            <small>Saída: 19:30 • Previsto: 23:10</small>
                        </td>
                        <td>
                            <strong>Roberto Almeida Santos</strong><br>
                            <small>Busscar Vissta (GHI-9012)</small>
                        </td>
                        <td>
                            <span class="badge-paradas com-paradas">40 / 42 embarques</span>
                        </td>
                        <td><span class="badge-paradas com-paradas">Em Andamento</span></td>
                        <td>
                            <button type="button" class="btn-editar btn-detalhes"
                                    data-id="#003"
                                    data-rota="Curitiba → Guarapuava"
                                    data-data="17/11/2026 (Saída às 19:30)"
                                    data-motorista="Roberto Almeida Santos"
                                    data-onibus="Busscar Vissta Buss (GHI-9012)"
                                    data-embarques="40 passageiros a bordo • Próxima parada: Irati"
                                    data-paradas="Palmeira (Concluída) • Irati (Prevista 21:15) • Prudentópolis (Prevista 22:10)">
                                Embarque / Desembarque
                            </button>
                        </td>
                    </tr>

                    <!-- Viagem 004 -->
                    <tr data-status="cancelada">
                        <td><code>#004</code></td>
                        <td><strong>Ponta Grossa → Castro</strong></td>
                        <td>
                            17/11/2026<br>
                            <small>Previsto: 07:00</small>
                        </td>
                        <td>
                            <strong>Carlos Eduardo Mendes</strong><br>
                            <small>Volvo B450R (JKL-3456)</small>
                        </td>
                        <td>
                            <span class="badge-paradas direta">0 / 42 embarques</span>
                        </td>
                        <td><span class="badge-paradas status-cancelada">Cancelada</span></td>
                        <td>
                            <button type="button" class="btn-editar btn-detalhes"
                                    data-id="#004"
                                    data-rota="Ponta Grossa → Castro"
                                    data-data="17/11/2026 (Cancelada antes da partida)"
                                    data-motorista="Carlos Eduardo Mendes"
                                    data-onibus="Volvo B450R Busscar (JKL-3456)"
                                    data-embarques="0 embarques • 12 passageiros realocados para o horário das 09:00"
                                    data-paradas="Motivo: Manutenção preventiva identificada na inspeção matinal">
                                Embarque / Desembarque
                            </button>
                        </td>
                    </tr>

                    <tr id="linha-sem-historico" class="escondido">
                        <td colspan="7" class="mensagem-vazia">
                            Nenhuma viagem encontrada no histórico para esse filtro.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Painel Expansível de Detalhes de Embarque e Desembarque -->
        <div id="painel-detalhes-viagem" class="box-parada painel-detalhes escondido">
            <div class="topo-detalhes">
                <h3 class="titulo-parada" id="detalhe-titulo">Detalhes da Viagem</h3>
                <button type="button" class="btn-excluir" id="btnFecharDetalhes">Fechar</button>
            </div>
            <div class="grid-detalhes-viagem">
                <p><strong>Data e Horário:</strong> <span id="detalhe-data"></span></p>
                <p><strong>Motorista Responsável:</strong> <span id="detalhe-motorista"></span></p>
                <p><strong>Ônibus Escalado:</strong> <span id="detalhe-onibus"></span></p>
                <p><strong>Controle de Embarque:</strong> <span id="detalhe-embarques"></span></p>
                <p class="linha-inteira"><strong>Paradas e Desembarques:</strong> <span id="detalhe-paradas"></span></p>
            </div>
        </div>
    </div>
</div>

<script>
    // 1. Filtro por status + barra de pesquisa
    const botoesFiltroHist = document.querySelectorAll('.btn-filtro-status');
    const campoPesquisaHist = document.getElementById('pesquisa-historico');
    const linhasHistorico = document.querySelectorAll('#tabela-historico tbody tr[data-status]');
    const linhaVaziaHist = document.getElementById('linha-sem-historico');

    let statusHistSelecionado = 'todos';

    function filtrarHistorico() {
        const termo = campoPesquisaHist.value.toLowerCase().trim();
        let visiveis = 0;

        linhasHistorico.forEach(linha => {
            const statusLinha = linha.dataset.status;
            const textoLinha = linha.textContent.toLowerCase();

            const bateStatus = (statusHistSelecionado === 'todos') || (statusLinha === statusHistSelecionado);
            const bateTexto = textoLinha.includes(termo);

            if (bateStatus && bateTexto) {
                linha.classList.remove('escondido');
                visiveis++;
            } else {
                linha.classList.add('escondido');
            }
        });

        linhaVaziaHist.classList.toggle('escondido', visiveis > 0);
    }

    botoesFiltroHist.forEach(btn => {
        btn.addEventListener('click', () => {
            botoesFiltroHist.forEach(b => b.classList.remove('ativo'));
            btn.classList.add('ativo');
            statusHistSelecionado = btn.dataset.status;
            filtrarHistorico();
        });
    });

    campoPesquisaHist.addEventListener('input', filtrarHistorico);

    // 2. Exibição dos detalhes de embarque e desembarque
    const painelDetalhes = document.getElementById('painel-detalhes-viagem');
    const botoesDetalhes = document.querySelectorAll('.btn-detalhes');
    const btnFecharDetalhes = document.getElementById('btnFecharDetalhes');

    botoesDetalhes.forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('detalhe-titulo').textContent = `Viagem ${btn.dataset.id} — ${btn.dataset.rota}`;
            document.getElementById('detalhe-data').textContent = btn.dataset.data;
            document.getElementById('detalhe-motorista').textContent = btn.dataset.motorista;
            document.getElementById('detalhe-onibus').textContent = btn.dataset.onibus;
            document.getElementById('detalhe-embarques').textContent = btn.dataset.embarques;
            document.getElementById('detalhe-paradas').textContent = btn.dataset.paradas;

            painelDetalhes.classList.remove('escondido');
            painelDetalhes.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
    });

    btnFecharDetalhes.addEventListener('click', () => {
        painelDetalhes.classList.add('escondido');
    });
</script>

<?php include 'inc/footerEMP.inc.php'; ?>