<?php include 'inc/headerPSG.inc.php'; ?>
<main class="pagina">   
    <div class="afiliadas"> 
        <H1>Empresas Afiliadas</H1>
        <div class="cardEmpresa">
            <img class="logo-empresa" src="#" alt="Logo da Empresa 1"> <!--aqui vai carregar a imagem que a empresa que se cadastrou colocar como logo e em baixo vai relfetir a rasão social dela -->
            <h2 class="nome-empresa" id="nome-empresa">Empresa</h2>
        </div>
    </div>
</main>

<?php include 'inc/footer.inc.php'; ?>