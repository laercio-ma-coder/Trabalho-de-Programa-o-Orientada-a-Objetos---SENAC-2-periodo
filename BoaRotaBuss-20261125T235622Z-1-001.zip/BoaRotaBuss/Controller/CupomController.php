<?php
namespace App\Controller;

use App\DAO\CupomDAO;
use App\Model\Cupom;
use Exception;
use PDOException;

class CupomController {
    private CupomDAO $dao;

    public function __construct() {
        $this->dao = new CupomDAO();
    }

    public function salvar(array $dados): string {
        $parceiroFk = (int)($dados['parceiro_fk'] ?? 0);
        $codigo = trim($dados['codigo'] ?? '');
        $desconto = trim($dados['desconto'] ?? '');

        if ($parceiroFk <= 0) {
            throw new Exception("Selecione um parceiro válido para vincular o cupom.");
        }
        if ($codigo === '' || $desconto === '') {
            throw new Exception("Código e benefício do cupom são obrigatórios.");
        }

        $cupom = new Cupom(
            $parceiroFk,
            $codigo,
            $desconto,
            $dados['validade'] ?: null,
            trim($dados['descricao'] ?? ''),
            !empty($dados['quantidade_limite']) ? (int)$dados['quantidade_limite'] : null,
            $dados['status'] ?? 'ATIVO',
            !empty($dados['id']) ? (int)$dados['id'] : null
        );

        try {
            if ($cupom->getId()) {
                $this->dao->atualizar($cupom);
                return "Cupom atualizado com sucesso!";
            }
            $this->dao->criar($cupom);
            return "Cupom criado com sucesso!";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                throw new Exception("Já existe um cupom cadastrado com o código '{$cupom->getCodigo()}'.");
            }
            throw $e;
        }
    }

    public function listar(): array {
        return $this->dao->listarTodos();
    }

    public function buscar(int $id): ?Cupom {
        return $this->dao->buscarPorId($id);
    }

    public function excluir(int $id): string {
        $this->dao->deletar($id);
        return "Cupom excluído com sucesso!";
    }
}