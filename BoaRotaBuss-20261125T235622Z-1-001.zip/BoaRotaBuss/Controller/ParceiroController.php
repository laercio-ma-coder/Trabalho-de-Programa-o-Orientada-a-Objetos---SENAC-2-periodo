<?php
namespace App\Controller;

use App\DAO\ParceiroDAO;
use App\Model\Parceiro;
use Exception;

class ParceiroController {
    private ParceiroDAO $dao;

    public function __construct() {
        $this->dao = new ParceiroDAO();
    }

    public function salvar(array $dados): string {
        $nome = trim($dados['nome'] ?? '');
        if ($nome === '') {
            throw new Exception("O nome do parceiro é obrigatório.");
        }

        $parceiro = new Parceiro(
            $nome,
            trim($dados['categoria'] ?? ''),
            trim($dados['site_proprio'] ?? ''),
            trim($dados['descricao'] ?? ''),
            $dados['tipo'] ?? 'PARCEIRO',
            !empty($dados['id']) ? (int)$dados['id'] : null
        );

        if ($parceiro->getId()) {
            $this->dao->atualizar($parceiro);
            return "Parceiro atualizado com sucesso!";
        }

        $this->dao->criar($parceiro);
        return "Parceiro cadastrado com sucesso!";
    }

    public function listar(): array {
        return $this->dao->listarTodos();
    }

    public function buscar(int $id): ?Parceiro {
        return $this->dao->buscarPorId($id);
    }

    public function excluir(int $id): string {
        $this->dao->deletar($id);
        return "Parceiro (e seus cupons vinculados) excluído com sucesso!";
    }
}