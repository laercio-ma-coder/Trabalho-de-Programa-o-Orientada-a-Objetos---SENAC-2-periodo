<?php include 'inc/headerEMP.inc.php'; ?>

<?php include 'inc/menuLateralEMP.inc.php'; ?>

<!-- ==========================================================
     BLOCO 1: CADASTRO DE ÔNIBUS DA FROTA
     ========================================================== -->
<div class="tela">
    <section class="cadastrar-viagem" id="cadastraonibus">
        <h1 class="title">Cadastrar Ônibus</h1>
        <p class="subtitle">Adicione um novo veículo à frota da empresa e configure suas comodidades</p>

        <form action="cadastrarOnibus.php" method="POST">
            <div class="linha">
                <div class="campo">
                    <label class="dados" for="marca">Marca / Montadora</label>
                    <input class="input" type="text" id="marca" name="marca"
                           placeholder="Ex: Marcopolo, Mercedes-Benz, Volvo" required>
                </div>

                <div class="campo">
                    <label class="dados" for="modelo">Modelo</label>
                    <input class="input" type="text" id="modelo" name="modelo"
                           placeholder="Ex: Paradiso G7 1200" required>
                </div>
            </div>

            <div class="linha">
                <div class="campo">
                    <label class="dados" for="placa">Placa</label>
                    <input class="input" type="text" id="placa" name="placa"
                           placeholder="ABC-1234 ou ABC1D23" maxlength="8" required>
                </div>

                <div class="campo">
                    <label class="dados" for="ano">Ano de Fabricação</label>
                    <input class="input" type="number" id="ano" name="ano"
                           min="1995" max="2027" placeholder="Ex: 2023" required>
                </div>

                <div class="campo">
                    <label class="dados" for="capacidade">Capacidade (Assentos)</label>
                    <input class="input" type="number" id="capacidade" name="capacidade"
                           min="10" max="80" placeholder="Ex: 44" required>
                </div>
            </div>

            <label class="dados" for="status_onibus">Status Inicial do Veículo</label>
            <select class="input" id="status_onibus" name="status_onibus" required>
                <option value="disponivel" selected>Disponível na Garagem</option>
                <option value="em_viagem">Em Operação / Viagem</option>
                <option value="manutencao">Em Manutenção</option>
            </select>

            <!-- Comodidades a Bordo -->
            <label class="dados">Comodidades Disponíveis no Veículo</label>
            <div class="grade-comodidades">
                <label class="check-comodidade" for="banheiro">
                    <input type="checkbox" id="banheiro" name="banheiro" value="1">
                    <span>Banheiro (WC)</span>
                </label>

                <label class="check-comodidade" for="ar_condicionado">
                    <input type="checkbox" id="ar_condicionado" name="ar_condicionado" value="1">
                    <span>Ar-condicionado</span>
                </label>

                <label class="check-comodidade" for="wifi">
                    <input type="checkbox" id="wifi" name="wifi" value="1">
                    <span>Wi-Fi a Bordo</span>
                </label>
            </div>

            <div class="botoes">
                <button type="submit" class="buttonLGN">Salvar Ônibus</button>
            </div>
        </form>
    </section>
</div>

<!-- ==========================================================
     BLOCO 2: FILTRO POR STATUS E BARRA DE PESQUISA DA FROTA
     ========================================================== -->
<div class="tela">
    <div class="topo-listagem">
        <h1 class="title">Consulta Rápida da Frota</h1>
        <span class="badge-paradas com-paradas" id="contador-resultados">4 veículos exibidos</span>
    </div>

    <!-- Barra de Controles: Botões de Status + Pesquisa -->
    <div class="controles-frota">
        <div class="grupo-filtros-status" role="group" aria-label="Filtrar ônibus por status">
            <button type="button" class="btn-filtro-status ativo" data-status="todos">
                Todos (4)
            </button>
            <button type="button" class="btn-filtro-status rota" data-status="rota">
                Em Rota (2)
            </button>
            <button type="button" class="btn-filtro-status manutencao" data-status="manutencao">
                Em Manutenção (1)
            </button>
            <button type="button" class="btn-filtro-status disponivel" data-status="disponivel">
                Disponíveis (1)
            </button>
        </div>

        <div class="caixa-pesquisa-frota">
            <input type="search" class="input" id="pesquisa-frota"
                   placeholder="Buscar por placa, modelo, motorista ou rota...">
        </div>
    </div>

    <!-- Tabela Unificada Filtrável -->
    <div class="tabela-responsiva">
        <table class="tabela-frota" id="tabela-status-frota">
            <thead>
                <tr>
                    <th>Veículo</th>
                    <th>Placa</th>
                    <th>Situação / Detalhes</th>
                    <th>Ocupação / Capacidade</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr data-status="rota">
                    <td><strong>Marcopolo Paradiso G7</strong></td>
                    <td><code>ABC-1234</code></td>
                    <td>Rota: Ponta Grossa → Curitiba (Mot. Carlos Mendes)</td>
                    <td>38 / 44 lugares (86%)</td>
                    <td><span class="badge-paradas com-paradas">Em Rota</span></td>
                </tr>

                <tr data-status="rota">
                    <td><strong>Busscar Vissta Buss</strong></td>
                    <td><code>GHI-9012</code></td>
                    <td>Rota: Curitiba → Guarapuava (Mot. Roberto Santos)</td>
                    <td>40 / 42 lugares (95%)</td>
                    <td><span class="badge-paradas com-paradas">Em Rota</span></td>
                </tr>

                <tr data-status="manutencao">
                    <td><strong>Volvo B450R Busscar</strong></td>
                    <td><code>JKL-3456</code></td>
                    <td>Revisão de freios e ar-condicionado (Retorno: 20/11)</td>
                    <td>42 lugares</td>
                    <td><span class="badge-paradas alerta-cnh">Em Manutenção</span></td>
                </tr>

                <tr data-status="disponivel">
                    <td><strong>Comil Campione Invictus</strong></td>
                    <td><code>DEF-5678</code></td>
                    <td>Estacionado na Garagem Central</td>
                    <td>46 lugares</td>
                    <td><span class="badge-paradas direta">Disponível</span></td>
                </tr>

                <tr id="linha-sem-resultados" class="escondido">
                    <td colspan="5" class="mensagem-vazia">
                        Nenhum ônibus encontrado para esse filtro ou pesquisa.
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- ==========================================================
     BLOCO 3: TABELA DE ÔNIBUS CADASTRADOS
     ========================================================== -->
<div class="tela">
    <div class="topo-listagem">
        <h1 class="title">Ônibus Cadastrados</h1>
    </div>

    <div class="tabela-responsiva">
        <table class="tabela-frota">
            <thead>
                <tr>
                    <th>Veículo</th>
                    <th>Placa</th>
                    <th>Capacidade</th>
                    <th>Comodidades</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <!-- Exemplo 1 -->
                <tr>
                    <td>
                        <strong>Marcopolo Paradiso G7</strong><br>
                        <small>Ano: 2022</small>
                    </td>
                    <td><code>ABC-1234</code></td>
                    <td>44 lugares</td>
                    <td>
                        <div class="chips-comodidades">
                            <span class="chip-item">WC</span>
                            <span class="chip-item">Ar-cond.</span>
                            <span class="chip-item">Wi-Fi</span>
                        </div>
                    </td>
                    <td><span class="badge-paradas com-paradas">Em Viagem</span></td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarOnibus.php?id=1" class="btn-editar">Editar</a>
                            <a href="excluirOnibus.php?id=1" class="btn-excluir">Excluir</a>
                        </div>
                    </td>
                </tr>

                <!-- Exemplo 2 -->
                <tr>
                    <td>
                        <strong>Comil Campione Invictus</strong><br>
                        <small>Ano: 2021</small>
                    </td>
                    <td><code>DEF-5678</code></td>
                    <td>46 lugares</td>
                    <td>
                        <div class="chips-comodidades">
                            <span class="chip-item">Ar-cond.</span>
                            <span class="chip-item">Wi-Fi</span>
                        </div>
                    </td>
                    <td><span class="badge-paradas direta">Disponível</span></td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarOnibus.php?id=2" class="btn-editar">Editar</a>
                            <a href="excluirOnibus.php?id=2" class="btn-excluir">Excluir</a>
                        </div>
                    </td>
                </tr>

                <!-- Exemplo 3 -->
                <tr>
                    <td>
                        <strong>Volvo B450R Busscar</strong><br>
                        <small>Ano: 2019</small>
                    </td>
                    <td><code>JKL-3456</code></td>
                    <td>42 lugares</td>
                    <td>
                        <div class="chips-comodidades">
                            <span class="chip-item">WC</span>
                            <span class="chip-item">Ar-cond.</span>
                        </div>
                    </td>
                    <td><span class="badge-paradas alerta-cnh">Em Manutenção</span></td>
                    <td>
                        <div class="acoes-item">
                            <a href="editarOnibus.php?id=3" class="btn-editar">Editar</a>
                            <a href="excluirOnibus.php?id=3" class="btn-excluir">Excluir</a>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    // 1. Formata placa automaticamente em maiúsculas
    document.getElementById('placa').addEventListener('input', (e) => {
        e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
    });

    // 2. Filtro por status + barra de pesquisa em tempo real
    const botoesFiltro = document.querySelectorAll('.btn-filtro-status');
    const campoPesquisa = document.getElementById('pesquisa-frota');
    const linhasOnibus = document.querySelectorAll('#tabela-status-frota tbody tr[data-status]');
    const linhaVazia = document.getElementById('linha-sem-resultados');
    const contadorResultados = document.getElementById('contador-resultados');

    let statusSelecionado = 'todos';

    function filtrarTabelaFrota() {
        const termo = campoPesquisa.value.toLowerCase().trim();
        let visiveis = 0;

        linhasOnibus.forEach(linha => {
            const statusLinha = linha.dataset.status;
            const textoLinha = linha.textContent.toLowerCase();

            const bateStatus = (statusSelecionado === 'todos') || (statusLinha === statusSelecionado);
            const bateTexto = textoLinha.includes(termo);

            if (bateStatus && bateTexto) {
                linha.classList.remove('escondido');
                visiveis++;
            } else {
                linha.classList.add('escondido');
            }
        });

        linhaVazia.classList.toggle('escondido', visiveis > 0);
        contadorResultados.textContent = visiveis === 1
            ? '1 veículo exibido'
            : `${visiveis} veículos exibidos`;
    }

    botoesFiltro.forEach(btn => {
        btn.addEventListener('click', () => {
            botoesFiltro.forEach(b => b.classList.remove('ativo'));
            btn.classList.add('ativo');
            statusSelecionado = btn.dataset.status;
            filtrarTabelaFrota();
        });
    });

    campoPesquisa.addEventListener('input', filtrarTabelaFrota);
</script>

<?php include 'inc/footerEMP.inc.php'; ?>