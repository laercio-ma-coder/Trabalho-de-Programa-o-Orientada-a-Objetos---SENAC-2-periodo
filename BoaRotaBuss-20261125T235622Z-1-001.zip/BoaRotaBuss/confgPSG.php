<?php include 'inc/headerPSG.inc.php'; ?>

<main class="pagina">
    <section class="card" style="background: rgba(7, 29, 44, 0.72); border: 1px solid rgba(102, 217, 242, 0.22);">
        <span style="display: inline-block; padding: 3px 10px; border-radius: 999px; border: 1px solid #00b8c4; background: rgba(0, 184, 196, 0.14); color: #5fe3ee; font-size: 0.68rem; font-weight: 800; letter-spacing: 0.5px; margin-bottom: 8px;">
            PREFERÊNCIAS DO PAINEL
        </span>

        <h1 class="title">Configurações do Passageiro</h1>
        <p class="subtitle">Ajuste suas preferências de exibição, notificações e segurança da conta.</p>

        <!-- ==========================================================
             LISTA DE PREFERÊNCIAS DO PASSAGEIRO
             ========================================================== -->
        <div style="display: flex; flex-direction: column; gap: 8px;">
            <label style="display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 11px 14px; border-radius: 10px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.14); cursor: pointer;">
                <div>
                    <strong style="display: block; font-size: 0.82rem; color: #ffffff; margin-bottom: 2px;">Modo Escuro (Baixo Brilho)</strong>
                    <span style="font-size: 0.72rem; color: #b8dce4;">Escurece os painéis para maior conforto visual durante viagens noturnas.</span>
                </div>
                <input type="checkbox" id="darkModeToggle">
            </label>

            <label style="display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 11px 14px; border-radius: 10px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.14); cursor: pointer;">
                <div>
                    <strong style="display: block; font-size: 0.82rem; color: #ffffff; margin-bottom: 2px;">Notificações e Alertas de Paradas</strong>
                    <span style="font-size: 0.72rem; color: #b8dce4;">Receba avisos no painel quando o ônibus estiver próximo do seu ponto de embarque ou parada.</span>
                </div>
                <input type="checkbox" id="notificacoes" checked>
            </label>

            <label style="display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 11px 14px; border-radius: 10px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.14); cursor: pointer;">
                <div>
                    <strong style="display: block; font-size: 0.82rem; color: #ffffff; margin-bottom: 2px;">Privacidade e Contato de Emergência</strong>
                    <span style="font-size: 0.72rem; color: #b8dce4;">Permite que a central e o motorista visualizem seu contato de apoio apenas em caso de ocorrência.</span>
                </div>
                <input type="checkbox" id="privacidade" checked>
            </label>

            <!-- Acordeão clicável para abrir o formulário de troca de senha -->
            <div id="btnAbrirSeguranca" role="button" tabindex="0"
                 style="display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 11px 14px; border-radius: 10px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.14); cursor: pointer;">
                <div>
                    <strong style="display: block; font-size: 0.82rem; color: #ffffff; margin-bottom: 2px;">Segurança e Trocar Senha</strong>
                    <span style="font-size: 0.72rem; color: #b8dce4;">Clique aqui para atualizar a senha de acesso da sua conta.</span>
                </div>
                <span id="setaSeguranca" style="color: #5fe3ee; font-size: 0.82rem; font-weight: 800; transition: transform 0.25s;">▼</span>
            </div>
        </div>

        <!-- ==========================================================
             FORMULÁRIO EXPANSÍVEL DE ALTERAÇÃO DE SENHA
             ========================================================== -->
        <div id="cardTrocarSenha" class="escondido"
             style="margin-top: 10px; padding: 16px; border-radius: 12px; background: rgba(6, 26, 44, 0.85); border: 1px solid rgba(0, 184, 196, 0.35);">
            <h2 style="color: #5fe3ee; font-size: 0.92rem; margin-bottom: 8px;">Alterar Senha da Conta</h2>

            <form action="#" method="post" onsubmit="event.preventDefault(); alert('Senha atualizada com sucesso!'); document.getElementById('cardTrocarSenha').classList.add('escondido');">
                <label class="dados" for="senhaAtualPSG">Senha Atual</label>
                <input class="input" type="password" id="senhaAtualPSG" placeholder="Digite sua senha atual" required>

                <div class="linha">
                    <div class="campo">
                        <label class="dados" for="novaSenhaPSG">Nova Senha</label>
                        <input class="input" type="password" id="novaSenhaPSG" placeholder="Mínimo 8 caracteres" required>
                    </div>

                    <div class="campo">
                        <label class="dados" for="confirmaSenhaPSG">Confirmar Nova Senha</label>
                        <input class="input" type="password" id="confirmaSenhaPSG" placeholder="Repita a nova senha" required>
                    </div>
                </div>

                <div class="botoes">
                    <button type="submit" id="alterarSenha" class="buttonLGN">Confirmar Nova Senha</button>
                    <button type="button" id="btnCancelarSenha" class="buttonLGN secundario">Cancelar</button>
                </div>
            </form>
        </div>

        <!-- Botão de Logout -->
        <div class="botoes">
            <a href="indexPassageiro.php" class="buttonLGN secundario">Voltar para Minha Viagem</a>
            <a href="indexLoginPassageiro.php" class="buttonLGN secundario" style="border-color: rgba(214, 69, 80, 0.65); color: #ffb3b9;">Sair da Conta</a>
        </div>
    </section>
</main>

<script>
    // 1. Controle do painel expansível de Trocar Senha (código completado)
    const btnSeguranca     = document.getElementById('btnAbrirSeguranca');
    const cardSenha        = document.getElementById('cardTrocarSenha');
    const setaSeguranca    = document.getElementById('setaSeguranca');
    const btnCancelarSenha = document.getElementById('btnCancelarSenha');

    function alternarCardSenha(forcarFechar = false) {
        const esconder = forcarFechar ? true : !cardSenha.classList.contains('escondido');
        cardSenha.classList.toggle('escondido', esconder);
        setaSeguranca.style.transform = esconder ? 'rotate(0deg)' : 'rotate(180deg)';
    }

    btnSeguranca.addEventListener('click', () => alternarCardSenha(false));
    btnCancelarSenha.addEventListener('click', () => alternarCardSenha(true));

    // 2. Persistência do Modo Escuro e preferências do passageiro no localStorage
    const darkTogglePsg = document.getElementById('darkModeToggle');
    const notifPsg      = document.getElementById('notificacoes');
    const privPsg       = document.getElementById('privacidade');

    if (localStorage.getItem('psg_dark') === '1') {
        darkTogglePsg.checked = true;
        document.body.style.filter = 'brightness(0.88)';
    }
    if (localStorage.getItem('psg_notif') !== null) {
        notifPsg.checked = localStorage.getItem('psg_notif') === '1';
    }
    if (localStorage.getItem('psg_priv') !== null) {
        privPsg.checked = localStorage.getItem('psg_priv') === '1';
    }

    darkTogglePsg.addEventListener('change', () => {
        document.body.style.filter = darkTogglePsg.checked ? 'brightness(0.88)' : '';
        localStorage.setItem('psg_dark', darkTogglePsg.checked ? '1' : '0');
    });

    notifPsg.addEventListener('change', () => {
        localStorage.setItem('psg_notif', notifPsg.checked ? '1' : '0');
    });

    privPsg.addEventListener('change', () => {
        localStorage.setItem('psg_priv', privPsg.checked ? '1' : '0');
    });
</script>

<?php include 'inc/footer.inc.php'; ?>